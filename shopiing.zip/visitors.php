<?php
// Start the session at the very beginning of the file
session_start();

// Redirect to the dashboard if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Gifted Me</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-main-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 4rem;
        }
        .hero-main-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .gift-card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
        }
        .gift-card-item {
            background-color: #fff;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            padding: 1.5rem;
            text-align: center;
        }
        .gift-card-item img {
            max-width: 100px;
            height: auto;
            margin: 0 auto 1rem;
            border-radius: 0.25rem;
        }
        .star-rating {
            display: flex;
            justify-content: center;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .star-rating svg {
            color: #fbbf24; /* Tailwind yellow-400 */
            width: 1rem;
            height: 1rem;
            margin-right: 0.125rem;
        }
        /* Modal Styles */
        .modal-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 40;
            display: none; /* Hidden by default */
        }
        .modal {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            z-index: 50;
            display: none; /* Hidden by default */
        }
        .cart-sidebar {
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            max-width: 400px;
            background-color: white;
            z-index: 50;
            transform: translateX(100%);
            transition: transform 0.3s ease-in-out;
            display: none; /* Hidden by default */
            box-shadow: -10px 0 20px rgba(0,0,0,0.1);
        }
        .cart-sidebar.open {
            transform: translateX(0);
        }
        .modal.open, .modal-backdrop.open, .cart-sidebar.open {
            display: block;
        }

    </style>
</head>
<body class="bg-white">

    <?php include 'header.php'; ?>

    <main class="min-h-screen">
        <div class="hero-main-bg py-20 lg:py-32 flex items-center">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper text-center text-white">
                <h1 class="text-4xl md:text-6xl font-extrabold tracking-tight leading-none mb-6">
                    Discover the perfect gift for every occasion 🎁
                </h1>
                <p class="text-lg md:text-xl font-light text-purple-100 max-w-3xl mx-auto mb-8">
                    Sign up to explore a world of digital gift cards from top brands, track your gifts, and send personalized messages to your loved ones.
                </p>
                <div class="space-y-4 sm:space-y-0 sm:space-x-4 flex flex-col sm:flex-row justify-center">
                    <a href="register.php" class="bg-white text-purple-600 hover:bg-gray-100 font-bold py-3 px-8 rounded-full text-lg transition-colors duration-300 shadow-lg">
                        Create an Account
                    </a>
                    <a href="login.php" class="bg-transparent border-2 border-white text-white hover:bg-white hover:text-purple-600 font-bold py-3 px-8 rounded-full text-lg transition-colors duration-300">
                        Log In
                    </a>
                </div>
            </div>
        </div>

        
<section class="py-16 bg-gray-50">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">Top Sellers This Week</h2>
                <div class="gift-card-grid">
                    
<div class="gift-card-item">
                        <img src="https://via.placeholder.com/100x100/FF5733/FFFFFF?text=Apple" alt="Apple Gift Card">
                        <h3 class="text-lg font-semibold text-gray-900 mb-1">US Apple Gift Card</h3>
                        <div class="star-rating">
                            <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star-half" fill="currentColor"></i>
                            <span class="text-sm text-gray-600 ml-1">4.9 (4696)</span>
                        </div>
                        <p class="text-gray-700 mb-4">$15 - $200</p>
                        <button class="choose-amount-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600 transition-colors duration-300"
                                data-product-id="1" 
                                data-product-name="US Apple Gift Card">
                            Choose Amount
                        </button>
                    </div>

                    
<div class="gift-card-item">
                        <img src="https://via.placeholder.com/100x100/333333/FFFFFF?text=Razer" alt="Razer Gold Gift Card">
                        <h3 class="text-lg font-semibold text-gray-900 mb-1">US Razer Gold Gift Card</h3>
                        <div class="star-rating">
                            <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i>
                            <span class="text-sm text-gray-600 ml-1">5.0 (595)</span>
                        </div>
                        <p class="text-gray-700 mb-4">$20 - $200</p>
                        <button class="choose-amount-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600 transition-colors duration-300"
                                data-product-id="2" 
                                data-product-name="US Razer Gold Gift Card">
                            Choose Amount
                        </button>
                    </div>

                    
<div class="gift-card-item">
                        <img src="https://via.placeholder.com/100x100/F3BA2F/FFFFFF?text=Binance" alt="Binance USDT Gift Card">
                        <h3 class="text-lg font-semibold text-gray-900 mb-1">Binance USDT Gift Card</h3>
                        <div class="star-rating">
                            <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i>
                            <span class="text-sm text-gray-600 ml-1">5.0 (283)</span>
                        </div>
                        <p class="text-gray-700 mb-4">$50 - $200</p>
                        <button class="choose-amount-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600 transition-colors duration-300"
                                data-product-id="3" 
                                data-product-name="Binance USDT Gift Card">
                            Choose Amount
                        </button>
                    </div>
                    
<div class="gift-card-item">
                        <img src="https://via.placeholder.com/100x100/000000/FFFFFF?text=Steam" alt="Steam Gift Card">
                        <h3 class="text-lg font-semibold text-gray-900 mb-1">US Steam Gift Card</h3>
                        <div class="star-rating">
                            <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i>
                            <span class="text-sm text-gray-600 ml-1">5.0 (1028)</span>
                        </div>
                        <p class="text-gray-700 mb-4">$30 - $200</p>
                        <button class="choose-amount-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600 transition-colors duration-300"
                                data-product-id="4" 
                                data-product-name="US Steam Gift Card">
                            Choose Amount
                        </button>
                    </div>
                </div>
                <div class="text-center mt-12">
                    <a href="#" class="inline-flex items-center bg-gray-200 text-gray-800 hover:bg-gray-300 font-semibold py-3 px-6 rounded-lg transition-colors duration-300">
                        Shop All Gift Cards
                        <i data-lucide="arrow-right" class="w-5 h-5 ml-2"></i>
                    </a>
                </div>
            </div>
        </section>

        
</main>

    <?php include 'footer.php'; ?>

    <div id="modal-backdrop" class="modal-backdrop"></div>

    <div id="select-value-modal" class="modal bg-white w-full max-w-lg rounded-lg shadow-xl p-6">
        <div class="flex justify-between items-center mb-4">
            <h2 id="select-value-title" class="text-2xl font-bold">Select Value</h2>
            <button id="close-select-value-modal" class="text-gray-500 hover:text-gray-800">
                <i data-lucide="x" class="w-6 h-6"></i>
            </button>
        </div>
        <div class="space-y-3">
            <div class="flex justify-between items-center p-4 rounded-lg bg-blue-50 border border-blue-200">
                <div class="flex items-center">
                    <img src="https://via.placeholder.com/60x40/333333/FFFFFF?text=Razer" alt="Razer" class="rounded-md mr-4">
                    <div>
                        <h3 class="font-semibold text-gray-900">$200 US Razer Gold Gift Card</h3>
                        <p class="text-lg font-bold text-gray-800">$213.94</p>
                    </div>
                </div>
                <button class="add-to-cart-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600">Add to Cart</button>
            </div>
            
            <div class="flex justify-between items-center p-4 rounded-lg bg-white border">
                <div class="flex items-center">
                    <img src="https://via.placeholder.com/60x40/333333/FFFFFF?text=Razer" alt="Razer" class="rounded-md mr-4">
                    <div>
                        <h3 class="font-semibold text-gray-900">$100 US Razer Gold Gift Card</h3>
                        <p class="text-lg font-bold text-gray-800">$107.97</p>
                    </div>
                </div>
                <button class="add-to-cart-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600">Add to Cart</button>
            </div>

            <div class="flex justify-between items-center p-4 rounded-lg bg-white border">
                <div class="flex items-center">
                    <img src="https://via.placeholder.com/60x40/333333/FFFFFF?text=Razer" alt="Razer" class="rounded-md mr-4">
                    <div>
                        <h3 class="font-semibold text-gray-900">$50 US Razer Gold Gift Card</h3>
                        <p class="text-lg font-bold text-gray-800">$55.97</p>
                    </div>
                </div>
                <button class="add-to-cart-btn bg-yellow-500 text-white font-semibold py-2 px-4 rounded-md hover:bg-yellow-600">Add to Cart</button>
            </div>
        </div>
    </div>

    <div id="cart-sidebar" class="cart-sidebar flex flex-col">
        <div class="flex justify-between items-center p-5 border-b">
            <h2 class="text-2xl font-bold">Your Cart</h2>
            <button id="close-cart-sidebar" class="text-gray-500 hover:text-gray-800">
                <i data-lucide="x" class="w-6 h-6"></i>
            </button>
        </div>
        
        <div class="flex-grow p-5 space-y-4 overflow-y-auto">
            <div class="flex items-start space-x-4">
                <img src="https://via.placeholder.com/60x40/FF5733/FFFFFF?text=Apple" alt="Apple" class="rounded-md w-16">
                <div class="flex-grow">
                    <h3 class="font-semibold text-gray-900">$200 US Apple Gift Card</h3>
                    <div class="star-rating justify-start">
                        <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star-half" fill="currentColor"></i>
                        <span class="text-sm text-gray-600 ml-1">4.9</span>
                    </div>
                    <div class="flex justify-between items-center mt-2">
                        <div class="flex items-center border rounded-md">
                            <button class="px-2 py-1 text-gray-600 hover:bg-gray-100">-</button>
                            <span class="px-3">13</span>
                            <button class="px-2 py-1 text-gray-600 hover:bg-gray-100">+</button>
                        </div>
                        <p class="font-bold text-lg">$214.94</p>
                    </div>
                </div>
            </div>

            <div class="flex items-start space-x-4">
                <img src="https://via.placeholder.com/60x40/333333/FFFFFF?text=Razer" alt="Razer" class="rounded-md w-16">
                <div class="flex-grow">
                    <h3 class="font-semibold text-gray-900">$200 US Razer Gold Gift Card</h3>
                    <div class="star-rating justify-start">
                        <i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i><i data-lucide="star" fill="currentColor"></i>
                        <span class="text-sm text-gray-600 ml-1">5.0</span>
                    </div>
                    <div class="flex justify-between items-center mt-2">
                        <div class="flex items-center border rounded-md">
                            <button class="px-2 py-1 text-gray-600 hover:bg-gray-100">-</button>
                            <span class="px-3">1</span>
                            <button class="px-2 py-1 text-gray-600 hover:bg-gray-100">+</button>
                        </div>
                        <p class="font-bold text-lg">$213.94</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="p-5 border-t bg-gray-50 space-y-4">
            <div>
                <label for="coupon" class="text-sm font-medium text-gray-700">Have a coupon?</label>
                <div class="flex mt-1">
                    <input type="text" id="coupon" name="coupon" class="flex-grow border-gray-300 rounded-l-md shadow-sm focus:ring-purple-500 focus:border-purple-500" placeholder="Coupon code">
                    <button class="bg-gray-200 text-gray-700 font-semibold px-4 rounded-r-md hover:bg-gray-300">Apply</button>
                </div>
            </div>
            
            <div class="flex justify-between items-center bg-yellow-100 text-yellow-800 p-3 rounded-lg">
                <span>Earn <span class="font-bold">30,082</span> reward points</span>
                <i data-lucide="award" class="w-5 h-5"></i>
            </div>

            <div class="flex justify-between items-center text-2xl font-bold">
                <span>Total</span>
                <span>$3,008.16</span>
            </div>
            
            <a href="checkout.php" id="checkout-btn" class="block w-full text-center bg-yellow-500 text-white font-bold py-3 px-4 rounded-lg text-lg hover:bg-yellow-600 transition-colors">
                <i data-lucide="lock" class="w-5 h-5 inline-block -mt-1 mr-2"></i>
                Checkout
            </a>
            <div class="flex justify-center space-x-3 opacity-60">
                <span>VISA</span> <span>MasterCard</span> <span>PayPal</span> <span>Amex</span> <span>Pay</span>
            </div>
        </div>
    </div>


    <script>
        // Make sure lucide icons are created for the new modals
        lucide.createIcons();

        // --- Get All Modal Elements ---
        const backdrop = document.getElementById('modal-backdrop');
        
        // "Select Value" Modal
        const selectValueModal = document.getElementById('select-value-modal');
        const selectValueTitle = document.getElementById('select-value-title');
        const closeSelectValueBtn = document.getElementById('close-select-value-modal');
        
        // "Your Cart" Sidebar
        const cartSidebar = document.getElementById('cart-sidebar');
        const closeCartSidebarBtn = document.getElementById('close-cart-sidebar');

        // --- Functions to control modals ---
        function openSelectValueModal(productName) {
            selectValueTitle.textContent = `Select Value (${productName})`;
            selectValueModal.classList.add('open');
            backdrop.classList.add('open');
        }

        function closeSelectValueModal() {
            selectValueModal.classList.remove('open');
            backdrop.classList.remove('open');
        }

        function openCartSidebar() {
            cartSidebar.classList.add('open');
            backdrop.classList.add('open');
        }

        function closeCartSidebar() {
            cartSidebar.classList.remove('open');
            backdrop.classList.remove('open');
        }

        // --- Event Listeners ---

        // 1. Listen for clicks on "Choose Amount" buttons
        document.querySelectorAll('.choose-amount-btn').forEach(button => {
            button.addEventListener('click', () => {
                const productName = button.getAttribute('data-product-name');
                // TODO: In a real app, you would use this 'productName' or 'data-product-id'
                // to make an AJAX call to fetch the *actual* values for this product.
                // For this demo, we just open the modal.
                openSelectValueModal(productName);
            });
        });

        // 2. Listen for clicks on "Add to Cart" (inside "Select Value" modal)
        document.querySelectorAll('.add-to-cart-btn').forEach(button => {
            button.addEventListener('click', () => {
                // TODO: In a real app, this would trigger an AJAX call to
                // a PHP script (e.g., `add_to_cart.php`) to update the $_SESSION['cart'].
                
                // For this demo, we just follow the visual flow:
                closeSelectValueModal();
                openCartSidebar();
            });
        });

        // 3. Listen for clicks on "Close" buttons
        closeSelectValueBtn.addEventListener('click', closeSelectValueModal);
        closeCartSidebarBtn.addEventListener('click', closeCartSidebar);

        // 4. Listen for click on backdrop (to close modals)
        backdrop.addEventListener('click', () => {
            closeSelectValueModal();
            closeCartSidebar();
        });

        // 5. The "Checkout" button in the cart just links to checkout.php
        // No extra JS needed for that as it's an <a> tag.

    </script>
</body>
</html>