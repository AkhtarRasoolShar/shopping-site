<?php
/*
=========================================================
 File: premium_gifting.php (FIXED: More robust gift_amount handling)
 Description: Premium Gifting page with multi-step form.
 Location: /premium_gifting.php
=========================================================
*/
session_start();
require_once 'db.php';

// List of Countries (same as checkout.php for consistency)
$countries = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda",
    "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas",
    "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize",
    "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil",
    "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia",
    "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China",
    "Colombia", "Comoros", "Congo (Brazzaville)", "Congo (Kinshasa)", "Costa Rica",
    "Croatia", "Cuba", "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica",
    "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea",
    "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France",
    "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada",
    "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras",
    "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland",
    "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya",
    "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan",
    "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein",
    "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives",
    "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico",
    "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco",
    "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands",
    "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway",
    "Oman", "Pakistan", "Palau", "Palestine State", "Panama", "Papua New Guinea",
    "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
    "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines",
    "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal",
    "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia",
    "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain",
    "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria",
    "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo",
    "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu",
    "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States",
    "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam",
    "Yemen", "Zambia", "Zimbabwe"
];
// No $conn->close() here!
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Gifting - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-premium-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-premium-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .form-section-premium {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .form-section-title-premium {
            display: flex;
            align-items: center;
            font-weight: 600;
            color: #4b5563;
            margin-bottom: 1rem;
            border-bottom: 1px solid #e5e7eb;
            padding-bottom: 0.5rem;
        }
        .form-section-number-premium {
            background-color: #e9d5ff;
            color: #5b21b6;
            border-radius: 9999px;
            width: 1.75rem;
            height: 1.75rem;
            min-width: 1.75rem;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            margin-right: 0.75rem;
            flex-shrink: 0;
        }
        .amount-btn-premium, .package-option {
            border: 1px solid #d1d5db;
            padding: 0.75rem 1rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: all 0.2s ease;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .amount-btn-premium:hover, .package-option:hover {
            background-color: #f3f4f6;
        }
        .amount-btn-premium.active, .package-option.active {
            border-color: #5b21b6;
            background-color: #6d28d9;
            color: white;
            font-weight: 600;
        }
        .package-option.active img {
            filter: brightness(0) invert(1); /* Invert colors for active state */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-premium-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Premium Gifting</h1>
                <p class="mt-2 text-lg text-purple-200">
                    Send Physical Gift Cards to your Friends & Relatives in Pakistan!
                </p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <?php if (isset($_SESSION['premium_success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($_SESSION['premium_success']); ?>
                </div>
                <?php unset($_SESSION['premium_success']); ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['premium_error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($_SESSION['premium_error']); ?>
                </div>
                <?php unset($_SESSION['premium_error']); ?>
            <?php endif; ?>

            <form action="process_premium_gifting.php" method="POST" enctype="multipart/form-data" class="grid lg:grid-cols-2 gap-8">
                <div>
                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">1</span> How much would you like to gift?
                        </h2>
                        <div class="flex flex-wrap gap-2 justify-center mb-4">
                            <button type="button" class="amount-btn-premium active" data-amount="1000">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=1,000+PKR" alt="1000 PKR Gift Card">
                                <span class="mt-2">PKR 1,000</span>
                            </button>
                            <button type="button" class="amount-btn-premium" data-amount="2000">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=2,000+PKR" alt="2000 PKR Gift Card">
                                <span class="mt-2">PKR 2,000</span>
                            </button>
                            <button type="button" class="amount-btn-premium" data-amount="5000">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=5,000+PKR" alt="5000 PKR Gift Card">
                                <span class="mt-2">PKR 5,000</span>
                            </button>
                            <button type="button" class="amount-btn-premium" data-amount="10000">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=10,000+PKR" alt="10000 PKR Gift Card">
                                <span class="mt-2">PKR 10,000</span>
                            </button>
                            <button type="button" class="amount-btn-premium" data-amount="20000">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=20,000+PKR" alt="20000 PKR Gift Card">
                                <span class="mt-2">PKR 20,000</span>
                            </button>
                        </div>
                        <input type="hidden" name="gift_amount" id="premium-gift-amount" value="1000">
                    </div>

                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">2</span> Your (Gift Sender) Details
                        </h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="sender_name" class="block text-sm font-medium text-gray-700 mb-1">Your Name</label>
                                <input type="text" name="sender_name" id="sender_name" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                            <div>
                                <label for="sender_mobile" class="block text-sm font-medium text-gray-700 mb-1">Mobile No.</label>
                                <input type="tel" name="sender_mobile" id="sender_mobile" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" placeholder="E.g. 03XX-XXXXXXX" required>
                            </div>
                            <div class="md:col-span-2">
                                <label for="sender_email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                                <input type="email" name="sender_email" id="sender_email" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                            <div>
                                <label for="sender_country" class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                                <select name="sender_country" id="sender_country" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                                    <?php foreach ($countries as $country): ?>
                                        <option value="<?= htmlspecialchars($country) ?>" <?= ($country == 'Pakistan') ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($country) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="sender_city" class="block text-sm font-medium text-gray-700 mb-1">City</label>
                                <input type="text" name="sender_city" id="sender_city" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                             <div class="md:col-span-2">
                                <label for="sender_address" class="block text-sm font-medium text-gray-700 mb-1">Your Address</label>
                                <textarea name="sender_address" id="sender_address" rows="2" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">3</span> Your Friend / Relative (Gift Receiver) Details
                        </h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="receiver_name" class="block text-sm font-medium text-gray-700 mb-1">Receiver's Name</label>
                                <input type="text" name="receiver_name" id="receiver_name" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                            <div>
                                <label for="receiver_mobile" class="block text-sm font-medium text-gray-700 mb-1">Receiver's Mobile No.</label>
                                <input type="tel" name="receiver_mobile" id="receiver_mobile" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                            <div class="md:col-span-2">
                                <label for="receiver_email" class="block text-sm font-medium text-gray-700 mb-1">Receiver's Email</label>
                                <input type="email" name="receiver_email" id="receiver_email" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700">
                            </div>
                             <div>
                                <label for="receiver_country" class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                                <select name="receiver_country" id="receiver_country" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                                    <?php foreach ($countries as $country): ?>
                                        <option value="<?= htmlspecialchars($country) ?>" <?= ($country == 'Pakistan') ? 'selected' : '' ?>>
                                            <?= htmlspecialchars($country) ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div>
                                <label for="receiver_city" class="block text-sm font-medium text-gray-700 mb-1">City</label>
                                <input type="text" name="receiver_city" id="receiver_city" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required>
                            </div>
                            <div class="md:col-span-2">
                                <label for="receiver_address" class="block text-sm font-medium text-gray-700 mb-1">Receiver's Full Address</label>
                                <textarea name="receiver_address" id="receiver_address" rows="2" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" required></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div>
                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">4</span> Location Packages
                        </h2>
                        <div class="grid grid-cols-2 gap-4">
                            <button type="button" class="package-option active" data-package-type="silver">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=Silver" alt="Silver Package">
                                <span class="mt-2 text-sm">Silver Package</span>
                            </button>
                            <button type="button" class="package-option" data-package-type="gold">
                                <img src="https://placehold.co/100x60/8b5cf6/ffffff?text=Gold" alt="Gold Package">
                                <span class="mt-2 text-sm">Gold Package</span>
                            </button>
                        </div>
                        <input type="hidden" name="location_package" id="location-package-input" value="silver">
                    </div>

                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">5</span> Add Message
                        </h2>
                        <label for="premium_message" class="block text-sm font-medium text-gray-700 mb-1">Write your message</label>
                        <textarea name="premium_message" id="premium_message" rows="3" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700" placeholder="Say hi to your loved ones."></textarea>
                    </div>

                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">6</span> Attach Photo (Optional)
                        </h2>
                        <label for="attach_photo" class="block text-sm font-medium text-gray-700 mb-1">Upload Photo</label>
                        <input type="file" name="attach_photo" id="attach_photo" accept="image/*" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700">
                        <p class="text-xs text-gray-500 mt-1">Accepted formats: JPG, PNG. Max file size: 2MB.</p>
                    </div>

                    <div class="form-section-premium">
                        <h2 class="form-section-title-premium">
                            <span class="form-section-number-premium">7</span> Payment & Billing
                        </h2>
                        <p class="text-gray-600 mb-4">Your final amount will be calculated at checkout based on gift value and selected package.</p>
                        <div class="text-center">
                            <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg text-lg">
                                Proceed to Checkout &rarr;
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();

        document.addEventListener('DOMContentLoaded', function() {
            // Amount selection
            const amountButtons = document.querySelectorAll('.amount-btn-premium');
            const giftAmountInput = document.getElementById('premium-gift-amount');

            // Set initial active state for amount button based on default value or active class
            let initialAmount = '1000'; // Default initial amount
            const activeAmountButton = document.querySelector('.amount-btn-premium.active');
            if (activeAmountButton) {
                initialAmount = activeAmountButton.dataset.amount;
            }
            giftAmountInput.value = initialAmount;

            amountButtons.forEach(button => {
                button.addEventListener('click', () => {
                    amountButtons.forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');
                    giftAmountInput.value = button.dataset.amount;
                });
            });


            // Location Package selection
            const packageOptions = document.querySelectorAll('.package-option');
            const locationPackageInput = document.getElementById('location-package-input');

            packageOptions.forEach(option => {
                option.addEventListener('click', () => {
                    packageOptions.forEach(opt => {
                        opt.classList.remove('active');
                        // Reset image filter for non-active
                        const img = opt.querySelector('img');
                        if (img) img.style.filter = '';
                    });
                    option.classList.add('active');
                    locationPackageInput.value = option.dataset.packageType;
                    // Apply image filter for active
                    const img = option.querySelector('img');
                    if (img) img.style.filter = 'brightness(0) invert(1)';
                });
            });

            // Set initial active state for package option
            if (locationPackageInput.value) {
                const initialActivePackage = document.querySelector(`.package-option[data-package-type="${locationPackageInput.value}"]`);
                if (initialActivePackage) {
                    initialActivePackage.classList.add('active');
                    const img = initialActivePackage.querySelector('img');
                    if (img) img.style.filter = 'brightness(0) invert(1)';
                }
            } else {
                 // Set a default if not already set (e.g., 'silver')
                locationPackageInput.value = 'silver';
                const defaultPackageBtn = document.querySelector('.package-option[data-package-type="silver"]');
                if (defaultPackageBtn) {
                    defaultPackageBtn.classList.add('active');
                    const img = defaultPackageBtn.querySelector('img');
                    if (img) img.style.filter = 'brightness(0) invert(1)';
                }
            }
        });
    </script>
</body>
</html>
