<?php
/*
=========================================================
 File: category_products.php (FIXED: Product Display Design)
 Description: Displays products for a specific category.
 Location: /category_products.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure database connection is included.

$category_name = $_GET['name'] ?? '';
$products = [];
$products_found_count = 0;

if (!empty($category_name)) {
    // Sanitize category name for SQL query
    $category_name_safe = $conn->real_escape_string($category_name);

    // Fetch products for the specified category
    $sql_products = "SELECT id, name, category, image, price, tags FROM products WHERE category = '{$category_name_safe}' ORDER BY name ASC";
    $result_products = $conn->query($sql_products);

    if ($result_products && $result_products->num_rows > 0) {
        $products = $result_products->fetch_all(MYSQLI_ASSOC);
        $products_found_count = $result_products->num_rows;
        // Decode tags if stored as JSON
        foreach ($products as &$product) {
            $product['tags'] = json_decode($product['tags'] ?? '[]', true);
        }
    }
}
// IMPORTANT: DO NOT CLOSE THE CONNECTION HERE!
// The connection is still needed by `header.php`.
// $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Category: <?= htmlspecialchars($category_name) ?> - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .product-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.2s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .product-card .tags {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            z-index: 10;
            display: flex; /* Use flex for stacked tags */
            flex-direction: column; /* Stack tags vertically */
            align-items: flex-start; /* Align tags to the start */
            gap: 0.25rem; /* Space between tags */
        }
        .product-card .tag-item {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 9999px; /* rounded-full */
            font-size: 0.75rem; /* text-xs */
            font-weight: 600; /* font-semibold */
            white-space: nowrap; /* Prevent text wrapping */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Category: <?= htmlspecialchars($category_name) ?></h1>

        <?php if (empty($products)): ?>
            <div class="bg-white rounded-lg shadow-md p-8 text-center">
                <i data-lucide="package-x" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-xl font-semibold text-gray-700">No Products Found</h2>
                <p class="text-gray-500 mt-2">There are currently no products available in this category.</p>
                <a href="categories.php" class="mt-6 inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">
                    ← Back to All Categories
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="block relative">
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-40 object-cover rounded-t-lg" onerror="this.onerror=null;this.src='https://placehold.co/400x300/e2e8f0/4a5568?text=Image+Not+Found';">
                            <div class="tags">
                                <?php if (!empty($product['tags'])): ?>
                                    <?php foreach ($product['tags'] as $tag): ?>
                                        <span class="tag-item <?= strpos($tag, 'Online') !== false ? 'bg-blue-100 text-blue-800' : (strpos($tag, '% Off') !== false ? 'bg-red-100 text-red-800' : 'bg-gray-200 text-gray-700') ?>">
                                            <?= htmlspecialchars($tag) ?>
                                        </span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="p-3">
                                <h3 class="text-md font-semibold text-gray-900 truncate"><?= htmlspecialchars($product['name']) ?></h3>
                                <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                                <p class="text-md font-bold text-purple-700 mt-2">PKR <?= number_format($product['price'], 2) ?></p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
