
<?php
/*
=========================================================
 File: logout_user.php
 Description: Destroys the user session.
 Location: /logout_user.php
=========================================================
*/
session_start();

$_SESSION = array();

session_destroy();

header("location: index.php");
exit;
?>
