<?php
/*
=========================================================
 File: order_success.php (FIXED & REDESIGNED)
 Description: Confirmation page after a successful order.
 Location: /order_success.php
=========================================================
*/
session_start();
require_once 'db.php';

if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// CORRECTED: Use lowercase 'order_id' to match the URL parameter.
$order_id = filter_input(INPUT_GET, 'order_id', FILTER_VALIDATE_INT);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Successful - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div class="max-w-2xl mx-auto bg-white rounded-lg shadow-lg p-8 md:p-12 text-center">
            <div class="mx-auto bg-green-100 rounded-full h-20 w-20 flex items-center justify-center">
                <i data-lucide="check-circle" class="w-12 h-12 text-green-600"></i>
            </div>
            <h1 class="text-3xl font-bold text-gray-800 mt-6">Thank You For Your Order!</h1>
            <p class="text-gray-600 mt-2">Your order has been placed successfully and is being processed.</p>

            <?php if ($order_id): ?>
                <div class="mt-6 bg-gray-50 border border-dashed rounded-lg p-4">
                    <p class="text-gray-600">Your Order ID is:</p>
                    <p class="text-2xl font-mono font-bold text-purple-700 mt-1">#<?= htmlspecialchars($order_id) ?></p>
                </div>
            <?php endif; ?>

            <a href="index.php" class="mt-8 inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg transition-colors">
                Continue Shopping
            </a>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
