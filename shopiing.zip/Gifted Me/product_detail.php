<?php
/*
=========================================================
 File: product_detail.php (REFINED DESIGN & INPUT NAME FIXED)
 Description: Displays product details with a new multi-step order form.
 Location: /product_detail.php
=========================================================
*/
session_start();
require_once 'db.php';

$product = null;
$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($product_id) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $product = $result->fetch_assoc();
        // Assuming 'tags' column exists and stores JSON. If not, remove this line.
        $product['tags'] = json_decode($product['tags'] ?? '[]', true);
    }
    $stmt->close();
}

$page_title = $product ? htmlspecialchars($product['name']) : "Product Not Found";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?> - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-product-header {
            background: linear-gradient(to right, #6d28d9, #8b5cf6); /* Deep purple to lighter purple gradient */
            padding-top: 3rem; /* Adjusted from header */
            padding-bottom: 3rem;
            text-align: center;
        }
        .form-section {
            background-color: #f9fafb;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .form-section-title {
            display: flex;
            align-items: center;
            font-weight: 600;
            color: #4b5563;
            margin-bottom: 1rem;
        }
        .form-section-number {
            background-color: #e9d5ff;
            color: #5b21b6;
            border-radius: 9999px;
            width: 1.75rem;
            height: 1.75rem;
            min-width: 1.75rem; /* Ensure it doesn't shrink */
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            margin-right: 0.75rem;
            flex-shrink: 0; /* Prevent it from shrinking */
        }
        .amount-btn, .gift-type-btn {
            border: 1px solid #d1d5db;
            padding: 0.5rem 1rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: all 0.2s ease;
            white-space: nowrap; /* Prevent text wrapping */
        }
        .amount-btn:hover, .gift-type-btn:hover {
            background-color: #f3f4f6;
        }
        .amount-btn.active, .gift-type-btn.active {
            border-color: #5b21b6;
            background-color: #6d28d9;
            color: white;
            font-weight: 600;
        }
        .greeting-card {
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.2s ease;
            border-radius: 0.375rem;
            max-width: 100%; /* Ensure images fit */
            height: auto;
        }
        .greeting-card.selected {
            border-color: #5b21b6;
        }

        /* Specific styles for the Schedule section (Section 7) */
        #schedule-later-options {
            display: none; /* Hidden by default */
            margin-top: 1rem;
            padding-left: 2.5rem; /* Indent under the radio button */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <?php if ($product): ?>
            <div class="hero-product-header text-white">
                <h1 class="text-3xl font-bold"><?= $page_title ?></h1>
                <p class="text-purple-200 mt-1">One card, countless choices!</p>
            </div>
            <form action="cart_handler.php" method="post" class="container mx-auto px-4 sm:px-6 lg:px-8 -mt-12 mb-12 relative z-10 bg-white rounded-lg shadow-lg p-8">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="schedule_type" id="schedule-type-input" value="send_immediately">
                <input type="hidden" name="delivery_type" id="delivery-type-input" value="digital">


                <div class="grid lg:grid-cols-2 gap-8">
                    <div>
                        <div class="form-section">
                            <h2 class="form-section-title"><span class="form-section-number">1</span> Gift Friend/Relative or Gift Yourself?</h2>
                            <div class="flex space-x-2">
                                <button type="button" id="gift-friend-btn" class="flex-1 gift-type-btn active">Gift Friend/Relative</button>
                                <button type="button" id="gift-self-btn" class="flex-1 gift-type-btn">Gift Yourself</button>
                            </div>
                        </div>

                        <div class="form-section">
                            <h2 class="form-section-title"><span class="form-section-number">2</span> How much would you like to gift?</h2>
                            <div class="flex items-center justify-between space-x-2 mb-4">
                                <button type="button" class="amount-btn" data-amount="1000">1,000</button>
                                <button type="button" class="amount-btn" data-amount="3000">3,000</button>
                                <button type="button" class="amount-btn active" data-amount="5000">5,000</button>
                                <button type="button" class="amount-btn" data-amount="10000">10,000</button>
                                <button type="button" class="amount-btn" data-amount="20000">20,000</button>
                            </div>
                            <p class="text-center text-gray-500 my-2">or Enter Your Amount</p>
                            <input type="number" name="quantity" id="amount-input" value="5000" placeholder="Amount" class="w-full border-gray-300 rounded-lg shadow-sm text-center font-bold text-xl p-2">
                            <div class="flex items-center justify-center mt-4">
                                <button type="button" class="flex items-center text-purple-600 hover:text-purple-800 text-sm">
                                    <i data-lucide="calculator" class="w-4 h-4 mr-1"></i>Currency Calculator
                                </button>
                            </div>
                        </div>

                        <div class="mt-8 bg-gray-50 rounded-lg overflow-hidden border border-gray-200 p-4 flex justify-center items-center">
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="max-w-xs max-h-64 object-contain">
                        </div>

                        <div class="form-section mt-8">
                            <h2 class="form-section-title"><span class="form-section-number">3</span> Personalize Your Gift</h2>
                            <label for="occasion" class="block text-sm font-medium text-gray-700">Select Occasion</label>
                            <select name="occasion" id="occasion" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                                <option>Birthday</option>
                                <option>Thank You</option>
                                <option>Congratulations</option>
                                <option>Engagement</option>
                                <option>Baby Shower</option>
                                <option>Wedding</option>
                                <option>Anniversary</option>
                                <option>Valentines</option>
                                <option>Farewell</option>
                                <option>Eid</option>
                                <option>Mother's Day</option>
                                <option>Father's Day</option>
                                <option>Women's Day</option>
                                <option>Happy New Year</option>
                                <option>International Men's Day</option>
                                <option>Others</option>
                            </select>
                            <label for="message" class="mt-4 block text-sm font-medium text-gray-700">Write your message</label>
                            <textarea name="message" id="message" rows="3" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm" placeholder="Say hi to your loved ones."></textarea>
                            <label class="mt-4 block text-sm font-medium text-gray-700">Select Greeting Card</label>
                            <div class="mt-2 grid grid-cols-5 gap-2">
                                <img src="https://placehold.co/80x100/dbeafe/3b82f6?text=Card1" class="greeting-card selected">
                                <img src="https://placehold.co/80x100/fecdd3/be123c?text=Card2" class="greeting-card">
                                <img src="https://placehold.co/80x100/d1fae5/059669?text=Card3" class="greeting-card">
                                <img src="https://placehold.co/80x100/fef3c7/d97706?text=Card4" class="greeting-card">
                                <img src="https://placehold.co/80x100/fce7f3/db2777?text=Card5" class="greeting-card">
                            </div>
                        </div>
                    </div>

                    <div>
                        <div class="form-section">
                            <h2 class="form-section-title"><span class="form-section-number">4</span> Your (Gift Sender) Details</h2>
                            <div class="grid grid-cols-2 gap-4">
                                <div><label for="sender_name" class="block text-sm font-medium text-gray-700">Your Name</label><input type="text" name="sender_name" id="sender_name" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm"></div>
                                <div><label for="sender_email" class="block text-sm font-medium text-gray-700">Your Email Address</label><input type="email" name="sender_email" id="sender_email" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm"></div>
                                <div><label for="sender_country_code" class="block text-sm font-medium text-gray-700">Country Code</label><input type="text" name="sender_country_code" id="sender_country_code" value="Pakistan (+92)" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm bg-gray-100" readonly></div>
                                <div><label for="sender_mobile" class="block text-sm font-medium text-gray-700">Mobile No.</label><input type="tel" name="sender_mobile" id="sender_mobile" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm" placeholder="E.g. 3331234567"></div>
                            </div>
                        </div>

                        <div id="receiver-details-section" class="form-section">
                            <h2 class="form-section-title"><span class="form-section-number">5</span> Your Friend / Relative (Gift Receiver) Details</h2>
                            <div class="grid grid-cols-2 gap-4">
                                <div><label for="receiver_name" class="block text-sm font-medium text-gray-700">Receiver's Name</label><input type="text" name="receiver_name" id="receiver_name" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm"></div>
                                <div><label for="receiver_email" class="block text-sm font-medium text-gray-700">Receiver's Email</label><input type="email" name="receiver_email" id="receiver_email" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm"></div>
                                <div><label for="receiver_country_code" class="block text-sm font-medium text-gray-700">Receiver's Country Code</label><input type="text" name="receiver_country_code" id="receiver_country_code" value="Pakistan (+92)" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm bg-gray-100" readonly></div>
                                <div><label for="receiver_mobile" class="block text-sm font-medium text-gray-700">Receiver's Mobile No.</label><input type="tel" name="receiver_mobile" id="receiver_mobile" class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm"></div>
                            </div>
                        </div>

                        <div class="form-section">
                            <h2 class="form-section-title"><span class="form-section-number">6</span> Delivery Options</h2>
                             <div class="flex flex-col space-y-3">
                                <label class="flex items-center">
                                    <input type="radio" name="delivery_option" value="digital" id="delivery-digital" checked class="form-radio h-4 w-4 text-purple-600">
                                    <span class="ml-2 font-medium text-gray-700">Digital E-Gift Card</span>
                                    <p class="text-sm text-gray-500 ml-4">Received on your provided email.</p>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="delivery_option" value="physical" id="delivery-physical" class="form-radio h-4 w-4 text-purple-600">
                                    <span class="ml-2 font-medium text-gray-700">Physical E-Gift Card</span>
                                    <p class="text-sm text-gray-500 ml-4">Delivered on your provided location.</p>
                                </label>
                            </div>
                        </div>

                        <div class="form-section">
                            <h2 class="form-section-title">
                                <span class="form-section-number">7</span> Schedule Your E-Gift Card
                                <span class="ml-2 text-purple-600 font-semibold text-sm">New Feature</span>
                            </h2>
                            <div class="flex flex-col space-y-3">
                                <label class="flex items-center">
                                    <input type="radio" name="schedule_option" value="immediately" id="schedule-immediately" checked class="form-radio h-4 w-4 text-purple-600">
                                    <span class="ml-2 font-medium text-gray-700">Send immediately</span>
                                </label>
                                <label class="flex items-center">
                                    <input type="radio" name="schedule_option" value="later" id="schedule-later" class="form-radio h-4 w-4 text-purple-600">
                                    <span class="ml-2 font-medium text-gray-700">Schedule for later</span>
                                </label>
                            </div>
                            <div id="schedule-later-options">
                                <label for="schedule_date" class="block text-sm font-medium text-gray-700 mb-2">Schedule Date:</label>
                                <input type="date" name="schedule_date" id="schedule_date" class="w-full border-gray-300 rounded-lg shadow-sm p-2" placeholder="dd/mm/yyyy">
                                <p class="mt-4 text-sm text-gray-600 flex items-start">
                                    <i data-lucide="info" class="w-4 h-4 text-blue-500 mr-2 flex-shrink-0 mt-1"></i>
                                    If you use this option, an automated Email & SMS (with E-Gift Card) will be sent to your Friend / Relative on Scheduled Date. You can schedule your E-Gift Card for upto 6 months (i.e. 20-Jan-2026)
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center mt-8">
                    <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg text-lg">Add to Cart &rarr;</button>
                </div>
            </form>
        <?php else: ?>
            <div class="text-center py-20">
                <h1 class="text-3xl font-bold text-gray-800">Product Not Found</h1>
                <p class="mt-4 text-gray-600">The product you are looking for does not exist or is unavailable.</p>
                <a href="products.php" class="mt-6 inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">Browse All Products</a>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; // Make sure footer.php exists or copy footer content directly here ?>

    <script>
        lucide.createIcons();

        document.addEventListener('DOMContentLoaded', function() {
            // --- Gift Type Selection (Friend/Self) ---
            const giftFriendBtn = document.getElementById('gift-friend-btn');
            const giftSelfBtn = document.getElementById('gift-self-btn');
            const receiverSection = document.getElementById('receiver-details-section');

            // Set initial state based on 'active' class on page load
            if (giftFriendBtn.classList.contains('active')) {
                receiverSection.style.display = 'block';
            } else if (giftSelfBtn.classList.contains('active')) {
                receiverSection.style.display = 'none';
            }

            giftFriendBtn.addEventListener('click', () => {
                receiverSection.style.display = 'block';
                giftFriendBtn.classList.add('active');
                giftSelfBtn.classList.remove('active');
            });

            giftSelfBtn.addEventListener('click', () => {
                receiverSection.style.display = 'none';
                giftSelfBtn.classList.add('active');
                giftFriendBtn.classList.remove('active');
            });

            // --- Amount Selection ---
            const amountButtons = document.querySelectorAll('.amount-btn');
            const amountInput = document.getElementById('amount-input');

            // Set initial value based on active button or default
            if (document.querySelector('.amount-btn.active')) {
                amountInput.value = document.querySelector('.amount-btn.active').dataset.amount;
            } else {
                // If no active button, default to input's initial value
                amountInput.value = amountInput.value || 5000; // Fallback default
            }


            amountButtons.forEach(button => {
                button.addEventListener('click', () => {
                    amountButtons.forEach(btn => btn.classList.remove('active'));
                    button.classList.add('active');
                    amountInput.value = button.dataset.amount;
                });
            });

            amountInput.addEventListener('input', () => {
                 amountButtons.forEach(btn => {
                    if (btn.dataset.amount === amountInput.value) {
                        btn.classList.add('active');
                    } else {
                        btn.classList.remove('active');
                    }
                 });
            });

            // --- Greeting Card Selection ---
            const greetingCards = document.querySelectorAll('.greeting-card');
            greetingCards.forEach(card => {
                card.addEventListener('click', () => {
                    greetingCards.forEach(c => c.classList.remove('selected'));
                    card.classList.add('selected');
                });
            });

            // --- Schedule Option ---
            const scheduleImmediately = document.getElementById('schedule-immediately');
            const scheduleLater = document.getElementById('schedule-later');
            const scheduleLaterOptions = document.getElementById('schedule-later-options');
            const scheduleTypeInput = document.getElementById('schedule-type-input'); // Hidden input for form submission

            // Initial state
            if (scheduleLater.checked) {
                scheduleLaterOptions.style.display = 'block';
            } else {
                scheduleLaterOptions.style.display = 'none';
            }

            scheduleImmediately.addEventListener('change', () => {
                if (scheduleImmediately.checked) {
                    scheduleLaterOptions.style.display = 'none';
                    scheduleTypeInput.value = 'send_immediately';
                }
            });

            scheduleLater.addEventListener('change', () => {
                if (scheduleLater.checked) {
                    scheduleLaterOptions.style.display = 'block';
                    scheduleTypeInput.value = 'schedule_for_later';
                }
            });

            // --- Delivery Option ---
            const deliveryDigital = document.getElementById('delivery-digital');
            const deliveryPhysical = document.getElementById('delivery-physical');
            const deliveryTypeInput = document.getElementById('delivery-type-input'); // Hidden input for form submission

            deliveryDigital.addEventListener('change', () => {
                if (deliveryDigital.checked) {
                    deliveryTypeInput.value = 'digital';
                }
            });

            deliveryPhysical.addEventListener('change', () => {
                if (deliveryPhysical.checked) {
                    deliveryTypeInput.value = 'physical';
                }
            });
        });
    </script>
</body>
</html>
