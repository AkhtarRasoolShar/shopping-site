<?php
/*
=========================================================
 File: terms_conditions.php (NEW)
 Description: Terms and Conditions page for Gifted Me.
 Location: /terms_conditions.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Terms & Conditions - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-terms-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-terms-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .policy-section-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-bottom: 2rem;
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-terms-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Terms & Conditions</h1>
                <p class="mt-2 text-lg text-purple-200">Please read carefully before using our services.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="policy-section-card">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">1. Acceptance of Terms</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    By accessing and using the Gifted Me website (giftkarte.com) and its services, you agree to be bound by these Terms & Conditions ("Terms"). If you do not agree to these Terms, please do not use our services. We reserve the right to modify these Terms at any time, and your continued use signifies your acceptance of any changes.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">2. Services Offered</h2>
                <p class="text-gray-700 leading-relaxed mb-2">Gifted Me provides a platform for:</p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>Purchasing and sending digital E-Gift Cards from various partner brands.</li>
                    <li>Personalizing gift cards with messages and designs.</li>
                    <li>Scheduling gift card delivery for future dates.</li>
                    <li>Facilitating corporate gifting solutions.</li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">3. User Accounts</h2>
                <p class="text-gray-700 leading-relaxed mb-2">
                    To access certain features of the Site, you may be required to register for an account. You agree to:
                </p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>Provide accurate, current, and complete information during registration.</li>
                    <li>Maintain the security of your password and identification.</li>
                    <li>Be fully responsible for all activities that occur under your account.</li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">4. E-Gift Card Purchase and Redemption</h2>
                <p class="text-gray-700 leading-relaxed mb-2">
                    **Purchase:** All E-Gift Card purchases are final. Please review your order carefully before completing the transaction. Prices are subject to change.
                </p>
                <p class="text-gray-700 leading-relaxed mb-2">
                    **Redemption:** E-Gift Cards are redeemable for merchandise or services at the specified partner brand. Redemption is subject to the terms and conditions of the issuing brand. Gifted Me is not responsible for any issues arising from the partner brand's policies or operations.
                </p>
                <p class="text-gray-700 leading-relaxed mb-4">
                    E-Gift Cards cannot be redeemed for cash, reloaded, or returned for a refund, unless required by law.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">5. Prohibited Activities</h2>
                <p class="text-gray-700 leading-relaxed mb-2">You may not access or use the Site for any purpose other than that for which Gifted Me makes it available. Prohibited activities include, but are not limited to:</p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>Systematically retrieving data or other content from the Site to create or compile, directly or indirectly, a collection, compilation, database, or directory without written permission from us.</li>
                    <li>Making any unauthorized use of the Site, including collecting usernames and/or email addresses of users by electronic or other means for the purpose of sending unsolicited email.</li>
                    <li>Engaging in unauthorized framing of or linking to the Site.</li>
                    <li>Interfering with, disrupting, or creating an undue burden on the Site or the networks or services connected to the Site.</li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">6. Disclaimers</h2>
                <p class="text-gray-700 leading-relaxed mb-2">
                    The Site is provided on an AS-IS basis. You agree that your use of the Site and our services will be at your sole risk. To the fullest extent permitted by law, we disclaim all warranties, express or implied, in connection with the Site and your use thereof, including, without limitation, the implied warranties of merchantability, fitness for a particular purpose, and non-infringement.
                </p>
                <p class="text-gray-700 leading-relaxed mb-4">
                    We make no warranties or representations about the accuracy or completeness of the Site’s content or the content of any websites linked to this Site and we will assume no liability or responsibility for any (1) errors, mistakes, or inaccuracies of content and materials, (2) personal injury or property damage, of any nature whatsoever, resulting from your access to and use of the Site, (3) any unauthorized access to or use of our secure servers and/or any and all personal information and/or financial information stored therein.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">7. Limitation of Liability</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    In no event will Gifted Me or its directors, employees, or agents be liable to you or any third party for any direct, indirect, consequential, exemplary, incidental, special, or punitive damages, including lost profit, lost revenue, loss of data, or other damages arising from your use of the Site, even if we have been advised of the possibility of such damages.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">8. Governing Law</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    These Terms are governed by and construed in accordance with the laws of Pakistan. Any dispute arising from these Terms or your use of the Site will be subject to the exclusive jurisdiction of the courts located in Karachi, Pakistan.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">9. Contact Us</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    If you have questions or comments about these Terms & Conditions, please contact us at:
                </p>
                <p class="text-gray-700 font-semibold">Email: info@giftkarte.com</p>
                <p class="text-gray-700 font-semibold">Phone: 021-111-MYGIFT (694438)</p>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
