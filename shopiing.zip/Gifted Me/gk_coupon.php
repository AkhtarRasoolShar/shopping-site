<?php
/*
=========================================================
 File: gk_coupon.php (NEW)
 Description: Placeholder page for GK Coupon (for Corporate Clients).
 Location: /gk_coupon.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure your database connection is included.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GK Coupon - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-gkcoupon-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-gkcoupon-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-gkcoupon-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">GK Coupon</h1>
                <p class="mt-2 text-lg text-purple-200">Exclusive coupon solutions for corporate clients.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                <i data-lucide="coupon" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-3xl font-bold text-gray-800">Content Under Construction</h2>
                <p class="mt-4 text-gray-600">
                    We're working hard to bring you comprehensive details about our GK Coupon program for corporate clients. Please check back soon!
                </p>
                <p class="mt-2 text-gray-500 text-sm">
                    For immediate inquiries, please <a href="corporate_gifting.php" class="text-purple-600 hover:underline">contact our Corporate Gifting team</a>.
                </p>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
