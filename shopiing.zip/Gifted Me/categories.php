<?php
/*
=========================================================
 File: categories.php (FIXED: Removed premature $conn->close())
 Description: Displays categories with icons.
 Location: /categories.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure database connection is included.

// Fetch categories from the database
// You should have a 'categories' table with 'id', 'name' and potentially 'icon_html' or similar
$sql = "SELECT id, name FROM categories ORDER BY name ASC";
$result = $conn->query($sql);

$categories = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Assigning Lucide icons based on category name (customize as needed)
        switch ($row['name']) {
            case 'Emerging Brands':
                $row['icon'] = 'zap'; // Example icon
                break;
            case 'Fashion & Accessories':
                $row['icon'] = 'shirt';
                break;
            case 'General':
                $row['icon'] = 'tag';
                break;
            case 'Home & Furnishing':
                $row['icon'] = 'home';
                break;
            case 'Supermarkets & Dept Store':
                $row['icon'] = 'store';
                break;
            // Add more cases for other categories
            default:
                $row['icon'] = 'gift'; // Default icon
                break;
        }
        $categories[] = $row;
    }
}
// IMPORTANT: REMOVED THIS LINE -> $conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Categories - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .category-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 1.5rem;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .category-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .category-icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 4rem;
            height: 4rem;
            border-radius: 9999px; /* rounded-full */
            margin-bottom: 1rem;
            background-color: #e9d5ff; /* light purple */
        }
        .category-icon-wrapper i {
            color: #5b21b6; /* deep purple */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Browse by Category</h1>

        <?php if (empty($categories)): ?>
            <div class="bg-white rounded-lg shadow-md p-8 text-center">
                <i data-lucide="folder-x" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-xl font-semibold text-gray-700">No Categories Found</h2>
                <p class="text-gray-500 mt-2">Please add categories from the admin panel.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                <?php foreach ($categories as $category): ?>
                    <a href="category_products.php?name=<?= urlencode($category['name']) ?>" class="category-card block">
                        <div class="category-icon-wrapper mx-auto">
                            <i data-lucide="<?= htmlspecialchars($category['icon']) ?>" class="w-8 h-8"></i>
                        </div>
                        <h2 class="text-xl font-semibold text-gray-800"><?= htmlspecialchars($category['name']) ?></h2>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
