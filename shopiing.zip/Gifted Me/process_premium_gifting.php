<?php
/*
=========================================================
 File: process_premium_gifting.php (FINALIZED)
 Description: Processes the Premium Gifting form submission, handles file upload, and saves to database.
 Location: /process_premium_gifting.php
=========================================================
*/
session_start(); // Start the session to use $_SESSION for messages
require_once 'db.php'; // Include the database connection

// --- DEBUGGING START (Remove or comment out in production) ---
// Temporarily enable error reporting to catch any issues during development
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log POST and FILES data to the PHP error log for inspection
error_log("PROCESS PREMIUM GIFTING: Request Method is " . $_SERVER["REQUEST_METHOD"]);
error_log("POST Data: " . print_r($_POST, true));
error_log("FILES Data: " . print_r($_FILES, true));
// --- DEBUGGING END ---


// Check if the user is logged in. If not, redirect to the login page.
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Check if the request method is POST. If not, redirect back to the form page.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 1. Gather and Sanitize Input Data using filter_input and null coalesce operator (??)
    // This helps prevent 'Undefined index' warnings and provides default values.
    $user_id = $_SESSION['user_id'];
    $gift_amount = filter_input(INPUT_POST, 'gift_amount', FILTER_VALIDATE_FLOAT); // Validates as float, returns false if invalid
    $location_package = filter_input(INPUT_POST, 'location_package', FILTER_SANITIZE_STRING);
    $premium_message = filter_input(INPUT_POST, 'premium_message', FILTER_SANITIZE_STRING);

    // Sender Details
    $sender_name = filter_input(INPUT_POST, 'sender_name', FILTER_SANITIZE_STRING);
    $sender_mobile = filter_input(INPUT_POST, 'sender_mobile', FILTER_SANITIZE_STRING);
    $sender_email = filter_input(INPUT_POST, 'sender_email', FILTER_SANITIZE_EMAIL);
    $sender_country = filter_input(INPUT_POST, 'sender_country', FILTER_SANITIZE_STRING);
    $sender_city = filter_input(INPUT_POST, 'sender_city', FILTER_SANITIZE_STRING);
    $sender_address = filter_input(INPUT_POST, 'sender_address', FILTER_SANITIZE_STRING);

    // Receiver Details
    $receiver_name = filter_input(INPUT_POST, 'receiver_name', FILTER_SANITIZE_STRING);
    $receiver_mobile = filter_input(INPUT_POST, 'receiver_mobile', FILTER_SANITIZE_STRING);
    $receiver_email = filter_input(INPUT_POST, 'receiver_email', FILTER_SANITIZE_EMAIL); // Email is optional for receiver
    $receiver_country = filter_input(INPUT_POST, 'receiver_country', FILTER_SANITIZE_STRING);
    $receiver_city = filter_input(INPUT_POST, 'receiver_city', FILTER_SANITIZE_STRING);
    $receiver_address = filter_input(INPUT_POST, 'receiver_address', FILTER_SANITIZE_STRING);

    // Array to store validation errors
    $errors = [];

    // 2. Robust Server-Side Validation
    if ($gift_amount === false || $gift_amount <= 0) {
        $errors[] = 'Gift amount must be a valid positive number.';
    }
    if (empty($location_package)) {
        $errors[] = 'Please select a location package.';
    }
    if (empty($sender_name)) { $errors[] = 'Sender\'s name is required.'; }
    if (empty($sender_mobile)) { $errors[] = 'Sender\'s mobile number is required.'; }
    if (empty($sender_email) || !filter_var($sender_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid sender\'s email address is required.';
    }
    if (empty($sender_country)) { $errors[] = 'Sender\'s country is required.'; }
    if (empty($sender_city)) { $errors[] = 'Sender\'s city is required.'; }
    if (empty($sender_address)) { $errors[] = 'Sender\'s address is required.'; }

    if (empty($receiver_name)) { $errors[] = 'Receiver\'s name is required.'; }
    if (empty($receiver_mobile)) { $errors[] = 'Receiver\'s mobile number is required.'; }
    if (!empty($receiver_email) && !filter_var($receiver_email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'If provided, receiver\'s email must be valid.';
    }
    if (empty($receiver_country)) { $errors[] = 'Receiver\'s country is required.'; }
    if (empty($receiver_city)) { $errors[] = 'Receiver\'s city is required.'; }
    if (empty($receiver_address)) { $errors[] = 'Receiver\'s full address is required.'; }


    // --- Handle Photo Upload (Optional) ---
    $photo_path = null; // Default to null for database
    if (isset($_FILES['attach_photo']) && $_FILES['attach_photo']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "uploads/premium_photos/"; // Relative to the script's location

        // Ensure the directory exists and is writable
        if (!file_exists($target_dir)) {
            if (!mkdir($target_dir, 0777, true)) { // Recursive creation with full permissions
                $errors[] = 'Server error: Failed to create upload directory.';
                error_log("Failed to create directory: " . $target_dir);
            }
        } elseif (!is_writable($target_dir)) {
            $errors[] = 'Server error: Upload directory is not writable.';
            error_log("Directory not writable: " . $target_dir);
        }

        // Proceed with upload if no directory errors
        if (empty($errors)) {
            $file_extension = strtolower(pathinfo($_FILES['attach_photo']['name'], PATHINFO_EXTENSION));
            $unique_filename = uniqid('premium_gift_') . '.' . $file_extension;
            $target_file = $target_dir . $unique_filename;

            // Define allowed file types and max size
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $max_file_size = 2 * 1024 * 1024; // 2MB in bytes

            if (!in_array($file_extension, $allowed_extensions)) {
                $errors[] = 'Invalid photo file type. Only JPG, JPEG, PNG, GIF are allowed.';
            }
            if ($_FILES['attach_photo']['size'] > $max_file_size) {
                $errors[] = 'Photo file size exceeds 2MB limit.';
            }

            if (empty($errors)) { // Check errors again after file specific validation
                if (move_uploaded_file($_FILES["attach_photo"]["tmp_name"], $target_file)) {
                    $photo_path = $target_file;
                } else {
                    $errors[] = 'Failed to upload photo file. Please try again.';
                    error_log("move_uploaded_file failed for " . $_FILES["attach_photo"]["tmp_name"]);
                }
            }
        }
    } elseif (isset($_FILES['attach_photo']) && $_FILES['attach_photo']['error'] != UPLOAD_ERR_NO_FILE) {
        // Handle other general upload errors (e.g., UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE)
        $errors[] = 'An unexpected file upload error occurred: Code ' . $_FILES['attach_photo']['error'];
        error_log("File upload error code: " . $_FILES['attach_photo']['error']);
    }


    // If any validation errors occurred, set session message and redirect
    if (!empty($errors)) {
        $_SESSION['premium_error'] = implode('<br>', $errors);
        header("Location: premium_gifting.php");
        exit;
    }

    // Calculate final total amount (you might apply package costs here if needed)
    $total_amount = $gift_amount; // Assuming package cost is added elsewhere or is 0 for simplicity

    // 3. Begin Database Transaction
    // Transactions ensure that either all database operations complete successfully, or none do.
    $conn->begin_transaction();

    try {
        // Prepare the SQL statement for inserting into premium_orders
        // Ensure your 'premium_orders' table structure matches these columns
        $stmt = $conn->prepare("INSERT INTO premium_orders (user_id, gift_amount, location_package, premium_message, attached_photo_url, sender_name, sender_mobile, sender_email, sender_country, sender_city, sender_address, receiver_name, receiver_mobile, receiver_email, receiver_country, receiver_city, receiver_address, order_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        if ($stmt === false) {
            throw new Exception("Database prepare failed: " . $conn->error);
        }

        // Set initial status for the premium order
        $order_status = 'Pending Premium Review';

        // Bind parameters. 's' for string, 'd' for double (float), 'i' for integer.
        // Ensure the types match your database column types.
        $stmt->bind_param("idssssssssssssssss",
            $user_id,
            $gift_amount,
            $location_package,
            $premium_message,
            $photo_path, // Will be null if no file uploaded
            $sender_name,
            $sender_mobile,
            $sender_email,
            $sender_country,
            $sender_city,
            $sender_address,
            $receiver_name,
            $receiver_mobile,
            $receiver_email, // Can be null in DB
            $receiver_country,
            $receiver_city,
            $receiver_address,
            $order_status
        );

        // Execute the statement
        if (!$stmt->execute()) {
            throw new Exception("Database execute failed: " . $stmt->error);
        }

        $premium_order_id = $stmt->insert_id; // Get the ID of the newly inserted order
        $stmt->close(); // Close the prepared statement

        // Commit the transaction if everything was successful
        $conn->commit();

        // 4. Redirect to a success message on the premium_gifting page or a dedicated success page
        $_SESSION['premium_success'] = 'Your Premium Gifting order (ID: ' . $premium_order_id . ') has been placed successfully. We will contact you soon for further details and payment.';
        header("Location: premium_gifting.php");
        exit;

    } catch (Exception $e) {
        // Rollback the transaction in case of any error within the try block
        $conn->rollback();
        // Log the actual error for server-side debugging (not for user display)
        error_log("Premium Gifting Order Error: " . $e->getMessage());
        $_SESSION['premium_error'] = 'An unexpected error occurred while placing your Premium Gifting order. Please try again.';
        header("Location: premium_gifting.php");
        exit;
    }

} else {
    // If the request method is not POST, redirect them away from direct access.
    header("Location: premium_gifting.php");
    exit;
}
?>
