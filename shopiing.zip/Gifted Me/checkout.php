<?php
/*
=========================================================
 File: checkout.php (UPDATED: Crypto Payment Option)
 Description: User checkout page with payment method selection.
 Location: /checkout.php
=========================================================
*/
session_start();
require_once 'db.php';

// Redirect if not logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_items = [];
$cart_total = 0;

// Fetch cart items
$sql_cart = "SELECT p.id, p.name, p.price, c.quantity FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
if ($stmt_cart = $conn->prepare($sql_cart)) {
    $stmt_cart->bind_param("i", $user_id);
    $stmt_cart->execute();
    $result_cart = $stmt_cart->get_result();
    if ($result_cart->num_rows > 0) {
        while ($row = $result_cart->fetch_assoc()) {
            $cart_items[] = $row;
            $cart_total += $row['price'] * $row['quantity'];
        }
    } else {
        // Redirect to cart if it's empty
        header("location: cart.php");
        exit;
    }
    $stmt_cart->close();
} else {
    // Handle database error
    die("Database query failed: " . $conn->error);
}

// Apply 10% discount
$discount_percentage = 10;
$discount_amount = $cart_total * ($discount_percentage / 100);
$final_total = $cart_total - $discount_amount;


// Fetch user's existing details if available (e.g., from a 'users' table or previous orders)
$user_full_name = '';
$user_address = '';
$user_city = '';
$user_tel = '';

$sql_user_details = "SELECT full_name, address, city, tel FROM users WHERE id = ?"; // Assuming these columns in 'users' table
if ($stmt_user_details = $conn->prepare($sql_user_details)) {
    $stmt_user_details->bind_param("i", $user_id);
    $stmt_user_details->execute();
    $stmt_user_details->bind_result($user_full_name, $user_address, $user_city, $user_tel);
    $stmt_user_details->fetch();
    $stmt_user_details->close();
}

// Check for error message from place_order.php
$error_message = '';
if (isset($_GET['error']) && $_GET['error'] == 1) {
    $error_message = "There was an issue processing your order. Please try again.";
}

// List of Countries
// This list is extensive. For brevity, only a few are shown. Expand as needed.
$countries = [
    "Afghanistan", "Albania", "Algeria", "Andorra", "Angola", "Antigua and Barbuda",
    "Argentina", "Armenia", "Australia", "Austria", "Azerbaijan", "Bahamas",
    "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize",
    "Benin", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Brazil",
    "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia",
    "Cameroon", "Canada", "Central African Republic", "Chad", "Chile", "China",
    "Colombia", "Comoros", "Congo (Brazzaville)", "Congo (Kinshasa)", "Costa Rica",
    "Croatia", "Cuba", "Cyprus", "Czechia", "Denmark", "Djibouti", "Dominica",
    "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea",
    "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Fiji", "Finland", "France",
    "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Greece", "Grenada",
    "Guatemala", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Honduras",
    "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland",
    "Israel", "Italy", "Jamaica", "Japan", "Jordan", "Kazakhstan", "Kenya",
    "Kiribati", "Korea, North", "Korea, South", "Kosovo", "Kuwait", "Kyrgyzstan",
    "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein",
    "Lithuania", "Luxembourg", "Madagascar", "Malawi", "Malaysia", "Maldives",
    "Mali", "Malta", "Marshall Islands", "Mauritania", "Mauritius", "Mexico",
    "Micronesia", "Moldova", "Monaco", "Mongolia", "Montenegro", "Morocco",
    "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands",
    "New Zealand", "Nicaragua", "Niger", "Nigeria", "North Macedonia", "Norway",
    "Oman", "Pakistan", "Palau", "Palestine State", "Panama", "Papua New Guinea",
    "Paraguay", "Peru", "Philippines", "Poland", "Portugal", "Qatar", "Romania",
    "Russia", "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines",
    "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal",
    "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia",
    "Solomon Islands", "Somalia", "South Africa", "South Sudan", "Spain",
    "Sri Lanka", "Sudan", "Suriname", "Sweden", "Switzerland", "Syria",
    "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo",
    "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Tuvalu",
    "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States",
    "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam",
    "Yemen", "Zambia", "Zimbabwe"
];


// IMPORTANT: Do NOT close $conn here. It's needed by header.php.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Checkout</h1>

        <?php if($error_message): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <form action="place_order.php" method="post" enctype="multipart/form-data" class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">1. Billing Details</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="full_name" class="block text-gray-700 text-sm font-bold mb-2">Full Name:</label>
                        <input type="text" name="full_name" id="full_name" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_full_name) ?>" required>
                    </div>
                    <div>
                        <label for="tel" class="block text-gray-700 text-sm font-bold mb-2">Phone Number:</label>
                        <input type="tel" name="tel" id="tel" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_tel) ?>" placeholder="e.g. 03XX-XXXXXXX" required>
                    </div>
                    <div class="md:col-span-2">
                        <label for="address" class="block text-gray-700 text-sm font-bold mb-2">Address:</label>
                        <textarea name="address" id="address" rows="3" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required><?= htmlspecialchars($user_address) ?></textarea>
                    </div>
                    <div>
                        <label for="city" class="block text-gray-700 text-sm font-bold mb-2">City:</label>
                        <input type="text" name="city" id="city" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_city) ?>" required>
                    </div>
                    <div>
                        <label for="country" class="block text-gray-700 text-sm font-bold mb-2">Country:</label>
                        <select name="country" id="country" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                            <?php foreach ($countries as $country): ?>
                                <option value="<?= htmlspecialchars($country) ?>" <?= ($country == 'Pakistan') ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($country) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <h2 class="text-2xl font-bold text-gray-800 mb-6 mt-10">2. Payment Method</h2>
                <div class="space-y-4">
                    <label class="flex items-center p-4 border rounded-lg cursor-pointer bg-blue-50">
                        <input type="radio" name="payment_method" value="Credit / Debit Card" class="form-radio h-5 w-5 text-purple-600" checked>
                        <span class="ml-3 text-lg font-semibold text-gray-800">Credit / Debit Card</span>
                    </label>
                    <div id="card_details" class="p-4 border border-blue-200 rounded-lg bg-blue-50 ml-6 space-y-4">
                        <div>
                            <label for="card_number" class="block text-gray-700 text-sm font-bold mb-2">Card Number:</label>
                            <input type="text" name="card_number" id="card_number" inputmode="numeric" pattern="[0-9\s]{13,19}" autocomplete="cc-number" placeholder="XXXX XXXX XXXX XXXX" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="expiry_date" class="block text-gray-700 text-sm font-bold mb-2">Expiry Date (MM/YY):</label>
                                <input type="text" name="expiry_date" id="expiry_date" pattern="(0[1-9]|1[0-2])\/?([0-9]{2})" autocomplete="cc-exp" placeholder="MM/YY" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                            </div>
                            <div>
                                <label for="cvv" class="block text-gray-700 text-sm font-bold mb-2">CVV:</label>
                                <input type="text" name="cvv" id="cvv" pattern="[0-9]{3,4}" autocomplete="cc-csc" placeholder="XXX" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                            </div>
                        </div>
                        <label class="flex items-center text-gray-700">
                            <input type="checkbox" name="save_card_details" class="form-checkbox h-4 w-4 text-purple-600 rounded">
                            <span class="ml-2 text-sm">Save these card details for future payments</span>
                        </label>
                    </div>

                    <label class="flex items-center p-4 border rounded-lg cursor-pointer bg-gray-50">
                        <input type="radio" name="payment_method" value="Direct Bank Transfer" class="form-radio h-5 w-5 text-purple-600">
                        <span class="ml-3 text-lg font-semibold text-gray-800">Direct Bank Transfer</span>
                    </label>
                    <div id="bank_transfer_details" class="hidden p-4 border border-gray-200 rounded-lg bg-gray-50 ml-6 space-y-4">
                        <p class="text-gray-700">Please transfer the total amount to the following bank account:</p>
                        <p class="text-gray-800 font-semibold">Bank Name: ABC Bank</p>
                        <p class="text-gray-800 font-semibold">Account Title: Gifted Me Pvt Ltd</p>
                        <p class="text-gray-800 font-semibold">Account Number: 1234 5678 9012 3456</p>
                        <p class="text-gray-800 font-semibold">IBAN: PKXX ABCX XXXX XXXX XXXX XXXX</p>
                        <div>
                            <label for="tid" class="block text-gray-700 text-sm font-bold mb-2">Transaction ID / Reference (Optional):</label>
                            <input type="text" name="tid" id="tid" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div>
                            <label for="payment_proof" class="block text-gray-700 text-sm font-bold mb-2">Upload Payment Proof (Screenshot / Photo):</label>
                            <input type="file" name="payment_proof" id="payment_proof" accept="image/*" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                            <p class="text-xs text-gray-500 mt-1">Accepted formats: JPG, PNG, PDF. Max file size: 5MB.</p>
                        </div>
                    </div>

                    <label class="flex items-center p-4 border rounded-lg cursor-pointer bg-green-50">
                        <input type="radio" name="payment_method" value="Crypto Payment" class="form-radio h-5 w-5 text-green-600">
                        <span class="ml-3 text-lg font-semibold text-gray-800">Crypto Payment (Binance)</span>
                    </label>
                    <div id="crypto_details" class="hidden p-4 border border-green-200 rounded-lg bg-green-50 ml-6 space-y-4">
                        <p class="text-sm text-red-700 font-semibold flex items-center">
                            <i data-lucide="alert-triangle" class="w-5 h-5 mr-2"></i> **IMPORTANT: Manual crypto transfers are prone to error. Ensure exact amount and correct address/network.**
                        </p>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <p class="text-gray-700 font-semibold">Bank Name:</p>
                                <p class="text-gray-800">Binance Crypto</p>
                            </div>
                            <div>
                                <p class="text-gray-700 font-semibold">Account Details:</p>
                                <p class="text-gray-800">USDT TRC20</p>
                            </div>
                            <div class="md:col-span-2">
                                <label for="crypto_address" class="block text-gray-700 text-sm font-bold mb-2">Crypto Address:</label>
                                <div class="flex items-center bg-white border border-gray-300 rounded-lg shadow-sm">
                                    <input type="text" id="crypto_address" value="TJpn34wTWaK7Cn3Ykt7upTfa5faCbvyuft" readonly class="flex-1 py-2 px-3 text-gray-700 bg-white">
                                    <button type="button" class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-4 py-2 rounded-r-lg" onclick="copyCryptoAddress()">Copy</button>
                                </div>
                                <p class="text-xs text-gray-500 mt-1">Click to copy the USDT TRC20 address.</p>
                            </div>
                        </div>

                        <div class="border-t border-green-300 pt-4 mt-4">
                            <p class="text-gray-700 font-bold mb-2">Send Direct Payments:</p>
                            <div class="flex space-x-4">
                                <a href="https://www.binance.com/en/pay" target="_blank" class="flex-1 bg-yellow-400 hover:bg-yellow-500 text-gray-800 font-bold py-2 px-4 rounded-lg flex items-center justify-center text-sm">
                                    <i data-lucide="external-link" class="w-4 h-4 mr-2"></i> Pay via Binance App
                                </a>
                                </div>
                             <p class="text-xs text-gray-500 mt-2">Opening the app will initiate a payment. Confirm details before sending.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="lg:col-span-1 bg-white rounded-lg shadow-md p-6 h-fit sticky top-24">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">Order Summary</h2>
                <div class="divide-y divide-gray-200 mb-4">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="flex justify-between items-center py-2">
                            <p class="text-gray-700"><?= htmlspecialchars($item['name']) ?> x <?= htmlspecialchars($item['quantity']) ?></p>
                            <p class="font-semibold">PKR <?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="flex justify-between items-center text-lg font-medium text-gray-700 mb-2">
                    <span>Subtotal:</span>
                    <span>PKR <?= number_format($cart_total, 2) ?></span>
                </div>
                <div class="flex justify-between items-center text-lg font-medium text-gray-700 mb-2">
                    <span>Discount (<?= $discount_percentage ?>%):</span>
                    <span class="text-green-600">- PKR <?= number_format($discount_amount, 2) ?></span>
                </div>
                <div class="flex justify-between items-center text-lg font-medium text-gray-700 mb-4">
                    <span>Shipping:</span>
                    <span>Free</span>
                </div>
                <div class="border-t border-gray-200 pt-4 flex justify-between items-center text-2xl font-bold text-purple-700">
                    <span>Total:</span>
                    <span>PKR <?= number_format($final_total, 2) ?></span>
                </div>
                <button type="submit" class="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg text-center flex items-center justify-center">
                    <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i> Place Order
                </button>
            </div>
        </form>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();

        document.addEventListener('DOMContentLoaded', function() {
            const paymentMethods = document.querySelectorAll('input[name="payment_method"]');
            const cardDetailsDiv = document.getElementById('card_details');
            const bankTransferDetailsDiv = document.getElementById('bank_transfer_details');
            const cryptoDetailsDiv = document.getElementById('crypto_details'); // New

            function togglePaymentDetails() {
                const selectedMethod = document.querySelector('input[name="payment_method"]:checked').value;

                cardDetailsDiv.classList.add('hidden');
                bankTransferDetailsDiv.classList.add('hidden');
                cryptoDetailsDiv.classList.add('hidden'); // Hide new div by default

                if (selectedMethod === 'Credit / Debit Card') {
                    cardDetailsDiv.classList.remove('hidden');
                } else if (selectedMethod === 'Direct Bank Transfer') {
                    bankTransferDetailsDiv.classList.remove('hidden');
                } else if (selectedMethod === 'Crypto Payment') { // New condition
                    cryptoDetailsDiv.classList.remove('hidden');
                }
            }

            paymentMethods.forEach(radio => {
                radio.addEventListener('change', togglePaymentDetails);
            });

            // Set initial state on page load
            togglePaymentDetails();

            // Basic Expiry Date formatting (MM/YY) - client-side
            const expiryInput = document.getElementById('expiry_date');
            if (expiryInput) {
                expiryInput.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, ''); // Remove non-digits
                    if (value.length > 2) {
                        value = value.substring(0, 2) + '/' + value.substring(2, 4);
                    }
                    e.target.value = value;
                });
            }

            // Function to copy Crypto Address (New)
            window.copyCryptoAddress = function() {
                const cryptoAddressInput = document.getElementById('crypto_address');
                cryptoAddressInput.select();
                cryptoAddressInput.setSelectionRange(0, 99999); // For mobile devices
                document.execCommand("copy");
                alert("Crypto address copied to clipboard!");
            };
        });
    </script>
</body>
</html>
