
<?php
/*
=========================================================
 File: login.php (UPDATED)
 Description: Handles user login with a "Forgot Password" link.
 Location: /login.php
=========================================================
*/
session_start();

if(isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true){
    header("location: index.php");
    exit;
}

require_once "db.php";

$email = $password = "";
$email_err = $password_err = $login_err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // (Login logic remains the same)
    if(empty(trim($_POST["email"]))){ $email_err = "Please enter email."; } else { $email = trim($_POST["email"]); }
    if(empty(trim($_POST["password"]))){ $password_err = "Please enter your password."; } else { $password = trim($_POST["password"]); }
    if(empty($email_err) && empty($password_err)){
        $sql = "SELECT id, username, email, password FROM users WHERE email = ?";
        if($stmt = $conn->prepare($sql)){
            $stmt->bind_param("s", $param_email);
            $param_email = $email;
            if($stmt->execute()){
                $stmt->store_result();
                if($stmt->num_rows == 1){
                    $stmt->bind_result($id, $username, $email, $hashed_password);
                    if($stmt->fetch()){
                        if(password_verify($password, $hashed_password)){
                            session_start();
                            $_SESSION["user_loggedin"] = true;
                            $_SESSION["user_id"] = $id;
                            $_SESSION["user_username"] = $username;
                            header("location: index.php");
                        } else{ $login_err = "Invalid email or password."; }
                    }
                } else{ $login_err = "Invalid email or password."; }
            } else{ echo "Oops! Something went wrong."; }
            $stmt->close();
        }
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-2">Welcome Back!</h2>
        <p class="text-center text-gray-500 mb-8">Sign in to your account</p>

        <?php if(!empty($login_err)){ echo '<div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">' . $login_err . '</div>'; } ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                <input type="email" name="email" class="shadow-sm border rounded w-full py-3 px-4 text-gray-700" value="<?php echo $email; ?>">
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                <input type="password" name="password" class="shadow-sm border rounded w-full py-3 px-4 text-gray-700">
            </div>
            <!-- UPDATED: Added Forgot Password Link -->
            <div class="text-right mb-6">
                <a href="forgot_password.php" class="text-sm text-purple-600 hover:text-purple-800 font-semibold">Forgot Password?</a>
            </div>
            <div class="form-group">
                <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-lg">Login</button>
            </div>
            <p class="text-center text-sm text-gray-600 mt-6">Don't have an account? <a href="register.php" class="text-purple-600 hover:text-purple-800 font-bold">Sign up now</a>.</p>
        </form>
    </div>
</body>
</html>
