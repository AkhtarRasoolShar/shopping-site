<?php
/*
=========================================================
 File: register.php
 Description: Handles user registration.
 Location: /register.php
=========================================================
*/

session_start();
require_once 'db.php';

$username_err = $email_err = $password_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate username
    if (empty(trim($_POST["username"]))) {
        $username_err = "Please enter a username.";
    } else {
        $sql = "SELECT id FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $_POST["username"]);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows == 1) {
            $username_err = "This username is already taken.";
        }
        $stmt->close();
    }

    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } else {
        $sql = "SELECT id FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $_POST["email"]);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows == 1) {
            $email_err = "This email is already registered.";
        }
        $stmt->close();
    }

    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    }

    // Check input errors before inserting in database
    if (empty($username_err) && empty($email_err) && empty($password_err)) {
        $sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        // Hash password
        $hashed_password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

        $stmt->bind_param("sss", $_POST['username'], $_POST['email'], $hashed_password);

        if ($stmt->execute()) {
            header("location: login.php?registration=success");
            exit();
        } else {
            echo "Something went wrong. Please try again later.";
        }
        $stmt->close();
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="w-full max-w-md bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-2">Create Account</h2>
        <p class="text-center text-gray-500 mb-8">Get started with your new account</p>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Username</label>
                <input type="text" name="username" class="shadow-sm appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-purple-600 <?= (!empty($username_err)) ? 'border-red-500' : ''; ?>">
                <span class="text-red-500 text-xs italic"><?php echo $username_err; ?></span>
            </div>
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-bold mb-2">Email</label>
                <input type="email" name="email" class="shadow-sm appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-purple-600 <?= (!empty($email_err)) ? 'border-red-500' : ''; ?>">
                <span class="text-red-500 text-xs italic"><?php echo $email_err; ?></span>
            </div>
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                <input type="password" name="password" class="shadow-sm appearance-none border rounded w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:ring-2 focus:ring-purple-600 <?= (!empty($password_err)) ? 'border-red-500' : ''; ?>">
                <span class="text-red-500 text-xs italic"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <button type="submit" class="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-lg focus:outline-none focus:shadow-outline transition-colors">Sign Up</button>
            </div>
            <p class="text-center text-sm text-gray-600 mt-6">Already have an account? <a href="login.php" class="text-purple-600 hover:text-purple-800 font-bold">Login here</a>.</p>
        </form>
    </div>
</body>
</html>
