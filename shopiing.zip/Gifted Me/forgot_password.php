<?php
/*
=========================================================
 File: forgot_password.php (NEW)
 Description: Page for users to request a password reset link.
 Location: /forgot_password.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure database connection is included

$success_message = '';
$error_message = '';

// Check for feedback messages from send_reset_link.php
if (isset($_SESSION['reset_success'])) {
    $success_message = $_SESSION['reset_success'];
    unset($_SESSION['reset_success']);
}
if (isset($_SESSION['reset_error'])) {
    $error_message = $_SESSION['reset_error'];
    unset($_SESSION['reset_error']);
}

// IMPORTANT: Do NOT close $conn here. It's needed by header.php.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }</style>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">

    <?php include 'header.php'; // Include header if you want full site navigation ?>

    <div class="bg-white p-8 rounded-lg shadow-lg max-w-md w-full">
        <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Forgot Your Password?</h2>
        <p class="text-center text-gray-600 mb-6">Enter your email address below and we'll send you a link to reset your password.</p>

        <?php if ($success_message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <form action="send_reset_link.php" method="post">
            <div class="mb-4">
                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address:</label>
                <input type="email" name="email" id="email" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
            </div>
            <div class="flex items-center justify-between">
                <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline w-full">
                    Send Reset Link
                </button>
            </div>
            <div class="text-center mt-4 text-sm">
                <a href="login.php" class="text-blue-600 hover:underline">Remembered your password? Login here.</a>
            </div>
        </form>
    </div>

    <?php include 'footer.php'; // Include footer if you want full site navigation ?>

    <script>lucide.createIcons();</script>
</body>
</html>
