<?php
/*
=========================================================
 File: faqs.php (NEW)
 Description: Frequently Asked Questions page with accordion.
 Location: /faqs.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure your database connection is included.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQs - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-faqs-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6); /* Deep purple to lighter purple gradient */
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-faqs-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .faq-tab-button {
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            font-weight: 500;
            transition: all 0.2s ease;
        }
        .faq-tab-button.active {
            background-color: #6d28d9;
            color: white;
        }
        .faq-tab-button:not(.active):hover {
            background-color: #e5e7eb;
            color: #4b5563;
        }
        .faq-item {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            margin-bottom: 1rem;
        }
        .faq-question {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 1.5rem;
            cursor: pointer;
            font-weight: 600;
            color: #374151;
        }
        .faq-answer {
            padding: 0 1.5rem 1rem 1.5rem;
            color: #4b5563;
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease-out, padding 0.3s ease-out;
            background-color: #f9fafb;
        }
        .faq-item.open .faq-answer {
            max-height: 200px; /* Adjust as needed for content */
            padding-top: 1rem;
            padding-bottom: 1.5rem;
        }
        .faq-item.open .faq-question .lucide-chevron-down {
            transform: rotate(180deg);
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-faqs-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">FAQs</h1>
                <p class="mt-2 text-lg text-purple-200">Here are some answers to some commonly asked questions</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="flex justify-center space-x-4 mb-8">
                <button class="faq-tab-button active" data-category="giga">For Gift Givers</button>
                <button class="faq-tab-button" data-category="recipient">For Gift Recipients</button>
                <button class="faq-tab-button" data-category="payments">For Payments</button>
            </div>

            <div id="faq-content-container">
                <div id="giga-faqs" class="faq-category-content">
                    <div class="flex items-center text-purple-700 font-semibold text-lg mb-4">
                        <i data-lucide="arrow-right" class="w-6 h-6 mr-2"></i>
                        For Gift Givers
                        <span class="ml-auto text-sm text-gray-500">7 Answers</span>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#1. What is Gifted Me?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Gifted Me is a digital gift card marketplace that offers a wide variety of e-gift cards from leading brands across Pakistan. It provides a convenient way to send personalized gifts for any occasion.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#2. How to purchase an E-Gift Card?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>You can purchase an E-Gift Card by selecting your desired brand/category, choosing the amount, personalizing it with a message and greeting card, and then proceeding to checkout.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#3. What is the delivery process?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Digital E-Gift Cards are sent via email and SMS to the recipient immediately or on a scheduled date. Physical E-Gift Cards can be delivered to a provided location.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#4. Can I schedule a gift card for later?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Yes, our 'GiftAhead' feature allows you to schedule E-Gift Cards for up to 6 months in advance. The recipient will receive it via email and SMS on the specified date.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#5. What is your refund/cancelation policy?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Our refund and cancellation policies vary by product and brand. Please refer to the specific terms and conditions listed on each product page or contact our customer service for details.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#6. How secure are my information / Credit Card details?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>We prioritize your security. All sensitive information, including credit card details, is handled through secure, PCI-compliant payment gateways. We do not store your full credit card information on our servers.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#7. Any other questions?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>If you have any other questions, please feel free to contact our customer service team via email at help@giftkarte.com or by calling 021-111-MYGIFT.</p>
                        </div>
                    </div>
                </div>

                <div id="recipient-faqs" class="faq-category-content hidden">
                    <div class="flex items-center text-purple-700 font-semibold text-lg mb-4">
                        <i data-lucide="arrow-right" class="w-6 h-6 mr-2"></i>
                        For Gift Recipients
                        <span class="ml-auto text-sm text-gray-500">3 Answers</span>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#1. How do I redeem my E-Gift Card?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>You can redeem your E-Gift Card online on the brand's website or at physical retail stores. Instructions for redemption are typically included with the E-Gift Card.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#2. What if my E-Gift Card is not working?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Please check the terms and conditions of the specific gift card for validity and usage restrictions. If the issue persists, contact our customer service with your E-Gift Card details.</p>
                        </div>
                    </div>
                     <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#3. Can I use a partial amount of my E-Gift Card?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Many of our partner brands allow partial redemption of E-Gift Cards. Please check the specific product details or the brand's terms and conditions for confirmation.</p>
                        </div>
                    </div>
                </div>

                <div id="payments-faqs" class="faq-category-content hidden">
                    <div class="flex items-center text-purple-700 font-semibold text-lg mb-4">
                        <i data-lucide="arrow-right" class="w-6 h-6 mr-2"></i>
                        For Payments
                        <span class="ml-auto text-sm text-gray-500">2 Answers</span>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#1. What payment methods are accepted?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>We accept various payment methods including Credit/Debit Cards (Visa, Mastercard), Direct Bank Transfers, and other local payment options as available. Your payment information is securely processed.</p>
                        </div>
                    </div>
                    <div class="faq-item">
                        <div class="faq-question">
                            <span>Q#2. Is there a transaction fee?</span>
                            <i data-lucide="chevron-down" class="w-6 h-6 text-gray-500 transition-transform duration-300"></i>
                        </div>
                        <div class="faq-answer">
                            <p>Gifted Me does not charge any transaction fees for E-Gift Card purchases. However, your bank or card issuer might apply their own fees for certain transactions.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();

        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const parentItem = question.closest('.faq-item');
                    parentItem.classList.toggle('open');
                });
            });

            // Tab Switching Logic
            const tabButtons = document.querySelectorAll('.faq-tab-button');
            const faqContents = document.querySelectorAll('.faq-category-content');

            tabButtons.forEach(button => {
                button.addEventListener('click', () => {
                    // Remove active from all buttons
                    tabButtons.forEach(btn => btn.classList.remove('active'));
                    // Add active to clicked button
                    button.classList.add('active');

                    // Hide all content sections
                    faqContents.forEach(content => content.classList.add('hidden'));

                    // Show the relevant content section
                    const targetCategory = button.dataset.category;
                    document.getElementById(targetCategory + '-faqs').classList.remove('hidden');
                });
            });
        });
    </script>
</body>
</html>
