<?php
/*
=========================================================
 File: egift_cards.php (FIXED: Removed premature $conn->close())
 Description: Displays all E-Gift Cards with search and filter options.
 Location: /egift_cards.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure your database connection is included.

// --- Filters and Search Parameters ---
$search_query = $_GET['query'] ?? '';
$filter_category = $_GET['category'] ?? ''; // e.g., "Popular", "Fashion", "Food"
$sort_order = $_GET['ordering'] ?? 'popular'; // "popular", "name_asc", "name_desc", "price_asc", "price_desc"

// Build the SQL query
$sql = "SELECT id, name, category, image, price, tags FROM products WHERE 1=1"; // Start with a true condition

// Apply search query
if (!empty($search_query)) {
    $search_query_safe = "%" . $conn->real_escape_string($search_query) . "%";
    $sql .= " AND (name LIKE '{$search_query_safe}' OR description LIKE '{$search_query_safe}')"; // Assuming 'description' is searchable
}

// Apply category filter (if 'category' column exists in products)
if (!empty($filter_category)) {
    $filter_category_safe = $conn->real_escape_string($filter_category);
    $sql .= " AND category = '{$filter_category_safe}'";
}

// Apply sorting
switch ($sort_order) {
    case 'name_asc':
        $sql .= " ORDER BY name ASC";
        break;
    case 'name_desc':
        $sql .= " ORDER BY name DESC";
        break;
    case 'price_asc':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY price DESC";
        break;
    case 'popular': // Assuming 'popular' is based on most recent or a 'popularity' column
    default:
        $sql .= " ORDER BY created_at DESC"; // Default to recent if no popularity metric
        break;
}

$result = $conn->query($sql);

$products = [];
if ($result && $result->num_rows > 0) {
    $products = $result->fetch_all(MYSQLI_ASSOC);
    // Decode tags from JSON if they are stored as such
    foreach ($products as &$product) {
        $product['tags'] = json_decode($product['tags'] ?? '[]', true);
    }
}
// IMPORTANT: REMOVED THIS LINE -> $conn->close(); // Close the database connection after all data is fetched.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Gift Cards - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-egift-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-egift-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .product-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.2s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .product-card .tags {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            z-index: 10;
        }
        .product-card .tag-item {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 9999px; /* rounded-full */
            font-size: 0.75rem; /* text-xs */
            font-weight: 600; /* font-semibold */
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
            white-space: nowrap; /* Prevent text wrapping */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-egift-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">E-Gift Cards</h1>
                <p class="mt-2 text-lg text-purple-200">The perfect gift for every occasion, delivered instantly.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="bg-white p-4 rounded-lg shadow-md mb-8">
                <form action="egift_cards.php" method="GET" class="flex flex-col md:flex-row items-center gap-4">
                    <input type="text" name="query" placeholder="Search Gift Cards..." value="<?= htmlspecialchars($search_query) ?>" class="w-full md:flex-grow border-gray-300 rounded-lg shadow-sm">

                    <select name="category" class="w-full md:w-auto border-gray-300 rounded-lg shadow-sm">
                        <option value="">All Categories</option>
                        <?php
                            // You would dynamically fetch categories from your database here
                            $categories = ['Popular', 'Fashion', 'Food', 'Electronics', 'Home & Living', 'Beauty', 'Entertainment'];
                            foreach ($categories as $cat) {
                                $selected = ($filter_category == $cat) ? 'selected' : '';
                                echo "<option value=\"" . htmlspecialchars($cat) . "\" {$selected}>" . htmlspecialchars($cat) . "</option>";
                            }
                        ?>
                    </select>

                    <select name="ordering" class="w-full md:w-auto border-gray-300 rounded-lg shadow-sm">
                        <option value="popular" <?= ($sort_order == 'popular') ? 'selected' : '' ?>>Most Popular</option>
                        <option value="name_asc" <?= ($sort_order == 'name_asc') ? 'selected' : '' ?>>Name (A-Z)</option>
                        <option value="name_desc" <?= ($sort_order == 'name_desc') ? 'selected' : '' ?>>Name (Z-A)</option>
                        <option value="price_asc" <?= ($sort_order == 'price_asc') ? 'selected' : '' ?>>Price (Low to High)</option>
                        <option value="price_desc" <?= ($sort_order == 'price_desc') ? 'selected' : '' ?>>Price (High to Low)</option>
                    </select>

                    <button type="submit" class="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white font-bold p-2 rounded-lg flex items-center justify-center">
                        <i data-lucide="search" class="w-5 h-5"></i>
                    </button>
                </form>
            </div>

            <?php if (empty($products)): ?>
                <div class="bg-white rounded-lg shadow-md p-8 text-center">
                    <i data-lucide="package-x" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                    <h2 class="text-xl font-semibold text-gray-700">No E-Gift Cards Found</h2>
                    <p class="text-gray-500 mt-2">Try adjusting your search or filters.</p>
                </div>
            <?php else: ?>
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <a href="product_detail.php?id=<?= $product['id'] ?>" class="block relative">
                                <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-40 object-cover rounded-t-lg" onerror="this.onerror=null;this.src='https://placehold.co/400x300/e2e8f0/4a5568?text=Image+Not+Found';">
                                <div class="tags">
                                    <?php if (!empty($product['tags'])): ?>
                                        <?php foreach ($product['tags'] as $tag): ?>
                                            <span class="tag-item <?= strpos($tag, 'Online') !== false ? 'bg-blue-100 text-blue-800' : (strpos($tag, '% Off') !== false ? 'bg-red-100 text-red-800' : 'bg-gray-200 text-gray-700') ?>">
                                                <?= htmlspecialchars($tag) ?>
                                            </span>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                <div class="p-3">
                                    <h3 class="text-md font-semibold text-gray-900 truncate"><?= htmlspecialchars($product['name']) ?></h3>
                                    <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                                    <p class="text-md font-bold text-purple-700 mt-2">PKR <?= number_format($product['price'], 2) ?></p>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
