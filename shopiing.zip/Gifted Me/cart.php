<?php
/*
=========================================================
 File: cart.php (UPDATED - Removed premature $conn->close())
 Description: Displays and manages the shopping cart.
 Location: /cart.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure db.php is included first to establish $conn

// Check if user is logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$cart_items = [];
$cart_total = 0;

// Fetch cart items
$sql = "SELECT c.product_id, c.quantity, p.name, p.price, p.image
        FROM cart c
        JOIN products p ON c.product_id = p.id
        WHERE c.user_id = ?";
if ($stmt = $conn->prepare($sql)) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cart_items[] = $row;
            $cart_total += $row['quantity'] * $row['price'];
        }
    }
    $stmt->close();
}

// IMPORTANT: Do NOT call $conn->close(); here.
// The connection must remain open for header.php and other includes.
// PHP will automatically close the connection when cart.php finishes executing.

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Shopping Cart - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; // This is where the error was triggered previously ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Your Shopping Cart</h1>

        <?php if (empty($cart_items)): ?>
            <div class="bg-white rounded-lg shadow-md p-8 text-center">
                <i data-lucide="shopping-cart" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-xl font-semibold text-gray-700">Your Cart is Empty</h2>
                <p class="text-gray-500 mt-2">Looks like you haven't added anything to your cart yet. Start shopping!</p>
                <a href="products.php" class="mt-6 inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">Browse Products</a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-2 bg-white rounded-lg shadow-md p-6">
                    <?php foreach ($cart_items as $item): ?>
                        <div class="flex items-center border-b border-gray-200 py-4 last:border-b-0">
                            <img src="<?= htmlspecialchars($item['image'] ?? 'https://placehold.co/80x80') ?>" alt="<?= htmlspecialchars($item['name']) ?>" class="w-20 h-20 object-cover rounded-md mr-4">
                            <div class="flex-1">
                                <h3 class="text-lg font-semibold text-gray-800"><?= htmlspecialchars($item['name']) ?></h3>
                                <p class="text-gray-600">PKR <?= number_format($item['price'], 2) ?></p>
                            </div>
                            <div class="flex items-center space-x-4">
                                <form action="cart_handler.php" method="post" class="flex items-center">
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="number" name="quantity" value="<?= htmlspecialchars($item['quantity']) ?>" min="1" class="w-16 text-center border border-gray-300 rounded-md py-1 px-2 focus:ring-purple-500 focus:border-purple-500">
                                    <button type="submit" class="ml-2 text-sm bg-gray-200 hover:bg-gray-300 text-gray-700 px-3 py-1 rounded-md">Update</button>
                                </form>
                                <form action="cart_handler.php" method="post">
                                    <input type="hidden" name="product_id" value="<?= $item['product_id'] ?>">
                                    <input type="hidden" name="action" value="remove">
                                    <button type="submit" class="text-red-600 hover:text-red-800 p-1 rounded-full"><i data-lucide="x" class="w-5 h-5"></i></button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="lg:col-span-1 bg-white rounded-lg shadow-md p-6 h-fit sticky top-24">
                    <h2 class="text-2xl font-bold text-gray-800 mb-4">Cart Summary</h2>
                    <div class="flex justify-between items-center text-lg font-medium text-gray-700 mb-2">
                        <span>Subtotal:</span>
                        <span>PKR <?= number_format($cart_total, 2) ?></span>
                    </div>
                    <div class="flex justify-between items-center text-lg font-medium text-gray-700 mb-4">
                        <span>Shipping:</span>
                        <span>Free</span> </div>
                    <div class="border-t border-gray-200 pt-4 flex justify-between items-center text-2xl font-bold text-purple-700">
                        <span>Total:</span>
                        <span>PKR <?= number_format($cart_total, 2) ?></span>
                    </div>
                    <a href="checkout.php" class="mt-6 w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-lg text-center block">Proceed to Checkout &rarr;</a>
                </div>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; // Ensure footer.php exists or its content is here ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
