<?php
/*
=========================================================
 File: founders_story.php (NEW)
 Description: Page detailing the founder's story of Gifted Me.
 Location: /founders_story.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Founder's Story - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-founders-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-founders-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .story-section-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-bottom: 2rem;
            max-width: 800px; /* Constrain width for readability */
            margin-left: auto;
            margin-right: auto;
        }
        .founder-image {
            border-radius: 9999px; /* rounded-full */
            width: 150px;
            height: 150px;
            object-fit: cover;
            border: 4px solid #6d28d9;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-founders-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Our Founder's Story</h1>
                <p class="mt-2 text-lg text-purple-200">The journey behind Gifted Me.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="story-section-card text-center">
                <img src="https://placehold.co/150x150/8b5cf6/ffffff?text=Founder" alt="Founder" class="founder-image mx-auto mb-6">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Meet [Founder's Name]</h2>
                <p class="text-gray-700 leading-relaxed text-lg mb-4">
                    The vision for Gifted Me was born out of a personal challenge faced by our founder, [Founder's Name], during [a specific time or event, e.g., the festive season, a remote birthday]. [He/She/They] realized the growing need for a gifting solution that was not only convenient but also offered genuine choice and instant gratification, especially in a diverse market like Pakistan.
                </p>
                <p class="text-gray-700 leading-relaxed text-lg mb-4">
                    [Founder's Name] embarked on a mission to bridge the gap between traditional gifting hassles and the digital convenience of modern commerce. With a background in [e.g., e-commerce, finance, technology], [he/she/they] envisioned a platform where anyone could easily send a thoughtful gift card, redeemable at a wide array of brands, eliminating the guesswork and logistical challenges of physical presents.
                </p>
                <p class="text-gray-700 leading-relaxed text-lg mb-4">
                    The journey began with extensive research, countless meetings with retailers, and a relentless pursuit of a user-friendly and secure system. It was a path filled with challenges, but [his/her/their] unwavering belief in the power of thoughtful gifting, simplified by technology, fueled every step.
                </p>
                <p class="text-gray-700 leading-relaxed text-lg">
                    Today, Gifted Me stands as a testament to that initial vision – a platform built on the principles of convenience, choice, and connection, enabling millions to express their care and affection effortlessly. We are proud of our origins and remain committed to [Founder's Name]'s founding spirit of innovation and dedication to our users.
                </p>
            </div>

            <div class="text-center mt-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Ready to Experience Gifted Me?</h2>
                <p class="text-gray-600 max-w-xl mx-auto mb-6">
                    Join our story by exploring the seamless world of digital gifting.
                </p>
                <a href="products.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg text-lg inline-flex items-center shadow-md">
                    <i data-lucide="package" class="w-5 h-5 mr-2"></i> Shop E-Gift Cards
                </a>
            </div>

        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
