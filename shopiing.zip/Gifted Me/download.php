<?php
/*
=========================================================
 File: download.php (NEW)
 Description: A page promoting the mobile app.
 Location: /download.php
=========================================================
*/
session_start();
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Download App - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .hero-bg-purple {
            background-color: #5b21b6;
            background-image: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <div class="hero-bg-purple text-white">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-16 grid md:grid-cols-2 gap-8 items-center">
            <!-- Text Content -->
            <div class="text-center md:text-left">
                <h1 class="text-4xl md:text-5xl font-bold leading-tight">Gifted Me Mobile App for Android and iOS!</h1>
                <p class="mt-4 text-lg text-purple-200">Send & Receive E-Gift Cards from your device with our mobile app! Get started now!</p>
                <div class="flex justify-center md:justify-start space-x-4 mt-8">
                    <a href="#"><img src="https://placehold.co/160x50/000000/ffffff?text=App+Store" alt="Download on the App Store" class="rounded-lg"></a>
                    <a href="#"><img src="https://placehold.co/160x50/000000/ffffff?text=Google+Play" alt="Get it on Google Play" class="rounded-lg"></a>
                </div>
            </div>
            <!-- Image Content -->
            <div class="flex justify-center">
                <img src="https://placehold.co/350x450/ffffff/6d28d9?text=Phone+Mockup" alt="Phone displaying the Gifted Me app" class="max-w-xs w-full rounded-2xl shadow-2xl">
            </div>
        </div>
    </div>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="zap" class="w-12 h-12 mx-auto text-yellow-500 mb-4"></i><h3 class="font-semibold">Fast and Convenient</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="gift" class="w-12 h-12 mx-auto text-green-500 mb-4"></i><h3 class="font-semibold">You Gift, They Choose</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="lock" class="w-12 h-12 mx-auto text-red-500 mb-4"></i><h3 class="font-semibold">Secure Payment</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="crown" class="w-12 h-12 mx-auto text-purple-500 mb-4"></i><h3 class="font-semibold">Premium Gifting</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="user" class="w-12 h-12 mx-auto text-blue-500 mb-4"></i><h3 class="font-semibold">User Dashboard</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="bell" class="w-12 h-12 mx-auto text-orange-500 mb-4"></i><h3 class="font-semibold">Occasion Reminder</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="star" class="w-12 h-12 mx-auto text-indigo-500 mb-4"></i><h3 class="font-semibold">GK Points (Loyalty Point)</h3></div>
            <div class="bg-white rounded-lg shadow-md p-6 text-center"><i data-lucide="wallet" class="w-12 h-12 mx-auto text-teal-500 mb-4"></i><h3 class="font-semibold">Check Remaining Balance</h3></div>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
