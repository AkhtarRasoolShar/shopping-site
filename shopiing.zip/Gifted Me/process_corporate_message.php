<?php
/*
=========================================================
 File: process_corporate_message.php (UPDATED: Save to DB)
 Description: Processes corporate gifting contact form and saves to DB, sends email.
 Location: /process_corporate_message.php
=========================================================
*/
session_start();
require_once 'db.php';

// --- DEBUGGING START (Remove or comment out in production) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
error_log("PROCESS CORPORATE MESSAGE: Request Method is " . $_SERVER["REQUEST_METHOD"]);
error_log("POST Data: " . print_r($_POST, true));
// --- DEBUGGING END ---

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate input
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $company_name = filter_input(INPUT_POST, 'company_name', FILTER_SANITIZE_STRING);
    $mobile_no = filter_input(INPUT_POST, 'mobile_no', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    $errors = [];
    if (empty($name)) { $errors[] = 'Your Name is required.'; }
    if (empty($company_name)) { $errors[] = 'Company Name is required.'; }
    if (empty($mobile_no)) { $errors[] = 'Mobile No. is required.'; }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'A valid Email Address is required.'; }
    if (empty($message)) { $errors[] = 'Message cannot be empty.'; }

    if (!empty($errors)) {
        $_SESSION['form_error'] = implode('<br>', $errors);
        header("Location: corporate_gifting.php#send-message");
        exit;
    }

    $conn->begin_transaction(); // Start transaction

    try {
        // --- Save message to database ---
        $stmt_insert_db = $conn->prepare("INSERT INTO contact_messages (sender_name, company_name, mobile_no, email, message) VALUES (?, ?, ?, ?, ?)");
        if ($stmt_insert_db === false) {
            throw new Exception("Database prepare failed for message insertion: " . $conn->error);
        }
        $stmt_insert_db->bind_param("sssss", $name, $company_name, $mobile_no, $email, $message);
        if (!$stmt_insert_db->execute()) {
            throw new Exception("Database execute failed for message insertion: " . $stmt_insert_db->error);
        }
        $stmt_insert_db->close();

        // --- Send email to admin (Optional, but recommended for immediate notification) ---
        $admin_email = "your_admin_email@example.com"; // CHANGE THIS TO YOUR ADMIN'S EMAIL ADDRESS
        $subject = "New Corporate Gifting Inquiry from " . $name;
        $email_body = "You have received a new corporate gifting inquiry:\n\n" .
                      "Name: " . $name . "\n" .
                      "Company Name: " . $company_name . "\n" .
                      "Mobile No.: " . $mobile_no . "\n" .
                      "Email Address: " . $email . "\n\n" .
                      "Message:\n" . $message . "\n";
        $headers = "From: " . $email . "\r\n" .
                   "Reply-To: " . $email . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();

        // Attempt to send email. Don't throw a fatal error if mail fails, just log it.
        if (!mail($admin_email, $subject, $email_body, $headers)) {
            error_log("Failed to send corporate gifting email. Mail function returned false. Admin Email: $admin_email");
            // You can decide if email failure should prevent transaction commit
            // For now, it won't, as DB save is primary.
        }

        $conn->commit(); // Commit transaction if both DB save and email (attempt) are fine

        $_SESSION['form_success'] = 'Your message has been sent successfully. We will get back to you shortly!';
        header("Location: corporate_gifting.php#send-message");
        exit;

    } catch (Exception $e) {
        $conn->rollback(); // Rollback transaction on any error
        error_log("Corporate Gifting Message Error: " . $e->getMessage());
        $_SESSION['form_error'] = 'Sorry, an unexpected error occurred. Please try again later.';
        header("Location: corporate_gifting.php#send-message");
        exit;
    }

} else {
    header("Location: corporate_gifting.php");
    exit;
}
?>
