<?php
// Start the session at the very beginning of the file
session_start();

// Redirect to the dashboard if the user is already logged in
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Gifted Me</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-main-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 4rem;
        }
        .hero-main-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
    </style>
</head>
<body class="bg-white">

    <?php
    // Include the database connection and other required files
    require_once 'db.php';
    include 'header.php';
    ?>

    <main class="min-h-screen">
        <div class="hero-main-bg py-20 lg:py-32 flex items-center">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper text-center text-white">
                <h1 class="text-4xl md:text-6xl font-extrabold tracking-tight leading-none mb-6">
                    Discover the perfect gift for every occasion 🎁
                </h1>
                <p class="text-lg md:text-xl font-light text-purple-100 max-w-3xl mx-auto mb-8">
                    Sign up to explore a world of digital gift cards from top brands, track your gifts, and send personalized messages to your loved ones.
                </p>
                <div class="space-y-4 sm:space-y-0 sm:space-x-4 flex flex-col sm:flex-row justify-center">
                    <a href="signup.php" class="bg-white text-purple-600 hover:bg-gray-100 font-bold py-3 px-8 rounded-full text-lg transition-colors duration-300 shadow-lg">
                        Create an Account
                    </a>
                    <a href="login.php" class="bg-transparent border-2 border-white text-white hover:bg-white hover:text-purple-600 font-bold py-3 px-8 rounded-full text-lg transition-colors duration-300">
                        Log In
                    </a>
                </div>
            </div>
        </div>

        <section class="py-16 bg-gray-50">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">How it Works</h2>
                <div class="grid md:grid-cols-3 gap-12 text-center">
                    <div>
                        <div class="flex justify-center mb-4">
                            <i data-lucide="search" class="w-16 h-16 text-purple-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 mb-2">1. Explore Brands</h3>
                        <p class="text-gray-600">Browse a wide selection of gift cards from your favorite brands.</p>
                    </div>
                    <div>
                        <div class="flex justify-center mb-4">
                            <i data-lucide="credit-card" class="w-16 h-16 text-purple-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 mb-2">2. Buy Instantly</h3>
                        <p class="text-gray-600">Purchase digital gift cards securely with just a few clicks.</p>
                    </div>
                    <div>
                        <div class="flex justify-center mb-4">
                            <i data-lucide="send" class="w-16 h-16 text-purple-600"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 mb-2">3. Send & Redeem</h3>
                        <p class="text-gray-600">Send them directly to your friends and family via email or SMS.</p>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-16">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Ready to get started?</h2>
                <p class="text-lg text-gray-600 mb-8">Join thousands of happy users and simplify your gifting today.</p>
                <a href="register.php" class="bg-purple-600 text-white hover:bg-purple-700 font-bold py-3 px-8 rounded-full text-lg transition-colors duration-300 shadow-lg">
                    Sign Up Now
                </a>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
