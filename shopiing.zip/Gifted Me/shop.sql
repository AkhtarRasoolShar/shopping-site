-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 21, 2025 at 10:54 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$vhMwnPihVSVxcsovX7a1C.XBLW1S7/ACO/uptHSfhKPX86jS6NVXi'),
(2, 'admins', '123456'),
(3, 'a', '$2y$10$AnbZ5gzP5jwxsNxA1ZcoaOyvEEuyXXDx5LZCxaKRSZhG2tWiNQ2fW'),
(4, 'sas', '$2y$10$KyAFrDdEk27TTYSsgB8eour8siUNklOcxU70PJrd8s59cTXfC.Wpa'),
(5, 'aa', '$2y$10$C7/D9esACfGmAIYZmIOAM.q/Bpteqh.aOt0bYO1B0YlOeejzZ16Jm');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(7, 'a'),
(2, 'Emerging Brands'),
(3, 'Fashion & Accessories'),
(1, 'General'),
(4, 'Home & Furnishing'),
(5, 'Supermarkets & Dept Store');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `logo_url` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `name`, `logo_url`, `is_active`) VALUES
(1, 'Reckitt', 'https://placehold.co/150x80/ffffff/cccccc?text=reckitt', 1),
(2, 'Engro', 'https://placehold.co/150x80/ffffff/cccccc?text=engro', 1),
(3, 'BAT', 'https://placehold.co/150x80/ffffff/cccccc?text=BAT', 1),
(4, 'HBL', 'https://placehold.co/150x80/ffffff/cccccc?text=HBL', 1),
(5, 'EBM', 'https://placehold.co/150x80/ffffff/cccccc?text=EBM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(255) NOT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(20) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `received_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `card_last_four` varchar(4) DEFAULT NULL,
  `tid` varchar(255) DEFAULT NULL,
  `payment_proof_image` varchar(255) DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `order_status` varchar(50) NOT NULL DEFAULT 'Pending',
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL,
  `tel` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `full_name`, `address`, `city`, `payment_method`, `card_last_four`, `tid`, `payment_proof_image`, `total_price`, `order_status`, `order_date`, `status`, `tel`) VALUES
(1, 1, 'a', 'a', 'a', '', NULL, NULL, NULL, 0.00, 'Pending', '2025-07-20 13:58:07', '', ''),
(2, 1, 'a', 'a', 'a', '', NULL, NULL, NULL, 0.00, 'Pending', '2025-07-20 14:05:58', '', ''),
(3, 1, 'aa', 'aaa', 'aa', 'Credit / Debit Card', NULL, '', '', 0.00, 'Pending Approval', '2025-07-20 14:20:38', '', ''),
(4, 1, '22', '323', '32', 'Credit / Debit Card', NULL, '', '', 3242.00, 'Pending Approval', '2025-07-20 15:15:52', '', ''),
(5, 1, 'aadag', 'gweg', 'gwg', 'Credit / Debit Card', NULL, '', '', 17825.00, 'Pending Approval', '2025-07-20 17:54:11', '', ''),
(6, 1, 'sdfdas', 'dsada', 'sdad', 'Crypto Payment', NULL, '', '', 3230000.00, 'Pending Approval', '2025-07-21 05:25:54', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(1, 1, 1, 0, 1212.00),
(2, 2, 1, 0, 1212.00),
(3, 3, 1, 0, 1212.00),
(4, 4, 2, 1, 3242.00),
(5, 5, 2, 5, 3242.00),
(6, 5, 3, 5, 323.00),
(7, 6, 3, 10000, 323.00);

-- --------------------------------------------------------

--
-- Table structure for table `page_views`
--

CREATE TABLE `page_views` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `page_url` varchar(255) NOT NULL,
  `view_time` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`) VALUES
(1, 'a@gmail.com', 'f942f3de0198cfb40c5038d5084259028bef07b76843f3285356d9faecf3299ee98244360bfd83b3407f97693e6b8e971dab', '2025-07-21 08:44:05'),
(2, 'a@gmail.com', 'cfd6a74d38317a3f0e6d0d078ba56a071357d32e2842b60f5d30d74164c3614d2f005359df05577fab2493e00dc5385502ab', '2025-07-21 08:45:17');

-- --------------------------------------------------------

--
-- Table structure for table `premium_orders`
--

CREATE TABLE `premium_orders` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `gift_amount` decimal(10,2) NOT NULL,
  `location_package` varchar(50) NOT NULL,
  `premium_message` text DEFAULT NULL,
  `attached_photo_url` varchar(255) DEFAULT NULL,
  `sender_name` varchar(255) NOT NULL,
  `sender_mobile` varchar(20) NOT NULL,
  `sender_email` varchar(255) NOT NULL,
  `sender_country` varchar(100) NOT NULL,
  `sender_city` varchar(100) NOT NULL,
  `sender_address` text NOT NULL,
  `receiver_name` varchar(255) NOT NULL,
  `receiver_mobile` varchar(20) NOT NULL,
  `receiver_email` varchar(255) DEFAULT NULL,
  `receiver_country` varchar(100) NOT NULL,
  `receiver_city` varchar(100) NOT NULL,
  `receiver_address` text NOT NULL,
  `order_status` varchar(50) DEFAULT 'Pending Premium Review',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `premium_orders`
--

INSERT INTO `premium_orders` (`id`, `user_id`, `gift_amount`, `location_package`, `premium_message`, `attached_photo_url`, `sender_name`, `sender_mobile`, `sender_email`, `sender_country`, `sender_city`, `sender_address`, `receiver_name`, `receiver_mobile`, `receiver_email`, `receiver_country`, `receiver_city`, `receiver_address`, `order_status`, `created_at`) VALUES
(1, 1, 1000.00, 'silver', '', NULL, 'Akhtar Rasool', 'fw', 'a@gmail.com', 'Pakistan', 'yyy', 'ggh', 'Akhtar Rasool', 'fsf', 'wgs@gmail.com', 'Pakistan', 'yyy', 'ggh', 'Pending Premium Review', '2025-07-21 06:01:28');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `tags` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`tags`)),
  `discount` varchar(50) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `image`, `price`, `tags`, `discount`, `description`, `created_at`) VALUES
(2, 'fsfs', 'fsdf', 'uploads/WhatsApp Video 2024-12-26 at 8.01.56 PM.mp4', 3242.00, '[\"fsfsd\"]', '', 'fsfsf', '2025-07-20 15:13:32'),
(3, 'awfsfa', 'fhf', 'uploads/x1080.jpg', 323.00, '[\"sadas\"]', '564dfg', 'adsada', '2025-07-20 15:55:11'),
(4, 'Innovative Tech Voucher', 'Emerging Brands', 'uploads/products/product_687df35876d16.jpeg', 7500.00, '0', NULL, 'A versatile gift card for innovative tech gadgets from new brands.', '2025-07-21 06:09:38'),
(5, 'Sustainable Fashion Gift', 'Emerging Brands', 'uploads/products/eco_fashion.jpg', 6000.00, '[\"In-Store\", \"Online\", \"New\"]', NULL, 'Explore sustainable and stylish clothing from up-and-coming designers.', '2025-07-21 06:09:38'),
(6, 'Artisan Coffee Card', 'Emerging Brands', 'uploads/products/coffee_card.jpg', 2500.00, '[\"In-Store\"]', NULL, 'Experience unique blends from local artisan coffee shops.', '2025-07-21 06:09:38'),
(7, 'Local Crafts Gift Card', 'Emerging Brands', 'uploads/products/crafts_card.jpg', 3000.00, '[\"Online\"]', NULL, 'Support local artisans with a gift card for handcrafted goods.', '2025-07-21 06:09:38');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `quote` text NOT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `name`, `quote`, `avatar_url`, `is_active`, `created_at`, `user_image`) VALUES
(1, 'Manahil Faraz', 'Loved the app! User-friendly interface :)', NULL, 1, '2025-07-20 12:20:28', ''),
(2, 'Bashir Ahmed Zeeshan', 'No need to keep cash or share your credit card with anyone if you want shopping/dine in just use GiftKarte', NULL, 1, '2025-07-20 12:20:28', ''),
(3, 'Alisha Khans', 'My sister in law living abroad gifted me GiftKarte voucher...it was an amazing experience..the service is too good..highly re...', NULL, 1, '2025-07-20 12:20:28', ''),
(4, 'sdad', 'sdadd', NULL, 1, '2025-07-21 08:24:14', 'uploads/testimonial_images/testimonial_687df92e3205e.jpg'),
(5, 'Articals', 'Articals', NULL, 1, '2025-07-21 08:27:25', 'uploads/testimonial_images/testimonial_687df9ed7d392.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_token_expiry` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `full_name` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `city` varchar(100) NOT NULL,
  `tel` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `reset_token`, `reset_token_expiry`, `created_at`, `full_name`, `address`, `city`, `tel`) VALUES
(1, 'a', 'a@gmail.com', '$2y$10$HxjwWx.IG4YGu3NStUvgkuaBM7gWqWOf6QOhpTccs6O5mxC6MZOsm', NULL, NULL, '2025-07-20 18:54:46', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `visitor_logs`
--

CREATE TABLE `visitor_logs` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `page_url` varchar(255) DEFAULT NULL,
  `visit_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visitor_logs`
--

INSERT INTO `visitor_logs` (`id`, `ip_address`, `user_agent`, `page_url`, `visit_time`) VALUES
(1, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', '/shopping/index.php', '2025-07-20 13:23:16'),
(2, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', '/shopping/index.php', '2025-07-21 08:53:24'),
(3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', '/shopping/reset_password.php?token=cfd6a74d38317a3f0e6d0d078ba56a071357d32e2842b60f5d30d74164c3614d2f005359df05577fab2493e00dc5385502ab', '2025-07-21 08:50:27'),
(4, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', '/shopping/forgot_password.php', '2025-07-21 08:53:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `page_views`
--
ALTER TABLE `page_views`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`token`);

--
-- Indexes for table `premium_orders`
--
ALTER TABLE `premium_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `page_views`
--
ALTER TABLE `page_views`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `premium_orders`
--
ALTER TABLE `premium_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `visitor_logs`
--
ALTER TABLE `visitor_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
