<?php
/*
=========================================================
 File: gk_points.php (NEW)
 Description: Explains the GK Points loyalty program.
 Location: /gk_points.php
=========================================================
*/
session_start();
require_once 'db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GK Points - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .hero-bg-purple {
            background-color: #5b21b6;
            background-image: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <div class="hero-bg-purple text-white">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
            <h1 class="text-4xl font-bold">GK Points</h1>
            <p class="mt-2 text-lg text-purple-200">"GK Points" - the Customer Loyalty Points is our way to appreciate & recognize our valued customers and users.</p>
        </div>
    </div>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid md:grid-cols-2 gap-8">
            <div class="bg-white rounded-lg shadow-lg p-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6">How to Earn GK Points?</h2>
                <div class="space-y-6">
                    <div>
                        <h3 class="text-lg font-semibold text-purple-700">Purchase E-Gift Card</h3>
                        <p class="mt-1 text-gray-600">Earn <span class="font-bold">1%</span> of the value of any E-Gift Card that you purchase from our Website or App.</p>
                    </div>
                    <div>
                        <h3 class="text-lg font-semibold text-purple-700">Redeem Your E-Gift Card</h3>
                        <p class="mt-1 text-gray-600">Earn <span class="font-bold">0.5%</span> of the value of any E-Gift Card that you redeem on our partner brands in the following categories:</p>
                        <ul class="list-disc list-inside mt-2 text-gray-600">
                            <li>Fashion & Accessories</li>
                            <li>Health & Beauty</li>
                            </ul>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow-lg p-8">
                <h2 class="text-2xl font-semibold text-gray-800 mb-6">How to Use GK Points?</h2>
                <div>
                    <h3 class="text-lg font-semibold text-purple-700 mb-4">Avail Discount</h3>
                    <ol class="list-decimal list-inside space-y-2 text-gray-600">
                        <li>Log in to your account.</li>
                        <li>Follow usual Purchase on Website or App.</li>
                        <li>At Check-out, click "Use GK Points" to pay.</li>
                        <li>Your total bill would be reduced by the equivalent PKR value of GK Points available in your account.</li>
                    </ol>
                </div>
            </div>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
