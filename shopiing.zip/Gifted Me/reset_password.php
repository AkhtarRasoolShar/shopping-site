<?php
/*
=========================================================
 File: reset_password.php (UPDATED: Design Matching Site)
 Description: Allows user to set a new password using a reset token.
 Location: /reset_password.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include database connection

$token = $_GET['token'] ?? '';
$user_id = null;
$error_message = '';
$success_message = '';

// Check if token is provided and valid
if (empty($token)) {
    $error_message = "Password reset token is missing.";
} else {
    // Find user by token and check expiry
    $sql_check_token = "SELECT id, reset_token_expiry FROM users WHERE reset_token = ? AND reset_token_expiry > NOW()";
    if ($stmt_check = $conn->prepare($sql_check_token)) {
        $stmt_check->bind_param("s", $token);
        $stmt_check->execute();
        $stmt_check->bind_result($user_id, $expiry_time_db);
        $stmt_check->fetch();
        $stmt_check->close();

        if (!$user_id) {
            // Check if token existed but expired
            $sql_check_expired = "SELECT id FROM users WHERE reset_token = ? AND reset_token_expiry <= NOW()";
            if ($stmt_expired = $conn->prepare($sql_check_expired)) {
                $stmt_expired->bind_param("s", $token);
                $stmt_expired->execute();
                $stmt_expired->store_result();
                if ($stmt_expired->num_rows > 0) {
                    $error_message = "Your password reset link has expired. Please request a new one.";
                } else {
                    $error_message = "Invalid password reset token.";
                }
                $stmt_expired->close();
            } else {
                 $error_message = "Database error checking expired token: " . $conn->error;
            }
        }
    } else {
        $error_message = "Database error checking token: " . $conn->error;
        error_log("Failed to prepare token check query: " . $conn->error);
    }
}

// Handle new password submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['reset_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $submitted_token = $_POST['token']; // Get token from hidden field

    // Re-validate token right before processing the password change
    $re_user_id = null;
    $sql_re_check_token = "SELECT id FROM users WHERE reset_token = ? AND reset_token_expiry > NOW()";
    if ($stmt_re_check = $conn->prepare($sql_re_check_token)) {
        $stmt_re_check->bind_param("s", $submitted_token);
        $stmt_re_check->execute();
        $stmt_re_check->bind_result($re_user_id);
        $stmt_re_check->fetch();
        $stmt_re_check->close();
    }

    if (!$re_user_id) {
        $error_message = "Invalid or expired reset token. Please request a new one.";
    } elseif (empty($new_password) || empty($confirm_password)) {
        $error_message = "All password fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "New password and confirm password do not match.";
    } elseif (strlen($new_password) < 6) { // Example: minimum password length
        $error_message = "New password must be at least 6 characters long.";
    } else {
        // Hash new password
        $hashed_new_password = password_hash($new_password, PASSWORD_DEFAULT);

        // Update password and clear reset token/expiry
        $sql_update_password = "UPDATE users SET password = ?, reset_token = NULL, reset_token_expiry = NULL WHERE id = ?";
        if ($stmt_update = $conn->prepare($sql_update_password)) {
            $stmt_update->bind_param("si", $hashed_new_password, $re_user_id);
            if ($stmt_update->execute()) {
                $success_message = "Your password has been reset successfully. You can now log in with your new password.";
                // Clear token from URL after successful reset
                $token = '';
            } else {
                $error_message = "Error updating password: " . $stmt_update->error;
            }
            $stmt_update->close();
        } else {
            $error_message = "Database prepare failed for update: " . $conn->error;
        }
    }
}

$conn->close(); // Close database connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set New Password - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-login-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6); /* Consistent with other hero sections */
            position: relative;
            overflow: hidden;
            padding-top: 3rem; /* Adjust padding as necessary */
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-login-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .form-container-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            max-width: 450px; /* Adjusted max-width for better fit */
            margin-left: auto;
            margin-right: auto;
            position: relative; /* For z-index in relation to hero */
            z-index: 10;
            margin-top: -3rem; /* Overlap with hero section */
            margin-bottom: 3rem; /* Space below form */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-login-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Set New Password</h1>
                <p class="mt-2 text-lg text-purple-200">Securely update your account password.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8">
            <div class="form-container-card">
                <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Create a new, strong password.</h2>

                <?php if ($success_message): ?>
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <?= htmlspecialchars($success_message) ?>
                    </div>
                    <div class="text-center mt-4">
                        <a href="login.php" class="text-blue-600 hover:underline">Proceed to Login</a>
                    </div>
                <?php endif; ?>
                <?php if ($error_message): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                        <?= htmlspecialchars($error_message) ?>
                    </div>
                    <?php if (empty($token) || $user_id === null): // If token is invalid or missing, suggest requesting new ?>
                        <div class="text-center mt-4">
                            <a href="forgot_password.php" class="text-blue-600 hover:underline">Request a new reset link</a>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if (!$success_message && empty($error_message) && !empty($token) && $user_id): // Show form only if token is valid and not yet successful ?>
                    <form action="reset_password.php?token=<?= htmlspecialchars($token) ?>" method="post">
                        <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                        <div class="mb-4">
                            <label for="new_password" class="block text-gray-700 text-sm font-bold mb-2">New Password:</label>
                            <input type="password" name="new_password" id="new_password" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-6">
                            <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">Confirm New Password:</label>
                            <input type="password" name="confirm_password" id="confirm_password" required class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="flex items-center justify-between">
                            <button type="submit" name="reset_password" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline w-full">
                                Reset Password
                            </button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>lucide.createIcons();</script>
</body>
</html>
