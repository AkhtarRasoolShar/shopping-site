<?php
/*
=========================================================
 File: contact.php (NEW)
 Description: General Contact Us page for user inquiries.
 Location: /contact.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include database connection.

$success_message = '';
$error_message = '';

// Check for feedback messages from process_contact_form.php
if (isset($_SESSION['contact_success'])) {
    $success_message = $_SESSION['contact_success'];
    unset($_SESSION['contact_success']);
}
if (isset($_SESSION['contact_error'])) {
    $error_message = $_SESSION['contact_error'];
    unset($_SESSION['contact_error']);
}

// IMPORTANT: Do NOT close $conn here. It's needed by header.php.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-contact-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-contact-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .contact-form-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-contact-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Contact Us</h1>
                <p class="mt-2 text-lg text-purple-200">Have a question? We'd love to hear from you.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>

            <div class="contact-form-card">
                <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Send Us a Message</h2>
                <form action="process_contact_form.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Your Name:</label>
                        <input type="text" name="name" id="name" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Your Email Address:</label>
                        <input type="email" name="email" id="email" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="subject" class="block text-gray-700 text-sm font-bold mb-2">Subject (Optional):</label>
                        <input type="text" name="subject" id="subject" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="mobile_no" class="block text-gray-700 text-sm font-bold mb-2">Mobile No. (Optional):</label>
                        <input type="tel" name="mobile_no" id="mobile_no" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="md:col-span-2">
                        <label for="message" class="block text-gray-700 text-sm font-bold mb-2">Your Message:</label>
                        <textarea name="message" id="message" rows="6" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Write your message here..."></textarea>
                    </div>
                    <div class="md:col-span-2 flex justify-center">
                        <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg shadow-md flex items-center justify-center">
                            Send Message <i data-lucide="send" class="w-5 h-5 ml-2"></i>
                        </button>
                    </div>
                </form>
            </div>

            <div class="text-center mt-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Other Ways to Reach Us</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
                        <i data-lucide="mail" class="w-12 h-12 text-blue-600 mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800">Email Us</h3>
                        <p class="text-gray-600">For general inquiries</p>
                        <a href="mailto:info@giftkarte.com" class="text-purple-600 hover:underline mt-2">info@giftkarte.com</a>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
                        <i data-lucide="phone" class="w-12 h-12 text-green-600 mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800">Call Us</h3>
                        <p class="text-gray-600">Customer Service Hotline</p>
                        <a href="tel:+9221111694438" class="text-purple-600 hover:underline mt-2">021-111-MYGIFT (694438)</a>
                    </div>
                    <div class="bg-white p-6 rounded-lg shadow-md flex flex-col items-center">
                        <i data-lucide="map-pin" class="w-12 h-12 text-red-600 mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800">Our Office</h3>
                        <p class="text-gray-600 text-center">ABC Towers, Suite 101, Main Boulevard, Karachi, Pakistan</p>
                        <a href="#" class="text-purple-600 hover:underline mt-2">Get Directions</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
