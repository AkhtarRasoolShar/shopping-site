<?php
/*
=========================================================
 File: about_gifted_me.php (NEW)
 Description: About Us page for Gifted Me.
 Location: /about_gifted_me.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-about-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-about-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .section-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-about-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">About Gifted Me</h1>
                <p class="mt-2 text-lg text-purple-200">Your ultimate destination for digital gifting.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="section-card">
                <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Our Mission</h2>
                <p class="text-gray-700 leading-relaxed text-lg text-center max-w-3xl mx-auto">
                    At Gifted Me, our mission is to revolutionize the way people give and receive gifts in Pakistan. We strive to provide a seamless, convenient, and joyful digital gifting experience that connects individuals with their favorite brands and enables them to celebrate every occasion with thoughtfulness and ease.
                </p>
            </div>

            <div class="section-card">
                <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Who We Are</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    Gifted Me is Pakistan's premier digital gift card marketplace, offering a diverse range of E-Gift Cards from top national and international brands. We understand the challenges of traditional gifting, from finding the right item to ensuring timely delivery. That's why we built a platform that puts choice, convenience, and personalization at your fingertips.
                </p>
                <p class="text-gray-700 leading-relaxed">
                    Our platform simplifies the gifting process, allowing you to send digital gift cards redeemable at thousands of retail stores and online platforms across the country. Whether it's a birthday, anniversary, Eid, or a corporate incentive, Gifted Me ensures your gift is perfect every time.
                </p>
            </div>

            <div class="section-card">
                <h2 class="text-3xl font-bold text-gray-800 mb-6 text-center">Our Values</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 text-center">
                    <div>
                        <i data-lucide="heart" class="w-12 h-12 text-purple-600 mx-auto mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Customer Centricity</h3>
                        <p class="text-gray-600 text-sm">We put our users first, constantly striving to enhance their experience.</p>
                    </div>
                    <div>
                        <i data-lucide="sparkles" class="w-12 h-12 text-blue-600 mx-auto mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Innovation</h3>
                        <p class="text-gray-600 text-sm">We embrace technology to offer unique and cutting-edge gifting solutions.</p>
                    </div>
                    <div>
                        <i data-lucide="shield-check" class="w-12 h-12 text-green-600 mx-auto mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Trust & Security</h3>
                        <p class="text-gray-600 text-sm">Ensuring the safety and privacy of our users' data is our top priority.</p>
                    </div>
                    <div>
                        <i data-lucide="handshake" class="w-12 h-12 text-yellow-600 mx-auto mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Partnership</h3>
                        <p class="text-gray-600 text-sm">We foster strong relationships with brands to bring you the best choices.</p>
                    </div>
                    <div>
                        <i data-lucide="smile" class="w-12 h-12 text-pink-600 mx-auto mb-4"></i>
                        <h3 class="text-xl font-semibold text-gray-800 mb-2">Joy & Simplicity</h3>
                        <p class="text-gray-600 text-sm">We believe gifting should be easy, delightful, and bring smiles.</p>
                    </div>
                </div>
            </div>

            <div class="text-center mt-12">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Join Us on Our Journey!</h2>
                <p class="text-gray-600 max-w-xl mx-auto mb-6">
                    Be a part of Pakistan's digital gifting revolution. Explore our wide range of E-Gift Cards today.
                </p>
                <a href="products.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg text-lg inline-flex items-center shadow-md">
                    <i data-lucide="package" class="w-5 h-5 mr-2"></i> Browse Gift Cards
                </a>
            </div>

        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
