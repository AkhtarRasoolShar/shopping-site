<?php
/*
=========================================================
 File: search_results.php (NEW)
 Description: Displays products based on a search query.
 Location: /search_results.php
=========================================================
*/
session_start();
require_once 'db.php';

$search_query = '';
$products = [];

if (isset($_GET['query'])) {
    $search_query = trim($_GET['query']);

    // Use a prepared statement to prevent SQL injection
    $sql = "SELECT id, name, category, image, price FROM products WHERE name LIKE ? OR category LIKE ?";
    $stmt = $conn->prepare($sql);

    // Add wildcard characters for the LIKE search
    $search_term = "%" . $search_query . "%";
    $stmt->bind_param("ss", $search_term, $search_term);

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $products = $result->fetch_all(MYSQLI_ASSOC);
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Search Results for "<?= htmlspecialchars($search_query) ?>"</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">Search Results</h1>
        <p class="text-gray-600 mb-8">Showing results for: <span class="font-semibold">"<?= htmlspecialchars($search_query) ?>"</span></p>

        <?php if (empty($products)): ?>
            <div class="bg-white rounded-lg shadow-lg p-8 text-center">
                <i data-lucide="search-x" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-xl font-semibold text-gray-700">No products found.</h2>
                <p class="text-gray-500 mt-2">We couldn't find any products matching your search. Please try a different term.</p>
                <a href="index.php" class="mt-6 inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">
                    &larr; Back to Homepage
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php foreach ($products as $product): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                        <a href="product_detail.php?id=<?= $product['id'] ?>">
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-48 object-cover" onerror="this.onerror=null;this.src='https://placehold.co/400x300/e2e8f0/4a5568?text=Image+Not+Found';">
                            <div class="p-4">
                                <h3 class="text-lg font-semibold text-gray-900 truncate"><?= htmlspecialchars($product['name']) ?></h3>
                                <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                                <p class="text-lg font-bold text-purple-700 mt-2">PKR <?= number_format($product['price'], 2) ?></p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
