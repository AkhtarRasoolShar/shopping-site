
<?php
/*
=========================================================
 File: delete_client.php
 Description: Deletes a client from the database.
 Location: /admin/delete_client.php
=========================================================
*/
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

$client_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if ($client_id) {
    // Optional: You might want to delete the logo file from the server as well
    // $stmt = $conn->prepare("SELECT logo_url FROM clients WHERE id = ?");
    // $stmt->bind_param("i", $client_id);
    // $stmt->execute();
    // $result = $stmt->get_result()->fetch_assoc();
    // if ($result && file_exists('../' . $result['logo_url'])) {
    //     unlink('../' . $result['logo_url']);
    // }
    // $stmt->close();

    $stmt = $conn->prepare("DELETE FROM clients WHERE id = ?");
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $stmt->close();
}
header("Location: clients.php?message=deleted");
exit;
?>
