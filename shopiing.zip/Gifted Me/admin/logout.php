<?php
/*
=========================================================
 File: logout.php
 Description: Destroys admin session and redirects to login.
 Location: /admin/logout.php
=========================================================
*/
session_start(); // Start the session to access session variables.

// Unset all of the session variables.
$_SESSION = array();

// Destroy the session.
session_destroy();

// Redirect to the admin login page.
header("location: index.php");
exit;
?>
