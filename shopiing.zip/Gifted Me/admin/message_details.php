<?php
/*
=========================================================
 File: message_details.php (NEW)
 Description: Displays full details of a specific user message.
 Location: /admin/message_details.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

$message_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$message_details = null;

if ($message_id !== false) {
    // Fetch message details
    $sql = "SELECT id, sender_name, company_name, mobile_no, email, message, received_at, is_read FROM contact_messages WHERE id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $message_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 1) {
            $message_details = $result->fetch_assoc();
            // Optionally, mark as read immediately upon viewing
            if (!$message_details['is_read']) {
                $stmt_update_read = $conn->prepare("UPDATE contact_messages SET is_read = TRUE WHERE id = ?");
                $stmt_update_read->bind_param("i", $message_id);
                $stmt_update_read->execute();
                $stmt_update_read->close();
                $message_details['is_read'] = TRUE; // Update in memory
            }
        }
        $stmt->close();
    }
}

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Message Details #<?= htmlspecialchars($message_id) ?> - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                    <li class="mb-4"><a href="messages.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="mail" class="w-5 h-5 mr-3"></i>Messages</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Message Details</h2>

            <div class="mb-6">
                <a href="messages.php" class="text-blue-600 hover:underline flex items-center mb-4">
                    <i data-lucide="arrow-left" class="w-5 h-5 mr-2"></i> Back to Messages
                </a>
            </div>

            <?php if (!$message_details): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative">
                    Message not found or invalid ID.
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                        <div>
                            <p class="text-gray-600 font-semibold">From:</p>
                            <p class="text-lg text-gray-800"><?= htmlspecialchars($message_details['sender_name']) ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600 font-semibold">Company:</p>
                            <p class="text-lg text-gray-800"><?= htmlspecialchars($message_details['company_name']) ?></p>
                        </div>
                        <div>
                            <p class="text-gray-600 font-semibold">Email:</p>
                            <p class="text-lg text-blue-600 break-words"><a href="mailto:<?= htmlspecialchars($message_details['email']) ?>"><?= htmlspecialchars($message_details['email']) ?></a></p>
                        </div>
                        <div>
                            <p class="text-gray-600 font-semibold">Mobile No.:</p>
                            <p class="text-lg text-gray-800"><?= htmlspecialchars($message_details['mobile_no']) ?></p>
                        </div>
                        <div class="md:col-span-2">
                            <p class="text-gray-600 font-semibold">Received At:</p>
                            <p class="text-lg text-gray-800"><?= date('F j, Y H:i:s', strtotime($message_details['received_at'])) ?></p>
                        </div>
                        <div class="md:col-span-2">
                            <p class="text-gray-600 font-semibold">Status:</p>
                            <p class="text-lg <?= $message_details['is_read'] ? 'text-green-600' : 'text-yellow-600' ?> font-bold">
                                <?= $message_details['is_read'] ? 'Read' : 'Unread' ?>
                            </p>
                        </div>
                    </div>

                    <div class="border-t border-gray-200 pt-6 mt-6">
                        <p class="text-gray-600 font-semibold mb-2">Message:</p>
                        <div class="bg-gray-50 p-4 rounded-lg leading-relaxed text-gray-800">
                            <?= nl2br(htmlspecialchars($message_details['message'])) ?>
                        </div>
                    </div>

                    <div class="mt-8 flex justify-end space-x-3">
                        <?php if (!$message_details['is_read']): ?>
                            <a href="messages.php?mark_read_id=<?= $message_details['id'] ?>&status=read" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg">Mark as Read</a>
                        <?php else: ?>
                            <a href="messages.php?mark_read_id=<?= $message_details['id'] ?>&status=unread" class="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-2 px-4 rounded-lg">Mark as Unread</a>
                        <?php endif; ?>
                        <a href="messages.php?delete_id=<?= $message_details['id'] ?>" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg" onclick="return confirm('Are you sure you want to delete this message?');">Delete</a>
                    </div>
                </div>
            <?php endif; ?>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
