<?php
/*
=========================================================
 File: add_testimonial.php (NEW)
 Description: Allows admin to add a new testimonial.
 Location: /admin/add_testimonial.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

$error_message = '';
$success_message = '';

// Handle Add Testimonial Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_testimonial'])) {
    $name = trim($_POST['name']);
    $quote = trim($_POST['quote']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $user_image_path = null;

    // Validate input
    if (empty($name) || empty($quote)) {
        $error_message = "Name and Quote cannot be empty.";
    } else {
        // Handle User Image Upload (Optional)
        if (isset($_FILES['user_image']) && $_FILES['user_image']['error'] == UPLOAD_ERR_OK) {
            $target_dir = "../uploads/testimonial_images/"; // Relative path from admin/ to shopping/uploads/testimonial_images/

            // Create directory if it doesn't exist
            if (!file_exists($target_dir)) {
                if (!mkdir($target_dir, 0777, true)) { // Recursive creation with full permissions
                    $error_message = 'Server error: Failed to create upload directory for images.';
                }
            } elseif (!is_writable($target_dir)) {
                $error_message = 'Server error: Upload directory for images is not writable.';
            }

            // Proceed with upload if no directory errors
            if (empty($error_message)) {
                $file_extension = strtolower(pathinfo($_FILES['user_image']['name'], PATHINFO_EXTENSION));
                $unique_filename = uniqid('testimonial_') . '.' . $file_extension;
                $target_file = $target_dir . $unique_filename;

                // Validate file type and size
                $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
                $max_file_size = 2 * 1024 * 1024; // 2MB

                if (!in_array($file_extension, $allowed_extensions)) {
                    $error_message = 'Invalid image file type. Only JPG, JPEG, PNG, GIF are allowed.';
                }
                if ($_FILES['user_image']['size'] > $max_file_size) {
                    $error_message = 'Image file size exceeds 2MB limit.';
                }

                if (empty($error_message)) { // Check errors again after file specific validation
                    if (move_uploaded_file($_FILES["user_image"]["tmp_name"], $target_file)) {
                        $user_image_path = str_replace('../', '', $target_file); // Store path relative to shopping/
                    } else {
                        $error_message = 'Failed to upload user image. Check folder permissions.';
                        error_log("move_uploaded_file failed for testimonial image: " . $_FILES["user_image"]["tmp_name"]);
                    }
                }
            }
        } elseif (isset($_FILES['user_image']) && $_FILES['user_image']['error'] != UPLOAD_ERR_NO_FILE) {
            $error_message = 'An unexpected file upload error occurred for image: Code ' . $_FILES['user_image']['error'];
            error_log("Testimonial image upload error code: " . $_FILES['user_image']['error']);
        }
    }

    // If no validation or upload errors, proceed to insert into database
    if (empty($error_message)) {
        $stmt_insert = $conn->prepare("INSERT INTO testimonials (name, quote, is_active, user_image) VALUES (?, ?, ?, ?)");
        if ($stmt_insert) {
            $stmt_insert->bind_param("ssis", $name, $quote, $is_active, $user_image_path);
            if ($stmt_insert->execute()) {
                $success_message = "Testimonial from '" . htmlspecialchars($name) . "' added successfully.";
                // Clear form data by redirecting or resetting variables
                $_POST = array(); // Clear post data to prevent re-submission on refresh
            } else {
                $error_message = "Error adding testimonial to database: " . $stmt_insert->error;
            }
            $stmt_insert->close();
        } else {
            $error_message = "Database prepare failed: " . $conn->error;
        }
    }
}

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Testimonial - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Add New Testimonial</h2>

            <div class="mb-6">
                <a href="testimonials.php" class="text-blue-600 hover:underline flex items-center mb-4">
                    <i data-lucide="arrow-left" class="w-5 h-5 mr-2"></i> Back to Testimonials List
                </a>
            </div>

            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-lg p-6 max-w-md mx-auto">
                <form action="add_testimonial.php" method="post" enctype="multipart/form-data">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Customer Name:</label>
                        <input type="text" name="name" id="name" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="mb-4">
                        <label for="quote" class="block text-gray-700 text-sm font-bold mb-2">Testimonial Quote:</label>
                        <textarea name="quote" id="quote" rows="4" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"></textarea>
                    </div>
                    <div class="mb-4">
                        <label for="user_image" class="block text-gray-700 text-sm font-bold mb-2">User Image (Optional):</label>
                        <input type="file" name="user_image" id="user_image" accept="image/*" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        <p class="text-xs text-gray-500 mt-1">Accepted: JPG, PNG, GIF. Max 2MB.</p>
                    </div>
                    <div class="mb-6">
                        <label class="flex items-center text-gray-700 text-sm font-bold">
                            <input type="checkbox" name="is_active" id="is_active" value="1" checked class="form-checkbox h-4 w-4 text-purple-600 rounded">
                            <span class="ml-2">Active Testimonial (Display on site)</span>
                        </label>
                    </div>
                    <div class="flex items-center justify-between">
                        <button type="submit" name="add_testimonial" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline">
                            Save Testimonial
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
