<?php
/*
=========================================================
 File: delete_testimonial.php (NEW)
 Description: Processes testimonial deletion.
 Location: /admin/delete_testimonial.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

if (isset($_GET['id'])) {
    $testimonial_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if ($testimonial_id) {
        // Fetch image path before deleting the testimonial record
        $image_to_delete = null;
        $stmt_fetch_image = $conn->prepare("SELECT user_image FROM testimonials WHERE id = ?");
        if ($stmt_fetch_image) {
            $stmt_fetch_image->bind_param("i", $testimonial_id);
            $stmt_fetch_image->execute();
            $stmt_fetch_image->bind_result($image_to_delete);
            $stmt_fetch_image->fetch();
            $stmt_fetch_image->close();
        }

        // Delete the testimonial from the database
        $stmt_delete = $conn->prepare("DELETE FROM testimonials WHERE id = ?");
        if ($stmt_delete) {
            $stmt_delete->bind_param("i", $testimonial_id);
            if ($stmt_delete->execute()) {
                // If testimonial deleted from DB, attempt to delete its image file
                if (!empty($image_to_delete) && file_exists('../' . $image_to_delete)) {
                    unlink('../' . $image_to_delete); // Delete image file from server
                }
                $_SESSION['testimonial_delete_success'] = "Testimonial deleted successfully.";
            } else {
                $_SESSION['testimonial_delete_error'] = "Error deleting testimonial: " . $stmt_delete->error;
            }
            $stmt_delete->close();
        } else {
            $_SESSION['testimonial_delete_error'] = "Database prepare failed: " . $conn->error;
        }
    } else {
        $_SESSION['testimonial_delete_error'] = "Invalid testimonial ID.";
    }
} else {
    $_SESSION['testimonial_delete_error'] = "No testimonial ID provided for deletion.";
}

$conn->close(); // Close the database connection.
header("Location: testimonials.php"); // Redirect back to testimonials list
exit;
