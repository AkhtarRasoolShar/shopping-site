<?php
/*
=========================================================
 File: testimonials.php (UPDATED: Added Edit/Delete links and messages)
 Description: Displays and manages testimonials.
 Location: /admin/testimonials.php
=========================================================
*/
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

// Fetch all testimonials
$sql = "SELECT id, name, quote, is_active FROM testimonials ORDER BY created_at DESC";
$result = $conn->query($sql);
$testimonials = [];
if ($result->num_rows > 0) {
    $testimonials = $result->fetch_all(MYSQLI_ASSOC);
}

// Display messages from process_delete_testimonial.php or edit_testimonial.php
$success_message = '';
$error_message = '';
if (isset($_SESSION['testimonial_delete_success'])) {
    $success_message = $_SESSION['testimonial_delete_success'];
    unset($_SESSION['testimonial_delete_success']);
}
if (isset($_SESSION['testimonial_delete_error'])) {
    $error_message = $_SESSION['testimonial_delete_error'];
    unset($_SESSION['testimonial_delete_error']);
}
if (isset($_SESSION['testimonial_edit_success'])) { // Assuming edit_testimonial.php might set this
    $success_message = $_SESSION['testimonial_edit_success'];
    unset($_SESSION['testimonial_edit_success']);
}
if (isset($_SESSION['testimonial_edit_error'])) { // Assuming edit_testimonial.php might set this
    $error_message = $_SESSION['testimonial_edit_error'];
    unset($_SESSION['testimonial_edit_error']);
}

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Testimonials</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                    <li class="mb-4"><a href="messages.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="mail" class="w-5 h-5 mr-3"></i>Messages</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>
        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Manage Testimonials</h2>

            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-semibold text-gray-700">Testimonials List</h3>
                    <a href="add_testimonial.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg flex items-center"><i data-lucide="plus" class="w-5 h-5 mr-2"></i>Add Testimonial</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="p-4 font-semibold">ID</th>
                                <th class="p-4 font-semibold">Name</th>
                                <th class="p-4 font-semibold">Quote (Partial)</th>
                                <th class="p-4 font-semibold">Active</th>
                                <th class="p-4 font-semibold text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($testimonials)): ?>
                                <tr><td colspan="5" class="text-center p-6 text-gray-500">No testimonials found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($testimonials as $testimonial): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-4"><?= htmlspecialchars($testimonial['id']) ?></td>
                                        <td class="p-4"><?= htmlspecialchars($testimonial['name']) ?></td>
                                        <td class="p-4"><?= htmlspecialchars(substr($testimonial['quote'], 0, 70)) ?><?= (strlen($testimonial['quote']) > 70) ? '...' : '' ?></td>
                                        <td class="p-4">
                                            <span class="px-2 py-1 rounded-full text-xs font-semibold <?= $testimonial['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800' ?>">
                                                <?= $testimonial['is_active'] ? 'Yes' : 'No' ?>
                                            </span>
                                        </td>
                                        <td class="p-4 text-right whitespace-nowrap">
                                            <a href="edit_testimonial.php?id=<?= $testimonial['id'] ?>" class="text-blue-600 hover:underline mr-4">Edit</a>
                                            <a href="delete_testimonial.php?id=<?= $testimonial['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Are you sure you want to delete this testimonial?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
