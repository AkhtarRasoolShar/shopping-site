<?php
/*
=========================================================
 File: live_view.php (UPDATED: Total Lifetime Visitors Count)
 Description: Displays live visitor activity and total lifetime visitors.
 Location: /admin/live_view.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

// Handle Clear Logs (only clears current 'live' data in visitor_logs)
// If you want to clear total lifetime visitors too, you might need a separate table for that.
if (isset($_POST['clear_logs'])) {
    $conn->query("TRUNCATE TABLE visitor_logs");
    header("Location: live_view.php"); // Redirect to refresh the page after clearing
    exit;
}

// Calculate time threshold for "live" visitors (e.g., last 30 minutes)
$threshold_time = date('Y-m-d H:i:s', strtotime('-30 minutes'));

// Fetch Live Visitors Count
// Count unique IP addresses active within the threshold
$sql_live_count = "SELECT COUNT(DISTINCT ip_address) as live_count FROM visitor_logs WHERE visit_time > ?";
$stmt_live_count = $conn->prepare($sql_live_count);
$stmt_live_count->bind_param("s", $threshold_time);
$stmt_live_count->execute();
$live_visitors_count = $stmt_live_count->get_result()->fetch_assoc()['live_count'];
$stmt_live_count->close();

// Fetch Total Lifetime Unique Visitors Count
$sql_total_unique_visitors = "SELECT COUNT(DISTINCT ip_address) as total_unique_count FROM visitor_logs";
$total_unique_visitors_count = $conn->query($sql_total_unique_visitors)->fetch_assoc()['total_unique_count'];


// Fetch detailed live visitor data
// Group by IP to get the last seen time and count distinct pages viewed by that IP
$sql_visitors_data = "
    SELECT
        ip_address,
        MAX(visit_time) AS last_seen,
        COUNT(DISTINCT page_url) AS pages_viewed_count
    FROM
        visitor_logs
    WHERE
        visit_time > ?
    GROUP BY
        ip_address
    ORDER BY
        last_seen DESC
";
$stmt_visitors_data = $conn->prepare($sql_visitors_data);
$stmt_visitors_data->bind_param("s", $threshold_time);
$stmt_visitors_data->execute();
$result_visitors_data = $stmt_visitors_data->get_result();
$live_visitors_data = [];
if ($result_visitors_data->num_rows > 0) {
    $live_visitors_data = $result_visitors_data->fetch_all(MYSQLI_ASSOC);
}
$stmt_visitors_data->close();

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Live Visitor Report - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
    <meta http-equiv="refresh" content="30">
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <header class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Live Visitor Report</h2>
                <form method="POST" action="live_view.php" onsubmit="return confirm('Are you sure you want to clear ALL visitor logs? This action cannot be undone.');">
                    <button type="submit" name="clear_logs" class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-lg flex items-center">
                        Clear Logs
                    </button>
                </form>
            </header>
            <p class="text-gray-500 mb-6">Showing unique visitors from the last 30 minutes. This page auto-refreshes every 30 seconds.</p>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-purple-100 p-3 rounded-full mr-4">
                        <i data-lucide="activity" class="w-6 h-6 text-purple-600"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Live Visitors Now</p>
                        <p class="text-3xl font-bold text-red-600"><?= $live_visitors_count ?></p>
                    </div>
                </div>

                <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-blue-100 p-3 rounded-full mr-4">
                        <i data-lucide="earth" class="w-6 h-6 text-blue-600"></i>
                    </div>
                    <div>
                        <p class="text-gray-500 text-sm">Total Lifetime Unique Visitors</p>
                        <p class="text-3xl font-bold text-blue-600"><?= $total_unique_visitors_count ?></p>
                    </div>
                </div>
            </div>


            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="p-4 font-semibold">IP Address</th>
                                <th class="p-4 font-semibold">Last Seen</th>
                                <th class="p-4 font-semibold">Pages Viewed (in last 30 mins)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($live_visitors_data)): ?>
                                <tr><td colspan="3" class="text-center p-6 text-gray-500">No active visitors in the last 30 minutes.</td></tr>
                            <?php else: ?>
                                <?php foreach ($live_visitors_data as $visitor): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-4"><?= htmlspecialchars($visitor['ip_address']) ?></td>
                                        <td class="p-4"><?= date('M j, Y H:i:s', strtotime($visitor['last_seen'])) ?></td>
                                        <td class="p-4"><?= htmlspecialchars($visitor['pages_viewed_count']) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
