<?php
/*
=========================================================
 File: categories.php (FIXED: Duplicate Entry Error)
 Description: Manages product categories.
 Location: /admin/categories.php
=========================================================
*/
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

$error_message = '';
$success_message = '';

// Handle Add Category
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $category_name = trim($_POST['category_name']);
    if (!empty($category_name)) {
        // --- ADDED: Check if category already exists ---
        $stmt_check = $conn->prepare("SELECT id FROM categories WHERE name = ?");
        $stmt_check->bind_param("s", $category_name);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows > 0) {
            $error_message = "Category '{$category_name}' already exists.";
        } else {
            // Original insert logic if category does not exist
            $stmt_insert = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
            $stmt_insert->bind_param("s", $category_name);
            if ($stmt_insert->execute()) {
                $success_message = "Category '{$category_name}' added successfully.";
            } else {
                $error_message = "Error adding category: " . $stmt_insert->error;
            }
            $stmt_insert->close();
        }
        $stmt_check->close();
    } else {
        $error_message = "Category name cannot be empty.";
    }
}

// Handle Delete Category
if (isset($_GET['delete_id'])) {
    $delete_id = filter_input(INPUT_GET, 'delete_id', FILTER_VALIDATE_INT);
    if ($delete_id) {
        $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
        $stmt->bind_param("i", $delete_id);
        if ($stmt->execute()) {
            $success_message = "Category deleted successfully.";
        } else {
            $error_message = "Error deleting category: " . $stmt->error;
        }
        $stmt->close();
        header("Location: categories.php");
        exit;
    }
}

// Fetch all categories
$sql = "SELECT id, name FROM categories ORDER BY name ASC";
$result = $conn->query($sql);
$categories = [];
if ($result->num_rows > 0) {
    $categories = $result->fetch_all(MYSQLI_ASSOC);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Categories</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>
        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Manage Categories</h2>
            <?php if($error_message): ?><div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6"><?= $error_message ?></div><?php endif; ?>
            <?php if($success_message): ?><div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6"><?= $success_message ?></div><?php endif; ?>
            <div class="grid md:grid-cols-2 gap-8">
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-xl font-semibold mb-4">Add New Category</h3>
                    <form action="categories.php" method="post">
                        <label for="category_name" class="block text-gray-700 text-sm font-bold mb-2">Category Name</label>
                        <input type="text" name="category_name" id="category_name" required class="shadow-sm border rounded w-full py-2 px-3">
                        <button type="submit" name="add_category" class="mt-4 w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">Add Category</button>
                    </form>
                </div>
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-xl font-semibold mb-4">Existing Categories</h3>
                    <ul class="divide-y divide-gray-200">
                        <?php if (empty($categories)): ?>
                            <li class="py-2 text-center text-gray-500">No categories added yet.</li>
                        <?php else: ?>
                            <?php foreach ($categories as $category): ?>
                                <li class="py-2 flex justify-between items-center">
                                    <span><?= htmlspecialchars($category['name']) ?></span>
                                    <a href="categories.php?delete_id=<?= $category['id'] ?>" class="text-red-500 hover:text-red-700" onclick="return confirm('Are you sure? This cannot be undone.')"><i data-lucide="trash-2" class="w-4 h-4"></i></a>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
