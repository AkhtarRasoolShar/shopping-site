<?php
/*
=========================================================
 File: edit_order_status.php
 Description: Allows admin to edit the status of a specific order.
 Location: /admin/edit_order_status.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: orders.php"); // Redirect to orders list if no ID
    exit;
}

$order_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$order_id) {
    header("Location: orders.php"); // Redirect if ID is invalid
    exit;
}

$current_status = '';
$error_message = '';
$success_message = '';

// Fetch current order status
$sql_fetch = "SELECT status FROM orders WHERE id = ?";
if ($stmt = $conn->prepare($sql_fetch)) {
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $stmt->bind_result($current_status);
    $stmt->fetch();
    $stmt->close();
} else {
    $error_message = "Error fetching order status.";
}

// Handle Status Update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status'])) {
    $new_status = trim($_POST['new_status']);

    if (!empty($new_status)) {
        $sql_update = "UPDATE orders SET status = ? WHERE id = ?";
        if ($stmt = $conn->prepare($sql_update)) {
            $stmt->bind_param("si", $new_status, $order_id);
            if ($stmt->execute()) {
                $success_message = "Order status updated successfully!";
                $current_status = $new_status; // Update displayed status
            } else {
                $error_message = "Error updating status: " . $conn->error;
            }
            $stmt->close();
        } else {
            $error_message = "Error preparing update statement: " . $conn->error;
        }
    } else {
        $error_message = "New status cannot be empty.";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Order Status #<?= htmlspecialchars($order_id) ?> - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Edit Order Status #<?= htmlspecialchars($order_id) ?></h2>

            <?php if($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            <?php if($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <p class="text-gray-700 text-lg mb-4">Current Status: <span class="font-semibold text-purple-700"><?= htmlspecialchars($current_status) ?></span></p>

                <form action="edit_order_status.php?id=<?= htmlspecialchars($order_id) ?>" method="post">
                    <div class="mb-4">
                        <label for="new_status" class="block text-gray-700 text-sm font-bold mb-2">New Status:</label>
                        <select name="new_status" id="new_status" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                            <option value="Pending" <?= ($current_status == 'Pending') ? 'selected' : '' ?>>Pending</option>
                            <option value="Processing" <?= ($current_status == 'Processing') ? 'selected' : '' ?>>Processing</option>
                            <option value="Shipped" <?= ($current_status == 'Shipped') ? 'selected' : '' ?>>Shipped</option>
                            <option value="Delivered" <?= ($current_status == 'Delivered') ? 'selected' : '' ?>>Delivered</option>
                            <option value="Cancelled" <?= ($current_status == 'Cancelled') ? 'selected' : '' ?>>Cancelled</option>
                            <option value="Refunded" <?= ($current_status == 'Refunded') ? 'selected' : '' ?>>Refunded</option>
                        </select>
                    </div>
                    <div class="flex items-center justify-between">
                        <button type="submit" name="update_status" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline">
                            Update Status
                        </button>
                        <a href="order_details.php?id=<?= htmlspecialchars($order_id) ?>" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg">
                            Cancel
                        </a>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
