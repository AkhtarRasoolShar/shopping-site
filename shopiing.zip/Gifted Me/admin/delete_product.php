<?php
/*
=========================================================
 File: delete_product.php (NEW)
 Description: Processes product deletion.
 Location: /admin/delete_product.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

if (isset($_GET['id'])) {
    $product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if ($product_id) {
        // Fetch image path before deleting the product record
        $image_to_delete = null;
        $stmt_fetch_image = $conn->prepare("SELECT image FROM products WHERE id = ?");
        if ($stmt_fetch_image) {
            $stmt_fetch_image->bind_param("i", $product_id);
            $stmt_fetch_image->execute();
            $stmt_fetch_image->bind_result($image_to_delete);
            $stmt_fetch_image->fetch();
            $stmt_fetch_image->close();
        }

        // Delete the product from the database
        $stmt_delete = $conn->prepare("DELETE FROM products WHERE id = ?");
        if ($stmt_delete) {
            $stmt_delete->bind_param("i", $product_id);
            if ($stmt_delete->execute()) {
                // If product deleted from DB, attempt to delete its image file
                if (!empty($image_to_delete) && file_exists('../' . $image_to_delete)) {
                    unlink('../' . $image_to_delete); // Delete image file from server
                }
                $_SESSION['product_delete_success'] = "Product deleted successfully.";
            } else {
                $_SESSION['product_delete_error'] = "Error deleting product: " . $stmt_delete->error;
            }
            $stmt_delete->close();
        } else {
            $_SESSION['product_delete_error'] = "Database prepare failed: " . $conn->error;
        }
    } else {
        $_SESSION['product_delete_error'] = "Invalid product ID.";
    }
} else {
    $_SESSION['product_delete_error'] = "No product ID provided for deletion.";
}

$conn->close(); // Close the database connection.
header("Location: products.php"); // Redirect back to products list
exit;
