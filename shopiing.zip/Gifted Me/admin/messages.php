<?php
/*
=========================================================
 File: messages.php (FIXED: Undefined array key "mobile_no")
 Description: Displays and manages user contact messages in the admin panel.
 Location: /admin/messages.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

$success_message = '';
$error_message = '';

// Handle marking message as read/unread
if (isset($_GET['mark_read_id']) && isset($_GET['status'])) {
    $message_id = filter_input(INPUT_GET, 'mark_read_id', FILTER_VALIDATE_INT);
    $new_status = ($_GET['status'] === 'read') ? TRUE : FALSE; // Boolean for DB

    if ($message_id !== false) {
        $stmt = $conn->prepare("UPDATE contact_messages SET is_read = ? WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $new_status, $message_id);
            if ($stmt->execute()) {
                $success_message = 'Message status updated.';
            } else {
                $error_message = 'Failed to update message status: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $error_message = 'Database prepare failed: ' . $conn->error;
        }
    } else {
        $error_message = 'Invalid message ID.';
    }
    // Redirect to clear URL parameters
    header("Location: messages.php");
    exit;
}

// Handle deleting message
if (isset($_GET['delete_id'])) {
    $message_id = filter_input(INPUT_GET, 'delete_id', FILTER_VALIDATE_INT);

    if ($message_id !== false) {
        $stmt = $conn->prepare("DELETE FROM contact_messages WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("i", $message_id);
            if ($stmt->execute()) {
                $success_message = 'Message deleted successfully.';
            } else {
                $error_message = 'Failed to delete message: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $error_message = 'Database prepare failed: ' . $conn->error;
        }
    } else {
        $error_message = 'Invalid message ID.';
    }
    header("Location: messages.php");
    exit;
}


// Fetch all messages (newest first)
// Ensure all these columns exist in your contact_messages table.
$sql_messages = "SELECT id, sender_name, company_name, mobile_no, email, message, received_at, is_read FROM contact_messages ORDER BY received_at DESC";
$result_messages = $conn->query($sql_messages);
$messages = [];
if ($result_messages) {
    $messages = $result_messages->fetch_all(MYSQLI_ASSOC);
} else {
    $error_message = "Failed to fetch messages: " . $conn->error;
}

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Messages - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .message-row.unread {
            background-color: #fffbeb; /* light yellow for unread */
            font-weight: 600;
        }
    </style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                    <li class="mb-4"><a href="messages.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="mail" class="w-5 h-5 mr-3"></i>Messages</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">User Messages</h2>

            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <?php if (empty($messages)): ?>
                    <div class="text-center p-6 text-gray-500">No messages found.</div>
                <?php else: ?>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-gray-50 border-b">
                                <tr>
                                    <th class="p-4 font-semibold">Sender</th>
                                    <th class="p-4 font-semibold">Company / Email</th>
                                    <th class="p-4 font-semibold">Message (Preview)</th>
                                    <th class="p-4 font-semibold">Received At</th>
                                    <th class="p-4 font-semibold text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($messages as $message): ?>
                                    <tr class="border-b hover:bg-gray-50 <?= $message['is_read'] ? '' : 'message-row unread' ?>">
                                        <td class="p-4 align-top">
                                            <?= htmlspecialchars($message['sender_name'] ?? '') ?><br>
                                            <span class="text-sm text-gray-500"><?= htmlspecialchars($message['mobile_no'] ?? '') ?></span>
                                        </td>
                                        <td class="p-4 align-top">
                                            <?= htmlspecialchars($message['company_name'] ?? '') ?><br>
                                            <span class="text-sm text-gray-500"><?= htmlspecialchars($message['email'] ?? '') ?></span>
                                        </td>
                                        <td class="p-4 align-top">
                                            <div class="max-w-xs overflow-hidden text-ellipsis whitespace-nowrap">
                                                <?= htmlspecialchars(substr($message['message'] ?? '', 0, 100)) ?><?= (strlen($message['message'] ?? '') > 100) ? '...' : '' ?>
                                            </div>
                                        </td>
                                        <td class="p-4 align-top text-sm text-gray-600">
                                            <?= date('M j, Y H:i', strtotime($message['received_at'] ?? 'now')) ?>
                                        </td>
                                        <td class="p-4 align-top text-right whitespace-nowrap">
                                            <a href="message_details.php?id=<?= $message['id'] ?>" class="text-blue-600 hover:underline mr-3">View</a>
                                            <?php if (!($message['is_read'] ?? true)): // Use ?? true to handle cases where is_read might not be set in older entries ?>
                                                <a href="messages.php?mark_read_id=<?= $message['id'] ?>&status=read" class="text-green-600 hover:underline mr-3">Mark Read</a>
                                            <?php else: ?>
                                                <a href="messages.php?mark_read_id=<?= $message['id'] ?>&status=unread" class="text-yellow-600 hover:underline mr-3">Mark Unread</a>
                                            <?php endif; ?>
                                            <a href="messages.php?delete_id=<?= $message['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Are you sure you want to delete this message?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
