<?php
/*
=========================================================
 File: process_edit_product.php (NEW)
 Description: Processes product edit form submission.
 Location: /admin/process_edit_product.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_product'])) {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $name = trim($_POST['name']);
    $category = trim($_POST['category']);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $description = trim($_POST['description']);
    $tags_input = isset($_POST['tags']) ? $_POST['tags'] : '';
    $tags_array = array_map('trim', explode(',', $tags_input));
    $tags_json = json_encode(array_filter($tags_array));
    $old_image_path = trim($_POST['old_image_path'] ?? ''); // Path stored relative to shopping/

    $image_path = $old_image_path; // Assume old image path by default
    $errors = [];

    // Basic validation
    if (!$product_id || empty($name) || empty($category) || $price === false || $price <= 0 || empty($description)) {
        $errors[] = "All fields (Name, Category, Price, Description) are required and Price must be positive.";
    }

    // Handle Product Image Upload
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] == UPLOAD_ERR_OK) {
        $target_dir = "../uploads/products/"; // Relative path from admin/ to shopping/uploads/products/

        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        } elseif (!is_writable($target_dir)) {
            $errors[] = 'Server error: Upload directory is not writable.';
        }

        if (empty($errors)) {
            $file_extension = strtolower(pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION));
            $unique_filename = uniqid('product_') . '.' . $file_extension;
            $new_target_file = $target_dir . $unique_filename;

            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
            $max_file_size = 5 * 1024 * 1024; // 5MB

            if (!in_array($file_extension, $allowed_extensions)) {
                $errors[] = 'Invalid image file type. Only JPG, JPEG, PNG, GIF are allowed.';
            }
            if ($_FILES['product_image']['size'] > $max_file_size) {
                $errors[] = 'Image file size exceeds 5MB limit.';
            }

            if (empty($errors)) {
                if (move_uploaded_file($_FILES["product_image"]["tmp_name"], $new_target_file)) {
                    $image_path = str_replace('../', '', $new_target_file); // Store new path relative to shopping/
                    // Optionally, delete old image if new one uploaded successfully
                    if (!empty($old_image_path) && file_exists('../' . $old_image_path)) {
                        unlink('../' . $old_image_path);
                    }
                } else {
                    $errors[] = 'Failed to upload new product image.';
                    error_log("move_uploaded_file failed for product image: " . $_FILES["product_image"]["tmp_name"]);
                }
            }
        }
    } elseif (isset($_FILES['product_image']) && $_FILES['product_image']['error'] != UPLOAD_ERR_NO_FILE) {
        $errors[] = 'An unexpected file upload error occurred: Code ' . $_FILES['product_image']['error'];
        error_log("Product image upload error code: " . $_FILES['product_image']['error']);
    }

    // If any validation or upload errors, set session message and redirect
    if (!empty($errors)) {
        $_SESSION['product_edit_error'] = implode('<br>', $errors);
        header("Location: edit_product.php?id=" . $product_id);
        exit;
    }

    // Update product in database
    $stmt_update = $conn->prepare("UPDATE products SET name = ?, category = ?, price = ?, description = ?, tags = ?, image = ? WHERE id = ?");
    if ($stmt_update) {
        $stmt_update->bind_param("ssdsisi", $name, $category, $price, $description, $tags_json, $image_path, $product_id);
        if ($stmt_update->execute()) {
            $_SESSION['product_edit_success'] = "Product '" . htmlspecialchars($name) . "' updated successfully.";
        } else {
            $_SESSION['product_edit_error'] = "Error updating product: " . $stmt_update->error;
        }
        $stmt_update->close();
    } else {
        $_SESSION['product_edit_error'] = "Database prepare failed: " . $conn->error;
    }

    $conn->close(); // Close the database connection.
    header("Location: edit_product.php?id=" . $product_id); // Redirect back to edit page or products list
    exit;

} else {
    // Redirect if accessed directly without POST
    header("Location: products.php");
    exit;
}
?>
