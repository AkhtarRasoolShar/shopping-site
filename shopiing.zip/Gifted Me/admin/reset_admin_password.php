<?php
/*
=========================================================
 File: reset_admin_password.php
 Description: A utility script to reset an admin's password.
 Location: /admin/reset_admin_password.php (temporary)
=========================================================
*/

// --- INSTRUCTIONS ---
// 1. Change the $username and $new_password variables below.
// 2. Upload this file to your /admin/ directory.
// 3. Access it from your browser (e.g., yoursite.com/admin/reset_admin_password.php).
// 4. You will see a success or error message.
// 5. IMPORTANT: DELETE THIS FILE FROM YOUR SERVER IMMEDIATELY AFTER USE.

// --- CONFIGURATION ---
$username_to_reset = 'admin'; // The username of the admin account you want to reset.
$new_password      = 'new_secure_password123'; // The new password you want to set.


// --- SCRIPT LOGIC (No need to edit below this line) ---
require_once '../db.php';

echo "<!DOCTYPE html><html lang='en'><head><meta charset='UTF-8'><title>Admin Password Reset</title><style>body { font-family: sans-serif; padding: 2em; line-height: 1.6; } .success { color: green; } .error { color: red; }</style></head><body>";
echo "<h1>Admin Password Reset Utility</h1>";

if (empty($username_to_reset) || empty($new_password)) {
    echo "<p class='error'>Error: Please set the \$username_to_reset and \$new_password variables inside the script.</p>";
    exit;
}

// Hash the new password for secure storage
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

// Prepare the update statement
$stmt = $conn->prepare("UPDATE admins SET password = ? WHERE username = ?");

if ($stmt === false) {
    echo "<p class='error'>Error preparing statement: " . htmlspecialchars($conn->error) . "</p>";
    exit;
}

$stmt->bind_param("ss", $hashed_password, $username_to_reset);

// Execute the statement
if ($stmt->execute()) {
    // Check if any row was actually updated
    if ($stmt->affected_rows > 0) {
        echo "<p class='success'>Success! The password for user '<strong>" . htmlspecialchars($username_to_reset) . "</strong>' has been reset.</p>";
        echo "<p>Your new password is: <strong>" . htmlspecialchars($new_password) . "</strong></p>";
        echo "<p style='color:red; font-weight:bold;'>IMPORTANT: Please delete this file (reset_admin_password.php) from your server now!</p>";
    } else {
        echo "<p class='error'>Error: No user found with the username '<strong>" . htmlspecialchars($username_to_reset) . "</strong>'. No changes were made.</p>";
    }
} else {
    echo "<p class='error'>Error executing statement: " . htmlspecialchars($stmt->error) . "</p>";
}

$stmt->close();
$conn->close();

echo "</body></html>";
?>
