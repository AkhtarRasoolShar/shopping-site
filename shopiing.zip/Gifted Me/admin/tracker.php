<?php
/*
=========================================================
 File: tracker.php (NEW)
 Description: Logs visitor activity to the database.
 Location: /tracker.php
=========================================================
*/
// This file should be included in your main header.php

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Do not log visits from logged-in admins
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    return; // Exit script
}

require_once 'db.php';

$ip_address = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$page_url = $_SERVER['REQUEST_URI'];

// To avoid flooding the database, we can update the timestamp of the last visit
// from the same IP if it's within the last 5 minutes.
$stmt = $conn->prepare("SELECT id FROM visitor_logs WHERE ip_address = ? AND page_url = ? AND visit_time > (NOW() - INTERVAL 5 MINUTE)");
$stmt->bind_param("ss", $ip_address, $page_url);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 0) {
    // If no recent record, insert a new one
    $stmt_insert = $conn->prepare("INSERT INTO visitor_logs (ip_address, user_agent, page_url) VALUES (?, ?, ?)");
    $stmt_insert->bind_param("sss", $ip_address, $user_agent, $page_url);
    $stmt_insert->execute();
    $stmt_insert->close();
} else {
    // If there is a recent record, just update its timestamp
    $stmt_update = $conn->prepare("UPDATE visitor_logs SET visit_time = NOW() WHERE ip_address = ? AND page_url = ?");
    $stmt_update->bind_param("ss", $ip_address, $page_url);
    $stmt_update->execute();
    $stmt_update->close();
}

$stmt->close();
// Note: The connection is not closed here because the parent file (header.php) might still need it.
?>
