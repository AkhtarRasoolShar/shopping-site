<?php
/*
=========================================================
 File:
 Description: Database Connection
 Location: /db.php
=========================================================
*/

// --- DATABASE CONFIGURATION ---
// Replace with your actual database credentials.
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root'); // Your DB username
define('DB_PASSWORD', ''); // Your DB password
define('DB_NAME', 'shop'); // The database name you created

// --- ESTABLISH CONNECTION ---
// Create a new MySQLi object to connect to the database.
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// --- CHECK CONNECTION ---
// If the connection fails, terminate the script and display an error message.
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the character set to utf8mb4 for proper handling of all characters.
$conn->set_charset("utf8mb4");

?>
