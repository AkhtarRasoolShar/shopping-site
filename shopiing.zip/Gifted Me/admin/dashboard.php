<?php
/*
=========================================================
 File: dashboard.php (UPDATED: Added Messages link in sidebar)
 Description: Main admin dashboard with updated sidebar.
 Location: /admin/dashboard.php
=========================================================
*/
session_start();
require_once '../db.php';

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

// --- FETCH SUMMARY STATISTICS ---
$total_products = $conn->query("SELECT COUNT(id) as count FROM products")->fetch_assoc()['count'];
$total_users = $conn->query("SELECT COUNT(id) as count FROM users")->fetch_assoc()['count'];
$total_orders = $conn->query("SELECT COUNT(id) as count FROM orders")->fetch_assoc()['count'];
$live_visitors = $conn->query("SELECT COUNT(DISTINCT ip_address) as count FROM visitor_logs WHERE visit_time > (NOW() - INTERVAL 30 MINUTE)")->fetch_assoc()['count'];


// --- FETCH RECENT PRODUCTS ---
$result_recent_products = $conn->query("SELECT id, name, category, price FROM products ORDER BY created_at DESC LIMIT 5");
$recent_products = $result_recent_products->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6 flex flex-col">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav class="flex-grow">
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                    <li class="mb-4"><a href="messages.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="mail" class="w-5 h-5 mr-3"></i>Messages</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <header class="mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Dashboard</h2>
                <p class="text-gray-500">Welcome back, <?= htmlspecialchars($_SESSION['admin_username']) ?>!</p>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-purple-100 p-3 rounded-full mr-4"><i data-lucide="package" class="w-6 h-6 text-purple-600"></i></div>
                    <div>
                        <p class="text-gray-500 text-sm">Total Products</p>
                        <p class="text-2xl font-bold"><?= $total_products ?></p>
                    </div>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-blue-100 p-3 rounded-full mr-4"><i data-lucide="users" class="w-6 h-6 text-blue-600"></i></div>
                    <div>
                        <p class="text-gray-500 text-sm">Total Customers</p>
                        <p class="text-2xl font-bold"><?= $total_users ?></p>
                    </div>
                </div>
                <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-green-100 p-3 rounded-full mr-4"><i data-lucide="shopping-cart" class="w-6 h-6 text-green-600"></i></div>
                    <div>
                        <p class="text-gray-500 text-sm">Total Orders</p>
                        <p class="text-2xl font-bold"><?= $total_orders ?></p>
                    </div>
                </div>
                 <div class="bg-white p-6 rounded-lg shadow-lg flex items-center">
                    <div class="bg-red-100 p-3 rounded-full mr-4"><i data-lucide="activity" class="w-6 h-6 text-red-600"></i></div>
                    <div>
                        <p class="text-gray-500 text-sm">Live Visitors</p>
                        <p class="text-2xl font-bold"><?= $live_visitors ?></p>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-lg shadow-lg p-6">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-semibold text-gray-700">Recent Products</h3>
                    <a href="add_product.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg flex items-center"><i data-lucide="plus" class="w-5 h-5 mr-2"></i>Add Product</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="p-4 font-semibold">Product Name</th>
                                <th class="p-4 font-semibold">Category</th>
                                <th class="p-4 font-semibold">Price</th>
                                <th class="p-4 font-semibold text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_products)): ?>
                                <tr><td colspan="4" class="text-center p-6 text-gray-500">No products found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_products as $product): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-4"><?= htmlspecialchars($product['name']) ?></td>
                                        <td class="p-4"><?= htmlspecialchars($product['category']) ?></td>
                                        <td class="p-4">PKR <?= htmlspecialchars(number_format($product['price'], 2)) ?></td>
                                        <td class="p-4 text-right">
                                            <a href="edit_product.php?id=<?= $product['id'] ?>" class="text-blue-600 hover:underline mr-4">Edit</a>
                                            <a href="delete_product.php?id=<?= $product['id'] ?>" class="text-red-600 hover:underline" onclick="return confirm('Are you sure?');">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
