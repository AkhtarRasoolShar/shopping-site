
<?php
/*
=========================================================
 File: add_product.php (UPDATED)
 Description: Uses a dropdown for categories.
 Location: /admin/add_product.php
=========================================================
*/
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

// Fetch categories for the dropdown
$sql_categories = "SELECT id, name FROM categories ORDER BY name ASC";
$result_categories = $conn->query($sql_categories);
$categories = [];
if ($result_categories->num_rows > 0) {
    $categories = $result_categories->fetch_all(MYSQLI_ASSOC);
}
// (Rest of the add_product.php logic remains the same...)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add New Product</title>
    <script src="[https://cdn.tailwindcss.com](https://cdn.tailwindcss.com)"></script>
    <link href="[https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap](https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap)" rel="stylesheet">
    <script src="[https://unpkg.com/lucide@latest](https://unpkg.com/lucide@latest)"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">...</aside>
        <main class="flex-1 p-10">
            <header class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Add New Product</h2>
                <a href="products.php" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg">&larr; Back to Products</a>
            </header>
            <div class="bg-white rounded-lg shadow-lg p-8">
                <form action="add_product.php" method="post" enctype="multipart/form-data">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><label for="name" class="block text-gray-700 text-sm font-bold mb-2">Product Name</label><input type="text" name="name" id="name" required class="shadow-sm border rounded w-full py-3 px-4"></div>

                        <!-- UPDATED CATEGORY INPUT -->
                        <div>
                            <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category</label>
                            <select name="category" id="category" required class="shadow-sm border rounded w-full py-3 px-4">
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?= htmlspecialchars($category['name']) ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div><label for="price" class="block text-gray-700 text-sm font-bold mb-2">Price (PKR)</label><input type="number" name="price" id="price" step="0.01" required class="shadow-sm border rounded w-full py-3 px-4"></div>
                        <div><label for="image" class="block text-gray-700 text-sm font-bold mb-2">Product Image</label><input type="file" name="image" id="image" class="shadow-sm block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100"></div>
                        <div><label for="tags" class="block text-gray-700 text-sm font-bold mb-2">Tags (comma-separated)</label><input type="text" name="tags" id="tags" placeholder="e.g. In-Store, Online" class="shadow-sm border rounded w-full py-3 px-4"></div>
                        <div><label for="discount" class="block text-gray-700 text-sm font-bold mb-2">Discount Badge</label><input type="text" name="discount" id="discount" placeholder="e.g. 5% OFF" class="shadow-sm border rounded w-full py-3 px-4"></div>
                        <div class="md:col-span-2"><label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description</label><textarea name="description" id="description" rows="4" class="shadow-sm border rounded w-full py-3 px-4"></textarea></div>
                    </div>
                    <div class="mt-8 flex justify-end"><button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg">Save Product</button></div>
                </form>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
