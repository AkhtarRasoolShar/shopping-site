
<?php
/*
=========================================================
 File: header.php (UPDATED)
 Description: Reusable header that now includes the visitor tracker.
 Location: /header.php
=========================================================
*/

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'tracker.php'; // Include the new tracker script

$cart_item_count = 0;
if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true) {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT SUM(quantity) as total_items FROM cart WHERE user_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $cart_item_count = $row['total_items'] ?? 0;
        }
        $stmt->close();
    }
}
?>
<header class="bg-white shadow-md sticky top-0 z-50">
    <!-- Rest of header HTML... -->
</header>
