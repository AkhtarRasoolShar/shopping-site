<?php
/*
=========================================================
 File: edit_product.php (FIXED: More Robust Tags Handling)
 Description: Allows admin to edit an existing product.
 Location: /admin/edit_product.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$product = null;
$error_message = '';
$success_message = '';

// Fetch product details
if ($product_id) {
    $stmt = $conn->prepare("SELECT id, name, category, price, description, tags, image FROM products WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows == 1) {
            $product = $result->fetch_assoc();
            // Convert JSON tags back to comma-separated string for form display
            // FIXED: Ensure json_decode output is always an array for implode using is_array() check
            $decoded_tags = json_decode($product['tags'] ?? '[]', true); // Decode, defaulting to empty JSON array string
            $product['tags_string'] = implode(', ', is_array($decoded_tags) ? $decoded_tags : []); // Ensure it's an array for implode
        } else {
            $error_message = "Product not found.";
        }
        $stmt->close();
    } else {
        $error_message = "Database query preparation failed: " . $conn->error;
    }
} else {
    $error_message = "No product ID provided.";
}

// Fetch categories for the dropdown
$categories = [];
$sql_categories = "SELECT name FROM categories ORDER BY name ASC";
$result_categories = $conn->query($sql_categories);
if ($result_categories && $result_categories->num_rows > 0) {
    while ($row = $result_categories->fetch_assoc()) {
        $categories[] = $row['name'];
    }
}

// Display messages from process_edit_product.php (after redirect)
if (isset($_SESSION['product_edit_success'])) {
    $success_message = $_SESSION['product_edit_success'];
    unset($_SESSION['product_edit_success']);
}
if (isset($_SESSION['product_edit_error'])) {
    $error_message = $_SESSION['product_edit_error'];
    unset($_SESSION['product_edit_error']);
}


$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                    <li class="mb-4"><a href="messages.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="mail" class="w-5 h-5 mr-3"></i>Messages</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <h2 class="text-3xl font-bold text-gray-800 mb-8">Edit Product</h2>

            <div class="mb-6">
                <a href="products.php" class="text-blue-600 hover:underline flex items-center mb-4">
                    <i data-lucide="arrow-left" class="w-5 h-5 mr-2"></i> Back to Products List
                </a>
            </div>

            <?php if ($error_message): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($error_message) ?>
                </div>
            <?php endif; ?>
            <?php if ($success_message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($success_message) ?>
                </div>
            <?php endif; ?>

            <?php if ($product): ?>
                <div class="bg-white rounded-lg shadow-lg p-6 max-w-2xl mx-auto">
                    <form action="process_edit_product.php" method="post" enctype="multipart/form-data">
                        <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['id']) ?>">
                        <input type="hidden" name="old_image_path" value="<?= htmlspecialchars($product['image']) ?>">

                        <div class="mb-4">
                            <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Product Name:</label>
                            <input type="text" name="name" id="name" value="<?= htmlspecialchars($product['name']) ?>" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-4">
                            <label for="category" class="block text-gray-700 text-sm font-bold mb-2">Category:</label>
                            <select name="category" id="category" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                                <option value="">Select Category</option>
                                <?php foreach ($categories as $cat_name): ?>
                                    <option value="<?= htmlspecialchars($cat_name) ?>" <?= ($product['category'] == $cat_name) ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($cat_name) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-4">
                            <label for="price" class="block text-gray-700 text-sm font-bold mb-2">Price (PKR):</label>
                            <input type="number" step="0.01" name="price" id="price" value="<?= htmlspecialchars($product['price']) ?>" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-4">
                            <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Description:</label>
                            <textarea name="description" id="description" rows="5" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"><?= htmlspecialchars($product['description']) ?></textarea>
                        </div>
                        <div class="mb-4">
                            <label for="tags" class="block text-gray-700 text-sm font-bold mb-2">Tags (comma-separated, e.g., In-Store, Online, 10% Off):</label>
                            <input type="text" name="tags" id="tags" value="<?= htmlspecialchars($product['tags_string']) ?>" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-6">
                            <label for="product_image" class="block text-gray-700 text-sm font-bold mb-2">Product Image:</label>
                            <?php if ($product['image']): ?>
                                <img src="../<?= htmlspecialchars($product['image']) ?>" alt="Current Image" class="mb-2 max-w-[150px] h-auto rounded-lg shadow">
                                <p class="text-sm text-gray-500 mb-2">Current image. Upload new to replace.</p>
                            <?php endif; ?>
                            <input type="file" name="product_image" id="product_image" accept="image/*" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                            <p class="text-xs text-gray-500 mt-1">Accepted: JPG, PNG, GIF. Max 5MB.</p>
                        </div>
                        <div class="flex items-center justify-between">
                            <button type="submit" name="edit_product" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline">
                                Save Changes
                            </button>
                        </div>
                    </form>
                </div>
            <?php else: ?>
                <div class="bg-white rounded-lg shadow-lg p-6 text-center text-red-600">
                    Product data could not be loaded.
                </div>
            <?php endif; ?>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
