<?php
/*
=========================================================
 File: order_details.php
 Description: Displays details of a specific order in the admin panel.
 Location: /admin/order_details.php
=========================================================
*/
session_start();
require_once '../db.php'; // Path to your db.php from admin directory

// Authentication Check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php"); // Redirect to admin login
    exit;
}

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: orders.php"); // Redirect to orders list if no ID
    exit;
}

$order_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$order_id) {
    header("Location: orders.php"); // Redirect if ID is invalid
    exit;
}

$order_details = [];
$order_items = [];
$customer_details = [];

// Fetch Order Details
// Added 'payment_method', 'payment_proof_image', and 'tel' to the select list
// Also added 'card_last_four' if you decide to add that column
$sql_order = "SELECT o.id, o.user_id, o.total_price, o.status, o.order_date,
                     o.full_name, o.address, o.city, o.payment_method, o.payment_proof_image, o.tel,
                     o.card_last_four, -- Add this line if you add the 'card_last_four' column to your orders table
                     u.username AS customer_username, u.email AS customer_email
              FROM orders o
              LEFT JOIN users u ON o.user_id = u.id
              WHERE o.id = ?";
if ($stmt = $conn->prepare($sql_order)) {
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $order_details = $result->fetch_assoc();
    } else {
        // Order not found
        header("Location: orders.php");
        exit;
    }
    $stmt->close();
}

// Fetch Order Items
$sql_items = "SELECT oi.quantity, oi.price, p.name AS product_name, p.image AS product_image
              FROM order_items oi
              JOIN products p ON oi.product_id = p.id
              WHERE oi.order_id = ?";
if ($stmt = $conn->prepare($sql_items)) {
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $order_items = $result->fetch_all(MYSQLI_ASSOC);
    }
    $stmt->close();
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details #<?= htmlspecialchars($order_id) ?> - Admin Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">
            <h1 class="text-2xl font-bold mb-8">Admin Panel</h1>
            <nav>
                <ul>
                    <li class="mb-4"><a href="dashboard.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="layout-dashboard" class="w-5 h-5 mr-3"></i>Dashboard</a></li>
                    <li class="mb-4"><a href="live_view.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="activity" class="w-5 h-5 mr-3"></i>Live View</a></li>
                    <li class="mb-4"><a href="products.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="package" class="w-5 h-5 mr-3"></i>Products</a></li>
                    <li class="mb-4"><a href="categories.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="list" class="w-5 h-5 mr-3"></i>Categories</a></li>
                    <li class="mb-4"><a href="orders.php" class="flex items-center p-2 bg-purple-600 rounded-lg"><i data-lucide="shopping-cart" class="w-5 h-5 mr-3"></i>Orders</a></li>
                    <li class="mb-4"><a href="testimonials.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="message-square" class="w-5 h-5 mr-3"></i>Testimonials</a></li>
                    <li class="mb-4"><a href="clients.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="briefcase" class="w-5 h-5 mr-3"></i>Clients</a></li>
                    <li class="mb-4"><a href="admins.php" class="flex items-center p-2 hover:bg-gray-700 rounded-lg"><i data-lucide="users" class="w-5 h-5 mr-3"></i>Manage Admins</a></li>
                </ul>
            </nav>
            <div>
                 <a href="logout.php" class="flex items-center p-2 hover:bg-red-700 rounded-lg"><i data-lucide="log-out" class="w-5 h-5 mr-3"></i>Logout</a>
            </div>
        </aside>

        <main class="flex-1 p-10">
            <header class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Order Details #<?= htmlspecialchars($order_details['id']) ?></h2>
                <a href="edit_order_status.php?id=<?= htmlspecialchars($order_details['id']) ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg flex items-center">
                    <i data-lucide="edit" class="w-5 h-5 mr-2"></i>Edit Status
                </a>
            </header>

            <div class="bg-white rounded-lg shadow-lg p-6 mb-8">
                <h3 class="text-xl font-semibold mb-4">Order Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700">
                    <div><strong>Order ID:</strong> <?= htmlspecialchars($order_details['id']) ?></div>
                    <div><strong>Date:</strong> <?= date('F j, Y', strtotime($order_details['order_date'])) ?></div>
                    <div><strong>Total:</strong> PKR <?= number_format($order_details['total_price'], 2) ?></div>
                    <div><strong>Status:</strong> <span class="font-semibold text-green-600"><?= htmlspecialchars($order_details['status']) ?></span></div>

                    <div><strong>Payment Method:</strong> <?= htmlspecialchars($order_details['payment_method']) ?></div>
                    <?php if (isset($order_details['card_last_four']) && !empty($order_details['card_last_four'])): ?>
                    <div><strong>Card Last Four:</strong> **** **** **** <?= htmlspecialchars($order_details['card_last_four']) ?></div>
                    <?php endif; ?>
                    <div><strong>Contact Number:</strong> <?= htmlspecialchars($order_details['tel']) ?></div>

                    <?php if (!empty($order_details['payment_proof_image'])): ?>
                    <div class="md:col-span-2 mt-4">
                        <strong>Payment Proof Image:</strong><br>
                        <a href="../<?= htmlspecialchars($order_details['payment_proof_image']) ?>" target="_blank" class="text-purple-600 hover:underline">View Full Image</a>
                        <img src="../<?= htmlspecialchars($order_details['payment_proof_image']) ?>" alt="Payment Proof" class="mt-2 max-w-xs h-auto rounded-lg shadow">
                    </div>
                    <?php endif; ?>
                    </div>

                <h3 class="text-xl font-semibold mt-8 mb-4">Customer Information</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700">
                    <div><strong>Customer Name:</strong> <?= htmlspecialchars($order_details['full_name']) ?></div>
                    <div><strong>Username:</strong> <?= htmlspecialchars($order_details['customer_username'] ?? 'N/A') ?></div>
                    <div><strong>Email:</strong> <?= htmlspecialchars($order_details['customer_email'] ?? 'N/A') ?></div>
                    <div class="md:col-span-2"><strong>Address:</strong> <?= htmlspecialchars($order_details['address']) ?>, <?= htmlspecialchars($order_details['city']) ?></div>
                </div>

                <h3 class="text-xl font-semibold mt-8 mb-4">Order Items</h3>
                <?php if (!empty($order_items)): ?>
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                            <thead>
                                <tr class="bg-gray-50 text-left text-sm text-gray-600 uppercase">
                                    <th class="py-3 px-4">Product</th>
                                    <th class="py-3 px-4">Quantity</th>
                                    <th class="py-3 px-4">Price</th>
                                    <th class="py-3 px-4">Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($order_items as $item): ?>
                                    <tr class="border-b border-gray-200">
                                        <td class="py-3 px-4 flex items-center">
                                            <img src="../<?= htmlspecialchars($item['product_image'] ?? 'https://placehold.co/50x50') ?>" alt="<?= htmlspecialchars($item['product_name']) ?>" class="w-12 h-12 object-cover rounded-md mr-3">
                                            <span><?= htmlspecialchars($item['product_name']) ?></span>
                                        </td>
                                        <td class="py-3 px-4"><?= htmlspecialchars($item['quantity']) ?></td>
                                        <td class="py-3 px-4">PKR <?= number_format($item['price'], 2) ?></td>
                                        <td class="py-3 px-4">PKR <?= number_format($item['quantity'] * $item['price'], 2) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <p class="text-gray-600">No items found for this order.</p>
                <?php endif; ?>

                <div class="flex justify-end mt-8">
                    <a href="orders.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg flex items-center">
                        <i data-lucide="arrow-left" class="w-5 h-5 mr-2"></i> Back to Orders
                    </a>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
