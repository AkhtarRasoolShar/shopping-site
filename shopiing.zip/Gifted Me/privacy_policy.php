<?php
/*
=========================================================
 File: privacy_policy.php (NEW)
 Description: Privacy Policy page for Gifted Me.
 Location: /privacy_policy.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-privacy-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-privacy-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .policy-section-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            padding: 2rem;
            margin-bottom: 2rem;
            max-width: 900px;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-privacy-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Privacy Policy</h1>
                <p class="mt-2 text-lg text-purple-200">Your privacy matters to us.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="policy-section-card">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">1. Introduction</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    Welcome to Gifted Me. We are committed to protecting your privacy and ensuring the security of your personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website giftkarte.com (the "Site") and use our services. Please read this policy carefully. If you do not agree with the terms of this Privacy Policy, please do not access the Site or use our services.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">2. Information We Collect</h2>
                <p class="text-gray-700 leading-relaxed mb-2">We may collect information about you in a variety of ways:</p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>
                        **Personal Data:** Personally identifiable information, such as your name, shipping address, email address, and telephone number, that you voluntarily give to us when you register with the Site or when you choose to participate in various activities related to the Site (such as online chat, online message boards, surveys, or contests).
                    </li>
                    <li>
                        **Financial Data:** Financial information, such as data related to your payment method (e.g., valid credit card number, card brand, expiration date) that we may collect when you purchase, order, return, exchange, or request information about our services from the Site. We use PCI-compliant third-party payment processors, and we do not store full credit card numbers on our servers.
                    </li>
                    <li>
                        **Derivative Data:** Information our servers automatically collect when you access the Site, such as your IP address, your browser type, your operating system, your access times, and the pages you have viewed directly before and after accessing the Site.
                    </li>
                    <li>
                        **Mobile Device Data:** Information about your mobile device, such as your mobile device ID, model, and manufacturer, and information about the location of your device, if you access the Site from a mobile device.
                    </li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">3. How We Use Your Information</h2>
                <p class="text-gray-700 leading-relaxed mb-2">Having accurate information about you permits us to provide you with a smooth, efficient, and customized experience. We may use information collected about you via the Site to:</p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>Process transactions and send notices about your transactions.</li>
                    <li>Fulfill and manage purchases, orders, payments, and other transactions related to the Site.</li>
                    <li>Email you regarding your account or order.</li>
                    <li>Respond to customer service requests.</li>
                    <li>Send you a newsletter or other marketing communications.</li>
                    <li>Compile anonymous statistical data and analysis for use internally or with third parties.</li>
                    <li>Prevent fraudulent transactions and monitor against theft.</li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">4. Disclosure of Your Information</h2>
                <p class="text-gray-700 leading-relaxed mb-2">We may share information we have collected about you in certain situations. Your information may be disclosed as follows:</p>
                <ul class="list-disc list-inside text-gray-700 leading-relaxed mb-4 pl-4">
                    <li>
                        **By Law or to Protect Rights:** If we believe the release of information about you is necessary to respond to legal process, to investigate or remedy potential violations of our policies, or to protect the rights, property, or safety of others, we may share your information as permitted or required by any applicable law, rule, or regulation.
                    </li>
                    <li>
                        **Third-Party Service Providers:** We may share your information with third parties that perform services for us or on our behalf, including payment processing, data analysis, email delivery, hosting services, customer service, and marketing assistance.
                    </li>
                    <li>
                        **Business Partners:** We may share your information with our business partners to offer you certain products, services, or promotions.
                    </li>
                </ul>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">5. Security of Your Information</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the personal information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">6. Policy for Children</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    We do not knowingly solicit information from or market to children under the age of 13. If you become aware of any data we have collected from children under age 13, please contact us using the contact information provided below.
                </p>

                <h2 class="text-2xl font-bold text-gray-800 mt-8 mb-4">7. Contact Us</h2>
                <p class="text-gray-700 leading-relaxed mb-4">
                    If you have questions or comments about this Privacy Policy, please contact us at:
                </p>
                <p class="text-gray-700 font-semibold">Email: info@giftkarte.com</p>
                <p class="text-gray-700 font-semibold">Phone: 021-111-MYGIFT (694438)</p>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
