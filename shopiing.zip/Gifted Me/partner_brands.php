<?php
/*
=========================================================
 File: partner_brands.php (FIXED: Removed premature $conn->close())
 Description: Displays and filters online partner brands and their locations.
 Location: /partner_brands.php
=========================================================
*/
session_start();
require_once 'db.php';

// --- Fetch Brands from Database (simulated with static data for now) ---
// In a real application, you would fetch this from your 'brands' and 'brand_locations' tables.
// Example SQL:
// SELECT b.id, b.name, b.website_url, b.is_online, b.is_in_store, b.is_on_sale, b.category,
//        GROUP_CONCAT(CONCAT(bl.city, '::', bl.address, '::', bl.is_online_redemption_text) SEPARATOR '||') AS locations_data
// FROM brands b
// LEFT JOIN brand_locations bl ON b.id = bl.brand_id
// GROUP BY b.id
// ORDER BY b.name ASC;

$all_brands = [
    [
        'id' => 1, 'name' => 'Allure Beauty', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://allurebeauty.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton. Markitt, next to Habbit, Tipu Sultan road.'],
            ['city' => 'Lahore', 'address' => 'Phase 5 D.H.A, Lahore'],
            ['city' => 'Islamabad', 'address' => 'Centaurus Mall'],
        ]
    ],
    [
        'id' => 2, 'name' => 'AMD Perfumes', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://amdperfumes.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton, Dolmen Mall Tariq Road, Dolmen Mall Hyderi, Lucky One Mall, North Walk – North Nazimabad, Square One – Gulshan-e-Iqbal, Safa Mall, Malir Cantt'],
            ['city' => 'Multan', 'address' => 'Mall of Multan'],
        ]
    ],
    [
        'id' => 3, 'name' => 'Anker Pakistan', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://laraibnow.com', // Note: provided text has laraibnow.com, image has anker.com.pk. Using provided text.
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Clifton Shopping Arcade Block 5, Khayaban-e-Roomi, Clifton; 49-C, Shop # 2, Badar Commercial Lane # 10, DHA'],
        ]
    ],
    [
        'id' => 4, 'name' => 'Audionic', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://audionic.co',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://audionic.co'],
        ]
    ],
    [
        'id' => 5, 'name' => 'Bandana', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://bandana.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'DHA Phase 3, Gulberg 2, Dolmen Mall Lahore'],
            ['city' => 'Karachi', 'address' => 'Khayaban e Bukhari, DHA Phase 6'],
            ['city' => 'Islamabad', 'address' => 'F-10 Markaz'],
        ]
    ],
    [
        'id' => 6, 'name' => 'Baseus Pakistan', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://baseuspakistan.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'Hall Road, Goldcrest Mall, DHA Phase 4, CSD Shopping Complex, Aziz Bhatti Road, Sarwar Colony'],
        ]
    ],
    [
        'id' => 7, 'name' => 'Bodybrics', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://bodybrics.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://bodybrics.com'],
        ]
    ],
    [
        'id' => 8, 'name' => 'BRACKETS', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.brackets.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'Xinhua Mall'],
            ['city' => 'Islamabad', 'address' => 'Centaurus Mall'],
            ['city' => 'Gujranwala', 'address' => 'GT Road'],
        ]
    ],
    [
        'id' => 9, 'name' => 'Breakout', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://breakout.com.pk',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Lahore, Karachi, Islamabad, Rawalpindi, Multan, Faisalabad, Sialkot, Hyderabad, Bahawalpur, Sargodha, Gujranwala, Peshawar, Sahiwal, Sukkur, Rahim Yar Khan, Gujrat, Quetta, Muzaffarabad, Jhelum'],
        ]
    ],
    [
        'id' => 10, 'name' => 'Brumano', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://shopbrumano.com',
        'locations' => [
            ['city' => 'Hyderabad', 'address' => 'Boulevard Mall.'],
            ['city' => 'Karachi', 'address' => 'Main Tariq Road.'],
            ['city' => 'Lahore', 'address' => 'Avenue Mall.'],
            ['city' => 'Mardan', 'address' => 'Xpressions store.'],
            ['city' => 'Multan', 'address' => 'First floor, Ace Galleria, Gulgasht Colony, Multan'],
            ['city' => 'Dera Ghazi Khan', 'address' => 'DG Khan'],
        ]
    ],
    [
        'id' => 11, 'name' => 'Califord', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://califord.com.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Shop No.G-51, Dolmen Mall, Tariq Road, Karachi, Main Bahadurabad, Karachi, Saima Mall – (Stadium Road), Atrium Mall, KDA Gulshan'],
        ]
    ],
    [
        'id' => 12, 'name' => 'CAT Footwear Pakistan', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.catfootwear.com.pk',
        'locations' => [
            ['city' => 'Inside Hush Puppies Stores', 'address' => 'Karachi, Lahore, Rawalpindi, Islamabad, Faisalabad, Multan, Peshawar, Hyderabad, Sargodha, Sheikhupura, Bahawalpur, Rahim Yar Khan, Quetta, Sahiwal, Gujranwala, Sialkot, Abbottabad, Wahh Cantt, Okara, Dera Ghazi Khan, Jhang, Nankana'],
        ]
    ],
    [
        'id' => 13, 'name' => 'Chapter 13', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://chapter13online.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://chapter13online.com'],
        ]
    ],
    [
        'id' => 14, 'name' => 'Charles Tyrwhitt', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.charlestyrwhitt.pk',
        'locations' => [
            ['city' => 'KARACHI', 'address' => 'Dolmen Mall Clifton'],
            ['city' => 'ISLAMABAD', 'address' => 'Centaurus Mall'],
        ]
    ],
    [
        'id' => 15, 'name' => 'CSD', 'is_in_store' => true, 'is_online' => false, // Assuming CSD is only In-Store based on website text
        'website_url' => 'https://www.csd.gov.pk/',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Murree, Kotli, Taxila, Wah Cantt, Morgah, Rawalpindi, Jhelum, Mangla, KAHAR, Islamabad, Kharian, Mianwali, Jarikas, Sialkot, Sargodha, Okara, Gujranwala, Chunian, Lahore, Bahawalnagar, Pasrur, Jalalpur, Multan, Dera Nawab Sahib, Vehari, Bahawalpur, Khanewal, Dear Ghazi Khan, Jacobabad, Pano Aqil, Rahim yar khan, Kashmor, Karachi, Badin, Jamshoro, Hyderabad, Okara, Peshawar, Badabair, Nowshera, Risalpur, Kohat, D.I.Khan, Kamra, Tarbela, Kohat, Attock, Bannu, Muzzaffarabad, Gillgit, Abbbottabad, Havvelian, Skaardu, Jugglot, Kakkul, Rawwalakot, Khuzdar, Samugli, Balochistan, Quetta, Zhob'],
        ]
    ],
    [
        'id' => 16, 'name' => 'DANY', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://danytech.com.pk',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://danytech.com.pk'],
        ]
    ],
    [
        'id' => 17, 'name' => 'Dune London', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.facebook.com/dunelondonpakistan', // Assuming Facebook is their main online presence
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dune London, Dolmen Mall Clifton'],
            ['city' => 'Islamabad', 'address' => 'Dune London, Centauras Mall'],
            ['city' => 'Lahore', 'address' => 'Dune London, Packages Mall'],
        ]
    ],
    [
        'id' => 18, 'name' => 'Edenrobe', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://edenrobe.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Rawalpindi, Multan, Faisalabad, Quetta, Larkana, Wah cant, Badin, Ghotki, Hyderabad, Jacobabad, Sialkot, Kahripur, Nawabshah, Sukkur, Shikarpur, Faisalabad, Gujranwala, Jhung, Jaranwala, Kamalia, Gojra, Mandi Bahauddin, Narowal, Okara, Rahimyar khan, Sahiwal, Pharianwali, Daska, Sheikupura, Arifwala, Dera Ghazi Khan, Haroonabad, Bahawalpur, Pakpattan, Bahawalnagar, Chakwal, Abbottabad, Haripour, Mianwali, Mardan, Swat, Jhelum, Vehari.'],
        ]
    ],
    [
        'id' => 19, 'name' => 'Elmore Beauty', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://shopelmore.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://shopelmore.com'],
        ]
    ],
    [
        'id' => 20, 'name' => 'FARA London', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://faralondon.com/',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton 1st floor, Luckyone Mall Lower Ground floor'],
            ['city' => 'Lahore', 'address' => 'Emporium Mall 1st floor, Packages Mall 1st floor'],
        ]
    ],
    [
        'id' => 21, 'name' => 'Furor', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://furorjeans.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Rawalpindi, Multan, Faisalabad, Quetta, Larkana, Wah cant, Badin, Ghotki, Hyderabad, Jacobabad, Sialkot, Kahripur, Nawabshah, Sukkur, Shikarpur, Faisalabad, Gujranwala, Jhung, Jaranwala, Kamalia, Gojra, Mandi Bahauddin, Narowal, Okara, Rahimyar khan, Sahiwal, Pharianwali, Daska, Sheikupura, Arifwala, Dera Ghazi Khan, Haroonabad, Bahawalpur, Pakpattan, Bahawalnagar, Chakwal, Abbottabad, Haripour, Mianwali, Mardan, Swat, Jhelum.'],
        ]
    ],
    [
        'id' => 22, 'name' => 'Habitt', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://habitt.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Tipu Sultan, DHA Phase 8'],
            ['city' => 'Lahore', 'address' => 'Sector Y, Phase 3, D.H.A, Gulberg III'],
            ['city' => 'Islamabad', 'address' => 'Plot # 242, Block A, Main PWD Road'],
            ['city' => 'Hyderabad', 'address' => 'Main Auto Bahn Road'],
        ]
    ],
    [
        'id' => 23, 'name' => 'Hush Puppies', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.hushpuppies.com.pk',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Rawalpindi, Islamabad, Faisalabad, Multan, Peshawar, Hyderabad, Sargodha, Sheikhupura, Bahawalpur, Rahim Yar Khan, Quetta, Sahiwal, Gujranwala, Sialkot, Abbottabad, Wah Cantt, Okara, Dera Ghazi Khan, Larkana'],
        ]
    ],
    [
        'id' => 24, 'name' => 'IronGear', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://theirongear.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://theirongear.com'],
        ]
    ],
    [
        'id' => 25, 'name' => 'J.', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.junaidjamshed.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Hyderabad, Nawabshah, Larkana, Sukkur, Quetta, Lahore, Faisalabad, Gujranwala, Bahawalpur, Rahim Yar Khan, Multan, Abbottabad, Islamabad, Rawalpindi, Gujrat, Mirpur, Sahiwal, Peshawar, Mardan, Sargodha, Sialkot, Wah Cantt, Jehlum, Mandi Bahauddin, SWAT, Mianwali, Muzaffarabad, Jhang, Dolmen Mall Lahore, Daska'],
        ]
    ],
    [
        'id' => 26, 'name' => 'Jafferjees', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.jafferjees.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Mehran Heights Clifton Block 8, Najeeb Corner Tariq Road, Lucky One Mall, Dolmen Mall Clifton'],
            ['city' => 'Islamabad', 'address' => 'Kohsar Market Sector F – 6/3, Beverly Centre Blue Area, Giga Mall World Trade Centre, Kingsley Arcade F6, Mall of Islamabad F11'],
            ['city' => 'Lahore', 'address' => 'Emporium Mall, Johar Town, MM Alam Road, Gulberg'],
            ['city' => 'Faisalabad', 'address' => 'Lyallpur Galleria, East Canal Road'],
            ['city' => 'Peshawar', 'address' => 'Shop # 3, Mall of KPK, University Rd, Tahkal'],
            ['city' => 'Multan', 'address' => 'Shareef Complex'],
        ]
    ],
    [
        'id' => 27, 'name' => 'JB Saeed Studio', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.jbsaeedstudio.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => '40-C, Bukhari Commercial Area Phase 6 DHA'],
        ]
    ],
    [
        'id' => 28, 'name' => 'JootiShooti', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://jootishooti.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://jootishooti.com'],
        ]
    ],
    [
        'id' => 29, 'name' => 'KHAS Stores', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.khasstores.com/',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Askari Star Mall, Malir Cantt, Tariq Rd'],
            ['city' => 'Lahore', 'address' => 'Gulberg, DHA Phase 3, Wapda Town'],
            ['city' => 'Islamabad', 'address' => 'J7 Mall, D17, CSD Rawalpindi'],
            ['city' => 'Also in', 'address' => 'Peshawar, Gujranwala, Sialkot, Sargodha, Faisalabad, Bahawalpur etc.'],
        ]
    ],
    [
        'id' => 30, 'name' => 'Luella Grey', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://luellagrey.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton'],
        ]
    ],
    [
        'id' => 31, 'name' => 'Malak', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://malak.com.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton, Dolmen Mall Tariq road'],
            ['city' => 'Lahore', 'address' => 'Dolmen Mall, Packages Mall'],
        ]
    ],
    [
        'id' => 32, 'name' => 'Maryum & Maria', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://maryumnmaria.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Rawalpindi, Gujrat, Gujranwala, Sargodha, Mandi Bahauddin, Faisalabad, Sialkot'],
        ]
    ],
    [
        'id' => 33, 'name' => 'MEME', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://shopatmeme.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton, Dolmen Mall Tariq Road, Luckyone Mall, Square One Mall'],
            ['city' => 'Lahore', 'address' => 'Packages Mall, Emporium Mall'],
            ['city' => 'Islamabad', 'address' => 'Centaurus Mall'],
        ]
    ],
    [
        'id' => 34, 'name' => 'Mendeez', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://mendeez.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Atrium Mall, Lucky One Mall, Badar Commercial, Dolmen Mall, Tariq Road, Safa Mall, Malir Cantt, Saima Square One Mall, Khadda Market, Tariq Road, North Walk'],
        ]
    ],
    [
        'id' => 35, 'name' => 'Metro', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.metro-online.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => '(3 stores)'],
            ['city' => 'Lahore', 'address' => '(4 stores)'],
            ['city' => 'Islamabad', 'address' => '(1 store)'],
            ['city' => 'Faisalabad', 'address' => '(1 store)'],
            ['city' => 'Multan', 'address' => '(1 store)'],
        ]
    ],
    [
        'id' => 36, 'name' => 'Metro Shoes', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.metroshoes.com.pk',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Rawalpindi, Islamabad, Lahore, Jhelum, Swat, Wah Cantt, Peshawar, Sargodha, Gujranwala, Multan, Mardan, Bahawalpur, Jhang, Sialkot, Mirpur, Abottabad, Sahiwal, Gujrat, Sheikhupura, Bahawalnagar, Chakwal, Cheechawatni, Khanewal, Faisalabad'],
        ]
    ],
    [
        'id' => 37, 'name' => 'MIRAS', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://miras.com.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => '99-C, 1st Floor, Zulfiqar Commercial, Street No. 3, Phase 8, DHA.'],
        ]
    ],
    [
        'id' => 38, 'name' => 'Nazmina', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://nazmina.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://nazmina.com'],
        ]
    ],
    [
        'id' => 39, 'name' => 'Nizam Watch House', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://nizamwatch.com',
        'locations' => [
            ['city' => 'Islamabad', 'address' => ''],
            ['city' => 'Faisalabad', 'address' => ''],
            ['city' => 'Rawalpindi', 'address' => ''],
            ['city' => 'Lahore', 'address' => ''],
        ]
    ],
    [
        'id' => 40, 'name' => 'Ochre', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://wearochre.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Luckyone Mall, SquareOne Mall, Saima Mall'],
        ]
    ],
    [
        'id' => 41, 'name' => 'One Degree', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://onedegree.com.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'Packages Mall'],
            ['city' => 'Islamabad', 'address' => 'Safa Gold Mall'],
            ['city' => 'Inside Hush Puppies stores', 'address' => 'Karachi, Lahore, Islamabad, Faisalabad, Sialkot'],
        ]
    ],
    [
        'id' => 42, 'name' => 'Orient Textiles', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.shopatorient.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Hyderabad, Gujranwala, Gujrat, Faisalabad, Multan, Rawalpindi, Bahawalpur, Peshawar, Mandi Bahauddin, Swat, Jhelum, Daska, Mirpur Khas, Mirpur Azad Kashmir'],
        ]
    ],
    [
        'id' => 43, 'name' => 'Paramount Books', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://paramountbooks.com.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Block 2 , PECHS'],
            ['city' => 'Lahore', 'address' => 'Tariq Rd, Gulberg III'],
            ['city' => 'Peshawar', 'address' => 'Arbab Rd, Saddar Cantt'],
        ]
    ],
    [
        'id' => 44, 'name' => 'Philips Personal Care', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://philipspersonalcare.com.pk',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://philipspersonalcare.com.pk'],
        ]
    ],
    [
        'id' => 45, 'name' => 'RTW Creation', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://rtwcreation.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://rtwcreation.com'],
        ]
    ],
    [
        'id' => 46, 'name' => 'Sajiero', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://www.sajiero.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://www.sajiero.com'],
        ]
    ],
    [
        'id' => 47, 'name' => 'Sana\'s', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://sanas.pk/',
        'locations' => [
            ['city' => 'Islamabad', 'address' => 'Centaurus Mall'],
            ['city' => 'Rawalpindi', 'address' => 'Saddar Bank Road'],
            ['city' => 'Faisalabad', 'address' => 'Lyallpur Galleria'],
            ['city' => 'Multan', 'address' => '10/A Gulghast Avenue'],
            ['city' => 'Lahore', 'address' => 'Emporium Mall, Packages Mall, Model Town Link Road'],
        ]
    ],
    [
        'id' => 48, 'name' => 'Scents N Stories', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://scentsnstories.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Image Tower, Block D, Gulshan-e-Jamal. Atrium Mall Saddar. Shop no. 1, Anarkali Market, Liaquat Ali Khan Road, Model Colony, Karachi. (Next to Dvago). Millennium Mall Ground Floor, Rashid Minhas Road, Karachi. 1st Floor, Near Ideas, LuckyOne Mall, Rashid Minhas Road, Karachi. Ground Floor, Shop # G-10, Ocean Towers, Block 9 Clifton, Karachi. 1st Floor Dolmen Mall, Tariq Road, CHS PECHS, Karachi. Shop No 17A, 4 Dots Shopping Complex, Malir Cantonment, Karachi.'],
            ['city' => 'Faisalabad', 'address' => 'Ground Floor, Kiosk# 2, Lyallpur Galleria, E Canal Rd, Saeed Colony Nasar Ullah Khan Town.'],
            ['city' => 'Lahore', 'address' => 'Shop 422, E, Johar Town, Khayaban-e-Firdousi Road. Lahore Link Road, Emporium Mall, Packages Mall, MM Alam Road'],
            ['city' => 'Islamabad', 'address' => 'Shop # 13C, 2nd Floor near Cinepax, Giga Mall. Centaurus Mall F8 Markaz Islamabad 3rd Floor Opposite Dollar Store.'],
            ['city' => 'Mandi Bahauddin', 'address' => 'Mall Of Phalian'],
            ['city' => 'Sargodha', 'address' => 'Mall Of Sargodha'],
            ['city' => 'Sialkot', 'address' => 'V Mall Sialkot Cantt'],
            ['city' => 'Peshawar', 'address' => 'Main University Road.'],
        ]
    ],
    [
        'id' => 49, 'name' => 'Shaffer', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://shaffer.store',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Khayaban-e-Bukhari DHA, Lucky one Mall, Dolmen Mall Clifton, Dolmen Mall Tariq Road'],
            ['city' => 'Lahore', 'address' => 'Dolmen Mall'],
            ['city' => 'Hyderabad', 'address' => 'Boulevard Mall'],
            ['city' => 'Sukkur', 'address' => 'Beside JS Bank, Military Road'],
            ['city' => 'Bahawalpur', 'address' => 'Ace Galleria'],
            ['city' => 'Multan', 'address' => 'Ace Galleria, Gulghast Colony'],
            ['city' => 'Faisalabad', 'address' => 'Chen One Road, Peoples Colony 01'],
        ]
    ],
    [
        'id' => 50, 'name' => 'Spa In A Bottle', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://spainabottle.net',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://spainabottle.net'],
        ]
    ],
    [
        'id' => 51, 'name' => 'Sputnik', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.sputnikfootwear.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Ground Floor, Dolmen Mall Clifton, Ground Floor, Park Towers, Clifton, Basement, Dolmen Mall Tariq Road, Main Tariq Road, Ground Floor, Dolmen Mall, Hyderi, Ground Floor, Lucky One Mall, Saddar, Hyderi'],
            ['city' => 'Lahore', 'address' => 'Level 1, Packages Mall, Dolmen Mall'],
            ['city' => 'Islamabad', 'address' => 'Ground Floor, The Centaurus Mall'],
            ['city' => 'Hyderabad', 'address' => 'Boulevard Mall Hyderabad'],
        ]
    ],
    [
        'id' => 52, 'name' => 'Starlet Shoes', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://starlet.pk',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Lahore, Gujrat, Rawalpindi, Burewala, Faisalabad, Sargodha, Mandi Bahauddin, Mardan, Peshawar, Swat, Sheikupura, Jhelum, Multan, Sialkot, Gujranwala'],
        ]
    ],
    [
        'id' => 53, 'name' => 'Stylo', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://stylo.pk',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://stylo.pk'],
        ]
    ],
    [
        'id' => 54, 'name' => 'SYAH', 'is_in_store' => false, 'is_online' => true,
        'website_url' => 'https://www.syahofficial.com',
        'locations' => [
            ['city' => 'Online', 'address' => 'Redeem online at https://www.syahofficial.com'],
        ]
    ],
    [
        'id' => 55, 'name' => 'The Body Shop', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.thebodyshop.pk',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Stores Located in Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad, Peshawar, Multan, Quetta etc. Pls visit website to get exact locations.'],
        ]
    ],
    [
        'id' => 56, 'name' => 'The Linen Company', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.pk.thelinen.company',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall Clifton, Ocean Mall'],
            ['city' => 'Lahore', 'address' => 'Gulberg Galleria, Packages Mall, Mall of Lahore, Gold Crest Mall'],
            ['city' => 'Islamabad', 'address' => 'Centaurus Mall, Giga Mall'],
            ['city' => 'Multan', 'address' => 'Mall of Multan'],
        ]
    ],
    [
        'id' => 57, 'name' => 'TSM & CO – the shoemakers and company', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://tsmco.com.pk',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Shop 4, 1/C, Mezzanine Floor, 2nd Commercial Lane Zamzama, DHA. Contact: +92 21 35875593'],
            ['city' => 'Lahore', 'address' => '223Y, Street 10, Y Block, Phase 3, DHA, Lahore Contact: +92 42 32020307'],
        ]
    ],
    [
        'id' => 58, 'name' => 'Vanya', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://vanya.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'Emporium Mall, Gulberg II, DHA Y Block, Dolmen Mall Lahore'],
            ['city' => 'Karachi', 'address' => 'Square One Mall, Ocean Mall'],
            ['city' => 'Islamabad', 'address' => 'Safa Gold Mall'],
        ]
    ],
    [
        'id' => 59, 'name' => 'Vegas.pk', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://vegas.pk',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'SHOP NO 1, 5TH FLOOR, XINHUA MALL, GULBERG III.'],
            ['city' => 'Islamabad', 'address' => 'E-11/2 Markaz.'],
            ['city' => 'Rawalpindi', 'address' => 'Ground Floor, Ghakar Plaza, Civic Center Bahria Town Phase 4.'],
            ['city' => 'Sargodha', 'address' => '1ST FLOOR Xin MALL, Queens Road Mansoorabad, phase 2 near MCB bank.'],
        ]
    ],
    [
        'id' => 60, 'name' => 'WalkEaze', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://walkeaze.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Faisalabad, Hyderabad, Sialkot, Quetta'],
        ]
    ],
    [
        'id' => 61, 'name' => 'Wearables', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://www.wearablesforever.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Dolmen Mall, Clifton'],
            ['city' => 'Lahore', 'address' => 'Packages Mall, Emporium Mall, Carrefour-DHA-VII, Carrefour-DHA-II'],
        ]
    ],
    [
        'id' => 62, 'name' => 'wewear', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://wewearpk.com',
        'locations' => [
            ['city' => 'Karachi', 'address' => 'Lucky One Mall, Hush Puppies Shop number 14 Lower Ground Floor.'],
        ]
    ],
    [
        'id' => 63, 'name' => 'Xiaomi', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://xiaomisale.com',
        'locations' => [
            ['city' => 'Lahore', 'address' => 'Emporium Mall, Packages Mall'],
            ['city' => 'Faisalabad', 'address' => 'People’s Colony'],
        ]
    ],
    [
        'id' => 64, 'name' => 'Zubaidas', 'is_in_store' => true, 'is_online' => true,
        'website_url' => 'https://zubaidas.com',
        'locations' => [
            ['city' => 'Multiple Cities', 'address' => 'Karachi, Lahore, Islamabad, Rawalpindi, Faisalabad, Jhelum, Kharian, Peshawar, Swat, Sialkot, Gujranwala, Mirpur'],
        ]
    ],
];
// End of static brand data

// Filter parameters
$search_query = $_GET['search'] ?? '';
$filter_on_sale = isset($_GET['filter_on_sale']);
$filter_in_store = isset($_GET['filter_in_store']);
$filter_prime = isset($_GET['filter_prime']); // Assuming 'Prime' is a category
$filter_salon = isset($_GET['filter_salon']); // Assuming 'Salon' is a category
$filter_online = isset($_GET['filter_online']);

// Apply filters (basic client-side filtering for demonstration)
$filtered_brands = array_filter($all_brands, function($brand) use ($search_query, $filter_on_sale, $filter_in_store, $filter_prime, $filter_salon, $filter_online) {
    $match_search = empty($search_query) || stripos($brand['name'], $search_query) !== false;

    $match_filter = true; // Assume true if no filters are active
    if ($filter_on_sale || $filter_in_store || $filter_prime || $filter_salon || $filter_online) {
        $match_filter = false; // Set to false if any filter is active and not matched
        if ($filter_on_sale && isset($brand['is_on_sale']) && $brand['is_on_sale']) {
            $match_filter = true;
        }
        if ($filter_in_store && $brand['is_in_store']) {
            $match_filter = true;
        }
        if ($filter_online && $brand['is_online']) {
            $match_filter = true;
        }
        if ($filter_prime && (isset($brand['category']) && $brand['category'] == 'Prime')) {
            $match_filter = true;
        }
        if ($filter_salon && (isset($brand['category']) && $brand['category'] == 'Salon')) {
            $match_filter = true;
        }
        // If no filter is checked, all should show (handled by initial $match_filter = true)
        // If any filter IS checked, it must match one of the checked filters
    }

    return $match_search && $match_filter;
});

$brands_found_count = count($filtered_brands);

// IMPORTANT: DO NOT CLOSE THE CONNECTION HERE!
// The connection is still needed by `header.php`.
// $conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Partner Brands - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-brands-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-brands-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .filter-button {
            padding: 0.5rem 1rem;
            border-radius: 9999px; /* rounded-full */
            font-weight: 500;
            transition: all 0.2s ease;
            white-space: nowrap;
        }
        .filter-button.active {
            background-color: #6d28d9;
            color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .filter-button:not(.active) {
            background-color: #f3f4f6;
            color: #4b5563;
            border: 1px solid #d1d5db;
        }
        .filter-button:not(.active):hover {
            background-color: #e5e7eb;
            color: #1f2937;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-brands-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Online Partner Brands</h1>
                <p class="mt-2 text-lg text-purple-200">Discover where you can use your Gifted Me cards!</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div class="bg-white p-4 rounded-lg shadow-md mb-8">
                <form action="partner_brands.php" method="GET" class="flex flex-col md:flex-row items-center gap-4">
                    <input type="text" name="search" placeholder="Search Here..." value="<?= htmlspecialchars($search_query) ?>" class="w-full md:flex-grow border-gray-300 rounded-lg shadow-sm">
                    <button type="submit" class="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white font-bold p-2 rounded-lg flex items-center justify-center">
                        <i data-lucide="search" class="w-5 h-5"></i> Search
                    </button>
                </form>
            </div>

            <div class="bg-white rounded-lg shadow-md p-6">
                <div class="flex justify-between items-center mb-6 flex-wrap gap-4">
                    <h2 class="text-2xl font-bold text-gray-800">Online Partner Brands</h2>
                    <span class="text-gray-600 font-semibold"><?= $brands_found_count ?> Brand(s) Found</span>
                </div>

                <div class="flex flex-wrap gap-2 mb-8" id="filter-buttons">
                    <button class="filter-button" data-filter-type="on_sale">Brands On Sale</button>
                    <button class="filter-button" data-filter-type="in_store">In-Store</button>
                    <button class="filter-button" data-filter-type="prime">Prime</button>
                    <button class="filter-button" data-filter-type="salon">Salon</button>
                    <button class="filter-button active" data-filter-type="online">Online</button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left table-auto">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="p-4 font-semibold w-12">S.No</th>
                                <th class="p-4 font-semibold w-48">Brand</th>
                                <th class="p-4 font-semibold">Location</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($filtered_brands)): ?>
                                <tr>
                                    <td colspan="3" class="text-center p-6 text-gray-500">No brands found matching your criteria.</td>
                                </tr>
                            <?php else: ?>
                                <?php $sno = 1; ?>
                                <?php foreach ($filtered_brands as $brand): ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="p-4 align-top"><?= $sno++ ?></td>
                                        <td class="p-4 align-top">
                                            <div class="font-semibold text-gray-800 mb-1"><?= htmlspecialchars($brand['name']) ?></div>
                                            <div class="flex gap-1 text-xs">
                                                <?php if ($brand['is_in_store']): ?><span class="bg-purple-100 text-purple-800 px-2 py-1 rounded-full">In-Store</span><?php endif; ?>
                                                <?php if ($brand['is_online']): ?><span class="bg-green-100 text-green-800 px-2 py-1 rounded-full">Online</span><?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="p-4 align-top">
                                            <ul class="list-disc list-inside space-y-1">
                                                <?php foreach ($brand['locations'] as $location): ?>
                                                    <li>
                                                        <span class="font-semibold text-gray-700"><?= htmlspecialchars($location['city']) ?>:</span>
                                                        <?= htmlspecialchars($location['address']) ?>
                                                    </li>
                                                <?php endforeach; ?>
                                            </ul>
                                            <?php if (!empty($brand['website_url'])): ?>
                                                <div class="mt-2 text-sm">
                                                    <span class="font-semibold">Website:</span>
                                                    <a href="<?= htmlspecialchars($brand['website_url']) ?>" target="_blank" class="text-blue-600 hover:underline">
                                                        <?= htmlspecialchars($brand['website_url']) ?>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();

        document.addEventListener('DOMContentLoaded', function() {
            const filterButtons = document.querySelectorAll('.filter-button');
            const searchForm = document.querySelector('form[action="partner_brands.php"]'); // Get the search form

            filterButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const filterType = button.dataset.filterType;

                    // Clear active state from all buttons
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    // Set active state on the clicked button
                    button.classList.add('active');

                    // Submit the form with the filter type (or dynamically filter via JS/AJAX)
                    // For simplicity, we'll re-submit the form, appending the filter to the URL
                    const currentUrl = new URL(window.location.href);
                    // Remove existing filter parameters
                    currentUrl.searchParams.delete('filter_on_sale');
                    currentUrl.searchParams.delete('filter_in_store');
                    currentUrl.searchParams.delete('filter_prime');
                    currentUrl.searchParams.delete('filter_salon');
                    currentUrl.searchParams.delete('filter_online');

                    // Add the selected filter
                    if (filterType === 'on_sale') currentUrl.searchParams.set('filter_on_sale', '1');
                    else if (filterType === 'in_store') currentUrl.searchParams.set('filter_in_store', '1');
                    else if (filterType === 'prime') currentUrl.searchParams.set('filter_prime', '1');
                    else if (filterType === 'salon') currentUrl.searchParams.set('filter_salon', '1');
                    else if (filterType === 'online') currentUrl.searchParams.set('filter_online', '1');

                    window.location.href = currentUrl.toString();
                });
            });

            // Set active filter button on page load based on URL params
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('filter_on_sale')) {
                document.querySelector('.filter-button[data-filter-type="on_sale"]').classList.add('active');
            } else if (urlParams.has('filter_in_store')) {
                document.querySelector('.filter-button[data-filter-type="in_store"]').classList.add('active');
            } else if (urlParams.has('filter_prime')) {
                document.querySelector('.filter-button[data-filter-type="prime"]').classList.add('active');
            } else if (urlParams.has('filter_salon')) {
                document.querySelector('.filter-button[data-filter-type="salon"]').classList.add('active');
            } else if (urlParams.has('filter_online')) {
                document.querySelector('.filter-button[data-filter-type="online"]').classList.add('active');
            } else {
                 // Default to 'Online' if no filter is specified, as per screenshot
                document.querySelector('.filter-button[data-filter-type="online"]').classList.add('active');
            }
        });
    </script>
</body>
</html>
