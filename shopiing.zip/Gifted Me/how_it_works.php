<?php
/*
=========================================================
 File: how_it_works.php (NEW)
 Description: Explains how Gifted Me works in a step-by-step manner.
 Location: /how_it_works.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How It Works - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-how-it-works-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-how-it-works-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .step-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 2rem;
            text-align: center;
            position: relative;
            z-index: 1; /* Ensure content is above connectors */
        }
        .step-number {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 3rem;
            height: 3rem;
            border-radius: 9999px; /* rounded-full */
            background-color: #e9d5ff; /* light purple */
            color: #5b21b6; /* deep purple */
            font-size: 1.5rem; /* text-2xl */
            font-weight: 700; /* font-bold */
            margin-bottom: 1rem;
            border: 2px solid #6d28d9;
        }
        .step-connector {
            position: absolute;
            top: 50%;
            left: calc(100% + 1rem); /* Position after the card, plus some gap */
            width: 3rem; /* Length of the line */
            height: 2px;
            background-color: #d1d5db; /* gray-300 */
            z-index: 0;
            transform: translateY(-50%);
        }
        .step-card:nth-child(even) .step-connector {
            left: -4rem; /* For even cards, position before the card */
            transform: translateY(-50%) rotateY(180deg); /* Flip horizontally if needed for design */
        }
        /* Hide connectors on smaller screens if using a single column layout */
        @media (max-width: 1023px) { /* Adjust breakpoint as per your Tailwind setup for lg */
            .step-connector {
                display: none;
            }
        }

    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-how-it-works-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">How It Works</h1>
                <p class="mt-2 text-lg text-purple-200">A simple guide to gifting with Gifted Me.</p>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Our Simple 3-Step Process</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">
                    Sending the perfect gift has never been easier. Follow these steps to delight your loved ones.
                </p>
            </div>

            <div class="grid lg:grid-cols-3 gap-8 relative">
                <div class="step-card">
                    <div class="step-number mx-auto">1</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Choose Your Gift Card</h3>
                    <p class="text-gray-600">Browse our wide selection of E-Gift Cards from top brands across various categories. Find the perfect fit for any occasion and recipient.</p>
                    <i data-lucide="search" class="w-10 h-10 text-gray-400 mt-4 mx-auto"></i>
                    <div class="step-connector"></div>
                </div>

                <div class="step-card">
                    <div class="step-number mx-auto">2</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Personalize & Schedule</h3>
                    <p class="text-gray-600">Add a personal message, select a beautiful greeting card, and choose to send it instantly or schedule it for a future date (up to 6 months in advance!).</p>
                    <i data-lucide="calendar-check" class="w-10 h-10 text-gray-400 mt-4 mx-auto"></i>
                     <div class="step-connector"></div>
                </div>

                <div class="step-card">
                    <div class="step-number mx-auto">3</div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Secure Checkout & Delivery</h3>
                    <p class="text-gray-600">Complete your purchase through our secure payment process. The E-Gift Card is then delivered directly to your recipient via email and SMS.</p>
                    <i data-lucide="credit-card" class="w-10 h-10 text-gray-400 mt-4 mx-auto"></i>
                </div>
            </div>

            <div class="text-center mt-16">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Have More Questions?</h2>
                <p class="text-gray-600 max-w-xl mx-auto mb-6">
                    Check out our Frequently Asked Questions section or contact our friendly customer support team.
                </p>
                <a href="faqs.php" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-8 rounded-lg text-lg inline-flex items-center shadow-md mr-4">
                    <i data-lucide="help-circle" class="w-5 h-5 mr-2"></i> Visit FAQs
                </a>
                <a href="contact.php" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-3 px-8 rounded-lg text-lg inline-flex items-center shadow-md">
                    <i data-lucide="mail" class="w-5 h-5 mr-2"></i> Contact Us
                </a>
            </div>

        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
