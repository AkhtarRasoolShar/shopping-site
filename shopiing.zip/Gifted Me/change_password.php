<?php
/*
=========================================================
 File: change_password.php (UPDATED: Fixed premature $conn->close())
 Description: Allows a logged-in user to change their password.
 Location: /change_password.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection

// Redirect if user is not logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// Handle password change form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Input validation
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error_message = "All password fields are required.";
    } elseif ($new_password !== $confirm_password) {
        $error_message = "New password and confirm password do not match.";
    } elseif (strlen($new_password) < 6) { // Example: minimum password length
        $error_message = "New password must be at least 6 characters long.";
    } else {
        // Fetch current hashed password from database
        $sql_fetch_password = "SELECT password FROM users WHERE id = ?";
        if ($stmt_fetch = $conn->prepare($sql_fetch_password)) {
            $stmt_fetch->bind_param("i", $user_id);
            $stmt_fetch->execute();
            $stmt_fetch->bind_result($hashed_password_from_db);
            $stmt_fetch->fetch();
            $stmt_fetch->close();

            // Verify current password
            if (password_verify($current_password, $hashed_password_from_db)) {
                // Hash new password
                $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update password in database
                $sql_update_password = "UPDATE users SET password = ? WHERE id = ?";
                if ($stmt_update = $conn->prepare($sql_update_password)) {
                    $stmt_update->bind_param("si", $new_hashed_password, $user_id);
                    if ($stmt_update->execute()) {
                        $success_message = "Password updated successfully!";
                    } else {
                        $error_message = "Error updating password: " . $stmt_update->error;
                    }
                    $stmt_update->close();
                } else {
                    $error_message = "Database prepare failed for update: " . $conn->error;
                }
            } else {
                $error_message = "Current password is incorrect.";
            }
        } else {
            $error_message = "Database prepare failed for fetch: " . $conn->error;
        }
    }
}

// IMPORTANT: REMOVED THIS LINE -> $conn->close(); // Close the database connection after all operations
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">Change Password</h1>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="md:col-span-1 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Account Navigation</h2>
                <ul class="space-y-2">
                    <li><a href="my_account.php#profile-settings" class="block p-2 rounded-lg hover:bg-gray-100 text-gray-700">Profile Settings</a></li>
                    <li><a href="my_account.php#order-history" class="block p-2 rounded-lg hover:bg-gray-100 text-gray-700">Order History</a></li>
                    <li><a href="change_password.php" class="block p-2 rounded-lg bg-purple-100 text-purple-700 font-medium">Change Password</a></li>
                    <li><a href="logout_user.php" class="block p-2 rounded-lg hover:bg-red-100 text-red-700">Logout</a></li>
                </ul>
            </div>

            <div class="md:col-span-2 space-y-8">
                <section class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Change Your Password</h2>

                    <?php if ($success_message): ?>
                        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                            <?= htmlspecialchars($success_message) ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($error_message): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                            <?= htmlspecialchars($error_message) ?>
                        </div>
                    <?php endif; ?>

                    <form action="change_password.php" method="post">
                        <div class="mb-4">
                            <label for="current_password" class="block text-gray-700 text-sm font-bold mb-2">Current Password:</label>
                            <input type="password" name="current_password" id="current_password" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-4">
                            <label for="new_password" class="block text-gray-700 text-sm font-bold mb-2">New Password:</label>
                            <input type="password" name="new_password" id="new_password" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="mb-6">
                            <label for="confirm_password" class="block text-gray-700 text-sm font-bold mb-2">Confirm New Password:</label>
                            <input type="password" name="confirm_password" id="confirm_password" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                        </div>
                        <div class="flex items-center justify-end">
                            <button type="submit" name="change_password" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline">
                                Change Password
                            </button>
                        </div>
                    </form>
                </section>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
