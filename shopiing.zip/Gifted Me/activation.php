<?php
/*
=========================================================
 File: activation.php (NEW)
 Description: Displays a form for users to activate their e-gift cards.
 Location: /activation.php
=========================================================
*/
session_start();
require_once 'db.php';

$message = '';
$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // In a real application, you would add logic here to:
    // 1. Find the E-Gift Card number in your database.
    // 2. Verify the details match (name, email, amount).
    // 3. Update the card's status to 'Active'.

    // For this demo, we will just show a success message.
    $card_number = $_POST['card_number'] ?? '';
    $message = "Your E-Gift Card #".htmlspecialchars($card_number)." has been activated successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>E-Gift Card Activation - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <div class="bg-purple-700 text-white">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center">
            <h1 class="text-3xl font-bold">E-Gift Card Activation Form</h1>
        </div>
    </div>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="max-w-4xl mx-auto bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-xl font-semibold text-gray-700 mb-6 flex items-center">
                <i data-lucide="hash" class="w-6 h-6 mr-3 text-purple-600"></i>
                Activation (Enter your E-Gift Card Number)
            </h2>

            <?php if ($message): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6"><?= $message ?></div>
            <?php endif; ?>

            <form action="activation.php" method="post">
                <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-6">
                    <div class="lg:col-span-1">
                        <label for="card_number" class="block text-sm font-medium text-gray-700">E-Gift Card No.</label>
                        <input type="text" name="card_number" id="card_number" placeholder="Enter E-Gift Card#" required class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                    </div>
                    <div>
                        <label for="full_name" class="block text-sm font-medium text-gray-700">Full Name</label>
                        <input type="text" name="full_name" id="full_name" placeholder="Full Name" required class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                    </div>
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">Email Address</label>
                        <input type="email" name="email" id="email" placeholder="e.g. abc@gmail.com" required class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                    </div>
                    <div>
                        <label for="mobile" class="block text-sm font-medium text-gray-700">Mobile Number</label>
                        <input type="tel" name="mobile" id="mobile" placeholder="e.g. 3112345678" required class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                    </div>
                    <div>
                        <label for="amount" class="block text-sm font-medium text-gray-700">Amount</label>
                        <input type="number" name="amount" id="amount" placeholder="Amount" required class="mt-1 block w-full border-gray-300 rounded-lg shadow-sm">
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-4">
                    <button type="reset" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-6 rounded-lg">Reset</button>
                    <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-lg">Activate</button>
                </div>
            </form>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>
