<?php
/*
=========================================================
 File: process_contact_form.php (NEW)
 Description: Processes general contact form and saves to DB, sends optional email.
 Location: /process_contact_form.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include the database connection

// --- DEBUGGING START (Remove or comment out in production) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
error_log("PROCESS GENERAL CONTACT: Request Method is " . $_SERVER["REQUEST_METHOD"]);
error_log("POST Data: " . print_r($_POST, true));
// --- DEBUGGING END ---

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize input
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $subject = filter_input(INPUT_POST, 'subject', FILTER_SANITIZE_STRING); // Optional
    $mobile_no = filter_input(INPUT_POST, 'mobile_no', FILTER_SANITIZE_STRING); // Optional
    $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_STRING);

    $errors = [];
    if (empty($name)) { $errors[] = 'Your Name is required.'; }
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = 'A valid Email Address is required.'; }
    if (empty($message)) { $errors[] = 'Your Message cannot be empty.'; }

    if (!empty($errors)) {
        $_SESSION['contact_error'] = implode('<br>', $errors);
        header("Location: contact.php");
        exit;
    }

    $conn->begin_transaction(); // Start transaction

    try {
        // --- Save message to database ---
        // Note: company_name is NULL for general contact form.
        $stmt_insert_db = $conn->prepare("INSERT INTO contact_messages (sender_name, email, mobile_no, company_name, message, subject) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt_insert_db === false) {
            throw new Exception("Database prepare failed for message insertion: " . $conn->error);
        }
        // For general contact form, company_name is empty/null, subject is new field
        $empty_company = null; // Or an empty string '' if DB column is not nullable
        $stmt_insert_db->bind_param("ssssss", $name, $email, $mobile_no, $empty_company, $message, $subject);
        if (!$stmt_insert_db->execute()) {
            throw new Exception("Database execute failed for message insertion: " . $stmt_insert_db->error);
        }
        $stmt_insert_db->close();

        // --- Send email to admin (Optional for immediate notification) ---
        $admin_email = "your_admin_email@example.com"; // CHANGE THIS TO YOUR ADMIN'S EMAIL ADDRESS
        $email_subject = "New General Contact Inquiry: " . (!empty($subject) ? $subject : "No Subject");
        $email_body = "You have received a new general contact inquiry:\n\n" .
                      "Name: " . $name . "\n" .
                      "Email Address: " . $email . "\n" .
                      "Mobile No.: " . (!empty($mobile_no) ? $mobile_no : "N/A") . "\n" .
                      "Subject: " . (!empty($subject) ? $subject : "N/A") . "\n\n" .
                      "Message:\n" . $message . "\n";
        $headers = "From: " . $email . "\r\n" .
                   "Reply-To: " . $email . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();

        if (!mail($admin_email, $email_subject, $email_body, $headers)) {
            error_log("Failed to send general contact email. Mail function returned false. Admin Email: $admin_email");
        }

        $conn->commit(); // Commit transaction
        $_SESSION['contact_success'] = 'Your message has been sent successfully. We will get back to you shortly!';
        header("Location: contact.php");
        exit;

    } catch (Exception $e) {
        $conn->rollback(); // Rollback transaction
        error_log("General Contact Message Error: " . $e->getMessage());
        $_SESSION['contact_error'] = 'Sorry, an unexpected error occurred. Please try again later.';
        header("Location: contact.php");
        exit;
    }

} else {
    header("Location: contact.php");
    exit;
}
?>
