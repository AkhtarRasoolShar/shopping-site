<?php
/*
=========================================================
 File: products.php (UPDATED: Added Sorting and Filtering)
 Description: Displays all available products with dynamic sorting and filtering.
 Location: /products.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure db.php is included first to establish $conn

// --- Filters and Search Parameters ---
$search_query = $_GET['query'] ?? '';
$filter_category = $_GET['category'] ?? ''; // e.g., "Fashion & Accessories"
$sort_order = $_GET['ordering'] ?? 'name_asc'; // Default sorting: Name (A-Z)

// Build the SQL query
$sql = "SELECT id, name, category, image, price, tags, description FROM products WHERE 1=1"; // Start with a true condition for easy AND concatenation

// Apply search query (if you decide to add a search input to this page)
if (!empty($search_query)) {
    $search_query_safe = "%" . $conn->real_escape_string($search_query) . "%";
    $sql .= " AND (name LIKE '{$search_query_safe}' OR description LIKE '{$search_query_safe}')";
}

// Apply category filter
if (!empty($filter_category)) {
    $filter_category_safe = $conn->real_escape_string($filter_category);
    $sql .= " AND category = '{$filter_category_safe}'";
}

// Apply sorting
switch ($sort_order) {
    case 'name_asc':
        $sql .= " ORDER BY name ASC";
        break;
    case 'name_desc':
        $sql .= " ORDER BY name DESC";
        break;
    case 'price_asc':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_desc':
        $sql .= " ORDER BY price DESC";
        break;
    case 'newest':
        $sql .= " ORDER BY created_at DESC";
        break;
    case 'oldest':
        $sql .= " ORDER BY created_at ASC";
        break;
    default:
        $sql .= " ORDER BY name ASC"; // Default if an invalid sort_order is provided
        break;
}

$result = $conn->query($sql);

$products = [];
if ($result && $result->num_rows > 0) {
    $products = $result->fetch_all(MYSQLI_ASSOC);
    // Decode tags from JSON if they are stored as such
    foreach ($products as &$product) {
        $product['tags'] = json_decode($product['tags'] ?? '[]', true);
    }
}

// Fetch all categories for the filter dropdown
$categories = [];
$sql_categories = "SELECT name FROM categories ORDER BY name ASC";
$result_categories = $conn->query($sql_categories);
if ($result_categories && $result_categories->num_rows > 0) {
    while ($row = $result_categories->fetch_assoc()) {
        $categories[] = $row['name'];
    }
}

// IMPORTANT: Do NOT close $conn here. It's needed by header.php.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .product-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
            transition: transform 0.2s ease;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .product-card .tags {
            position: absolute;
            top: 0.5rem;
            left: 0.5rem;
            z-index: 10;
            display: flex; /* Use flex for stacked tags */
            flex-direction: column; /* Stack tags vertically */
            align-items: flex-start; /* Align tags to the start */
            gap: 0.25rem; /* Space between tags */
        }
        .product-card .tag-item {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            border-radius: 9999px; /* rounded-full */
            font-size: 0.75rem; /* text-xs */
            font-weight: 600; /* font-semibold */
            margin-right: 0.25rem;
            margin-bottom: 0.25rem;
            white-space: nowrap; /* Prevent text wrapping */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="flex justify-between items-center mb-8 flex-wrap gap-4">
            <h1 class="text-3xl font-bold text-gray-800">All Products</h1>

            <form action="products.php" method="GET" class="flex flex-col md:flex-row gap-4 items-center">
                <input type="hidden" name="query" value="<?= htmlspecialchars($search_query) ?>">

                <select name="category" onchange="this.form.submit()" class="border-gray-300 rounded-lg shadow-sm py-2 px-3 focus:ring-purple-500 focus:border-purple-500">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat_name): ?>
                        <option value="<?= htmlspecialchars($cat_name) ?>" <?= ($filter_category == $cat_name) ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat_name) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <select name="ordering" onchange="this.form.submit()" class="border-gray-300 rounded-lg shadow-sm py-2 px-3 focus:ring-purple-500 focus:border-purple-500">
                    <option value="name_asc" <?= ($sort_order == 'name_asc') ? 'selected' : '' ?>>Name (A-Z)</option>
                    <option value="name_desc" <?= ($sort_order == 'name_desc') ? 'selected' : '' ?>>Name (Z-A)</option>
                    <option value="price_asc" <?= ($sort_order == 'price_asc') ? 'selected' : '' ?>>Price (Low to High)</option>
                    <option value="price_desc" <?= ($sort_order == 'price_desc') ? 'selected' : '' ?>>Price (High to Low)</option>
                    <option value="newest" <?= ($sort_order == 'newest') ? 'selected' : '' ?>>Newest First</option>
                    <option value="oldest" <?= ($sort_order == 'oldest') ? 'selected' : '' ?>>Oldest First</option>
                </select>
                </form>
        </div>

        <?php if (empty($products)): ?>
            <div class="bg-white rounded-lg shadow-md p-8 text-center">
                <i data-lucide="package-x" class="w-16 h-16 mx-auto text-gray-400 mb-4"></i>
                <h2 class="text-xl font-semibold text-gray-700">No Products Available</h2>
                <p class="text-gray-500 mt-2">Please check back later, we are adding new products all the time!</p>
                <p class="text-gray-500 mt-2">Try adjusting your filters or search query.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
                <?php foreach ($products as $product): ?>
                    <div class="product-card">
                        <a href="product_detail.php?id=<?= $product['id'] ?>" class="block relative">
                            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-40 object-cover rounded-t-lg" onerror="this.onerror=null;this.src='https://placehold.co/400x300/e2e8f0/4a5568?text=Image+Not+Found';">
                            <div class="tags">
                                <?php if (!empty($product['tags'])): ?>
                                    <?php foreach ($product['tags'] as $tag): ?>
                                        <span class="tag-item <?= strpos($tag, 'Online') !== false ? 'bg-blue-100 text-blue-800' : (strpos($tag, '% Off') !== false ? 'bg-red-100 text-red-800' : 'bg-gray-200 text-gray-700') ?>">
                                            <?= htmlspecialchars($tag) ?>
                                        </span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                            <div class="p-3">
                                <h3 class="text-md font-semibold text-gray-900 truncate"><?= htmlspecialchars($product['name']) ?></h3>
                                <p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p>
                                <p class="text-md font-bold text-purple-700 mt-2">PKR <?= number_format($product['price'], 2) ?></p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
