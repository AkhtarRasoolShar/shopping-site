<?php
/*
=========================================================
 File: user_order_details.php (UPDATED: More Comprehensive Order Details)
 Description: Displays details of a specific user order.
 Location: /user_order_details.php
=========================================================
*/
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Check if order ID is provided in the URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    // Redirect to my_account.php if no ID is provided
    header("location: my_account.php");
    exit;
}

$order_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$order_details = [];
$order_items = [];

// Fetch order details with full billing, shipping, and payment information
$sql_order = "SELECT id, total_price, status, order_date, full_name, address, city, country, tel, payment_method, tid, payment_proof_image, card_last_four
              FROM orders
              WHERE id = ? AND user_id = ?";
if ($stmt = $conn->prepare($sql_order)) {
    $stmt->bind_param("ii", $order_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $order_details = $result->fetch_assoc();
    } else {
        // Order not found or does not belong to the current user
        header("location: my_account.php");
        exit;
    }
    $stmt->close();
}

// Fetch order items (assuming an 'order_items' table)
$sql_items = "SELECT oi.quantity, oi.price, p.name as product_name, p.image as product_image
              FROM order_items oi
              JOIN products p ON oi.product_id = p.id
              WHERE oi.order_id = ?";
if ($stmt = $conn->prepare($sql_items)) {
    $stmt->bind_param("i", $order_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $order_items = $result->fetch_all(MYSQLI_ASSOC);
    }
    $stmt->close();
}

$conn->close(); // Close the database connection.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details - Order #<?= htmlspecialchars($order_id) ?> - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">Order Details #<?= htmlspecialchars($order_details['id']) ?></h1>

        <div class="bg-white rounded-lg shadow-md p-6 mb-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <p class="text-gray-600 font-semibold">Order Date:</p>
                    <p class="text-lg text-gray-800"><?= date('F j, Y', strtotime($order_details['order_date'])) ?></p>
                </div>
                <div>
                    <p class="text-gray-600 font-semibold">Order Total:</p>
                    <p class="text-lg text-purple-700 font-bold">PKR <?= number_format($order_details['total_price'], 2) ?></p>
                </div>
                <div>
                    <p class="text-gray-600 font-semibold">Status:</p>
                    <p class="text-lg font-bold
                        <?= ($order_details['status'] == 'Pending Approval') ? 'text-yellow-600' : '' ?>
                        <?= ($order_details['status'] == 'Processing') ? 'text-blue-600' : '' ?>
                        <?= ($order_details['status'] == 'Shipped') ? 'text-indigo-600' : '' ?>
                        <?= ($order_details['status'] == 'Delivered') ? 'text-green-600' : '' ?>
                        <?= ($order_details['status'] == 'Cancelled') ? 'text-red-600' : '' ?>
                    ">
                        <?= htmlspecialchars($order_details['status']) ?>
                    </p>
                </div>
                <?php /* if (!empty($order_details['tracking_number'])): ?>
                    <div>
                        <p class="text-gray-600 font-semibold">Tracking Number:</p>
                        <p class="text-lg text-blue-600"><a href="YOUR_TRACKING_URL/<?= htmlspecialchars($order_details['tracking_number']) ?>" target="_blank"><?= htmlspecialchars($order_details['tracking_number']) ?></a></p>
                    </div>
                <?php endif; */ ?>
            </div>

            <h2 class="text-2xl font-semibold text-gray-800 mt-8 mb-4">Billing & Shipping Address</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700 mb-6">
                <div>
                    <p class="font-semibold">Full Name:</p>
                    <p><?= htmlspecialchars($order_details['full_name']) ?></p>
                </div>
                <div>
                    <p class="font-semibold">Phone Number:</p>
                    <p><?= htmlspecialchars($order_details['tel']) ?></p>
                </div>
                <div class="md:col-span-2">
                    <p class="font-semibold">Address:</p>
                    <p><?= htmlspecialchars($order_details['address']) ?></p>
                </div>
                <div>
                    <p class="font-semibold">City:</p>
                    <p><?= htmlspecialchars($order_details['city']) ?></p>
                </div>
                <div>
                    <p class="font-semibold">Country:</p>
                    <p><?= htmlspecialchars($order_details['country']) ?></p>
                </div>
            </div>

            <h2 class="text-2xl font-semibold text-gray-800 mt-8 mb-4">Payment Information</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700 mb-6">
                <div>
                    <p class="font-semibold">Payment Method:</p>
                    <p><?= htmlspecialchars($order_details['payment_method']) ?></p>
                </div>
                <?php if (!empty($order_details['card_last_four'])): ?>
                <div>
                    <p class="font-semibold">Card Last Four Digits:</p>
                    <p>**** **** **** <?= htmlspecialchars($order_details['card_last_four']) ?></p>
                </div>
                <?php endif; ?>
                <?php if (!empty($order_details['tid'])): ?>
                <div>
                    <p class="font-semibold">Transaction ID/Reference:</p>
                    <p class="break-words"><?= htmlspecialchars($order_details['tid']) ?></p>
                </div>
                <?php endif; ?>
                <?php if (!empty($order_details['payment_proof_image'])): ?>
                <div class="md:col-span-2">
                    <p class="font-semibold">Payment Proof:</p>
                    <a href="<?= htmlspecialchars($order_details['payment_proof_image']) ?>" target="_blank" class="text-purple-600 hover:underline">
                        <img src="<?= htmlspecialchars($order_details['payment_proof_image']) ?>" alt="Payment Proof" class="mt-2 max-w-xs h-auto rounded-lg shadow">
                        Click to view image
                    </a>
                </div>
                <?php endif; ?>
            </div>

            <h2 class="text-2xl font-semibold text-gray-800 mt-8 mb-4">Items in this Order</h2>
            <?php if (!empty($order_items)): ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                        <thead>
                            <tr class="bg-gray-50 text-left text-sm text-gray-600 uppercase">
                                <th class="py-3 px-4">Product</th>
                                <th class="py-3 px-4">Quantity</th>
                                <th class="py-3 px-4">Price</th>
                                <th class="py-3 px-4">Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order_items as $item): ?>
                                <tr class="border-b border-gray-200">
                                    <td class="py-3 px-4 flex items-center">
                                        <img src="<?= htmlspecialchars($item['product_image'] ?? 'https://placehold.co/50x50') ?>" alt="<?= htmlspecialchars($item['product_name']) ?>" class="w-12 h-12 object-cover rounded-md mr-3">
                                        <span><?= htmlspecialchars($item['product_name']) ?></span>
                                    </td>
                                    <td class="py-3 px-4"><?= htmlspecialchars($item['quantity']) ?></td>
                                    <td class="py-3 px-4">PKR <?= number_format($item['price'], 2) ?></td>
                                    <td class="py-3 px-4">PKR <?= number_format($item['quantity'] * $item['price'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-gray-600">No items found for this order.</p>
            <?php endif; ?>

            <div class="flex justify-end mt-8">
                <a href="my_account.php#order-history" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg flex items-center">
                    <i data-lucide="arrow-left" class="w-5 h-5 mr-2"></i> Back to My Account
                </a>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>
