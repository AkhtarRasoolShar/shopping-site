<?php
/*
=========================================================
 File: order_details.php (UPGRADED)
 Description: Shows order details including payment info for admin approval.
 Location: /admin/order_details.php
=========================================================
*/
session_start();
require_once '../db.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}

$order_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$order_id) {
    header("Location: orders.php");
    exit;
}

// Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['order_status'])) {
    $new_status = $_POST['order_status'];
    $stmt = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    $stmt->execute();
    $stmt->close();
    header("Location: order_details.php?id=" . $order_id);
    exit;
}

// Fetch order details
$sql_order = "SELECT o.*, u.username, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?";
$stmt_order = $conn->prepare($sql_order);
$stmt_order->bind_param("i", $order_id);
$stmt_order->execute();
$order = $stmt_order->get_result()->fetch_assoc();
$stmt_order->close();

if (!$order) {
    header("Location: orders.php");
    exit;
}

// Fetch order items
$sql_items = "SELECT oi.quantity, oi.price, p.name, p.image FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
$stmt_items = $conn->prepare($sql_items);
$stmt_items->bind_param("i", $order_id);
$stmt_items->execute();
$order_items = $stmt_items->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt_items->close();

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details #<?= $order_id ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-gray-800 text-white p-6">...</aside>
        <main class="flex-1 p-10">
            <header class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold text-gray-800">Order Details <span class="text-purple-700 font-mono">#<?= $order_id ?></span></h2>
                <a href="orders.php" class="bg-gray-500 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-lg">&larr; Back to Orders</a>
            </header>

            <div class="grid lg:grid-cols-3 gap-8">
                <!-- Order Items -->
                <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-xl font-semibold mb-4">Items in this Order</h3>
                    <ul class="divide-y divide-gray-200">
                        <?php foreach ($order_items as $item): ?>
                            <li class="flex items-center py-4">
                                <img src="../<?= htmlspecialchars($item['image']) ?>" class="w-16 h-16 rounded-md mr-4">
                                <div class="flex-grow">
                                    <p class="font-semibold"><?= htmlspecialchars($item['name']) ?></p>
                                    <p class="text-sm text-gray-500">Quantity: <?= $item['quantity'] ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="font-semibold">PKR <?= number_format($item['price'] * $item['quantity'], 2) ?></p>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="text-right font-bold text-xl mt-4 pt-4 border-t">Total: PKR <?= number_format($order['total_price'], 2) ?></div>
                </div>

                <!-- Customer, Status & Payment -->
                <div class="lg:col-span-1 space-y-8">
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">Customer Details</h3>
                        <p><strong>Name:</strong> <?= htmlspecialchars($order['full_name']) ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($order['email']) ?></p>
                        <p class="mt-2"><strong>Shipping Address:</strong><br><?= nl2br(htmlspecialchars($order['address'])) ?><br><?= htmlspecialchars($order['city']) ?></p>
                    </div>

                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">Payment Information</h3>
                        <p><strong>Method:</strong> <?= htmlspecialchars($order['payment_method']) ?></p>
                        <?php if ($order['payment_method'] == 'Direct Bank Transfer'): ?>
                            <p><strong>Transaction ID:</strong> <?= htmlspecialchars($order['tid'] ?: 'Not provided') ?></p>
                            <?php if ($order['payment_proof_image']): ?>
                                <p class="mt-2"><strong>Payment Proof:</strong><br><a href="../<?= htmlspecialchars($order['payment_proof_image']) ?>" target="_blank" class="text-purple-600 hover:underline">View Image</a></p>
                            <?php else: ?>
                                <p><strong>Payment Proof:</strong> Not provided</p>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4">Update Status</h3>
                        <form action="order_details.php?id=<?= $order_id ?>" method="post">
                            <label for="order_status" class="block text-sm font-medium text-gray-700">Order Status</label>
                            <select name="order_status" id="order_status" class="mt-1 block w-full pl-3 pr-10 py-2 border-gray-300 rounded-md">
                                <option <?= $order['order_status'] == 'Pending Approval' ? 'selected' : '' ?>>Pending Approval</option>
                                <option <?= $order['order_status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                                <option <?= $order['order_status'] == 'Shipped' ? 'selected' : '' ?>>Shipped</option>
                                <option <?= $order['order_status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                                <option <?= $order['order_status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                            </select>
                            <button type="submit" class="w-full mt-4 bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 rounded-lg">Update Status</button>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>
