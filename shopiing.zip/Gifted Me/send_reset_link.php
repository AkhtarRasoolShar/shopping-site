<?php
/*
=========================================================
 File: send_reset_link.php (NEW)
 Description: Generates password reset token, saves it, and sends email.
 Location: /send_reset_link.php
=========================================================
*/
session_start();
require_once 'db.php'; // Include database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['reset_error'] = "Please enter a valid email address.";
        header("Location: forgot_password.php");
        exit;
    }

    // Check if email exists in users table
    $sql_check_email = "SELECT id FROM users WHERE email = ?";
    if ($stmt_check = $conn->prepare($sql_check_email)) {
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $stmt_check->store_result();

        if ($stmt_check->num_rows == 0) {
            $_SESSION['reset_error'] = "No account found with that email address.";
            header("Location: forgot_password.php");
            exit;
        }
        $stmt_check->close();
    } else {
        $_SESSION['reset_error'] = "Database error. Please try again later.";
        error_log("Failed to prepare email check query: " . $conn->error);
        header("Location: forgot_password.php");
        exit;
    }

    // Generate unique token
    $token = bin2hex(random_bytes(32)); // 64 character hex string
    $expiry_time = date("Y-m-d H:i:s", strtotime('+1 hour')); // Token valid for 1 hour

    // Save token and expiry to database for the user
    $sql_update_token = "UPDATE users SET reset_token = ?, reset_token_expiry = ? WHERE email = ?";
    if ($stmt_update = $conn->prepare($sql_update_token)) {
        $stmt_update->bind_param("sss", $token, $expiry_time, $email);
        if (!$stmt_update->execute()) {
            $_SESSION['reset_error'] = "Failed to generate reset link. Database update error.";
            error_log("Failed to update reset token: " . $stmt_update->error);
            header("Location: forgot_password.php");
            exit;
        }
        $stmt_update->close();
    } else {
        $_SESSION['reset_error'] = "Database error. Please try again later.";
        error_log("Failed to prepare token update query: " . $conn->error);
        header("Location: forgot_password.php");
        exit;
    }

    $conn->close(); // Close connection after database operation

    // --- Send Email ---
    $reset_link = "http://localhost/shopping/reset_password.php?token=" . $token; // Use HTTPS in production!
    $subject = "Password Reset Request for your Gifted Me Account";
    $message_body = "Dear User,\n\n"
                  . "You have requested to reset your password for your Gifted Me account.\n"
                  . "Please click on the following link to reset your password within the next 1 hour:\n"
                  . $reset_link . "\n\n"
                  . "If you did not request a password reset, please ignore this email.\n\n"
                  . "Thank you,\n"
                  . "Gifted Me Team";

    $headers = "From: no-reply@giftedme.com\r\n" .
               "Reply-To: no-reply@giftedme.com\r\n" .
               "X-Mailer: PHP/" . phpversion();

    if (mail($email, $subject, $message_body, $headers)) {
        $_SESSION['reset_success'] = "A password reset link has been sent to your email address.";
    } else {
        $_SESSION['reset_error'] = "Failed to send reset email. Please try again later. (Check server mail configuration)";
        error_log("Failed to send password reset email to: " . $email);
    }

    header("Location: forgot_password.php");
    exit;

} else {
    // Redirect if accessed directly without POST
    header("Location: forgot_password.php");
    exit;
}
?>
