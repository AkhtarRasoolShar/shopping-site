<?php
/*
=========================================================
 File: product_modal.php (UPDATED: T&C, Locations tabs, WhatsApp number)
 Description: Fetches and displays the content for the product detail modal.
 Location: /product_modal.php
=========================================================
*/
require_once 'db.php';

$product = null;
$product_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if ($product_id) {
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
        $product = $result->fetch_assoc();
        // Safely decode 'tags' into an array.
        $decoded_tags = json_decode($product['tags'] ?? '[]', true);
        $product['tags'] = is_array($decoded_tags) ? $decoded_tags : [];
    }
    $stmt->close();
}

if ($product):
?>
<div class="grid md:grid-cols-2 gap-6">
    <div class="text-center">
        <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full rounded-lg shadow-md mb-4" onerror="this.onerror=null;this.src='https://placehold.co/400x300/e2e8f0/4a5568?text=Image+Not+Found';">
        <p class="text-lg font-bold text-purple-700">PKR <?= htmlspecialchars(number_format($product['price'], 0)) ?> - 50000</p>
        <div class="mt-4 text-left text-sm text-gray-600 space-y-2">
            <p class="flex items-center"><i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2"></i>Redeemable at Physical Stores</p>
            <p class="flex items-center"><i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2"></i>Partial Redeemable at Multiple Brands</p>
        </div>
        <a href="product_detail.php?id=<?= $product['id'] ?>" class="mt-6 w-full inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-6 rounded-lg">Buy E-Gift Card</a>
    </div>

    <div>
        <div class="flex items-start mb-2">
            <img src="https://placehold.co/60x60/f3f4f6/4a5568?text=Logo" alt="Brand Logo" class="w-16 h-16 rounded-md mr-4">
            <div>
                <h2 class="text-2xl font-bold"><?= htmlspecialchars($product['name']) ?></h2>
                <div class="flex gap-2 mt-1">
                    <?php foreach($product['tags'] as $tag): ?>
                        <span class="text-xs font-semibold px-2 py-1 rounded-full bg-gray-200 text-gray-700"><?= htmlspecialchars($tag) ?></span>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <div class="border-b border-gray-200">
            <nav class="flex space-x-4 -mb-px" aria-label="Tabs">
                <button type="button" class="tab-button px-3 py-2 font-medium text-sm rounded-t-lg border-b-2 border-purple-600 text-purple-600" data-tab-target="gift-details">Gift Details</button>
                <button type="button" class="tab-button px-3 py-2 font-medium text-sm rounded-t-lg border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-tab-target="terms-conditions">T&C</button>
                <button type="button" class="tab-button px-3 py-2 font-medium text-sm rounded-t-lg border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300" data-tab-target="locations">Locations</button>
            </nav>
        </div>

        <div class="py-4 text-sm text-gray-600">
            <div id="gift-details" class="tab-content active-tab">
                <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>
                <p class="mt-4">For further information, you can call our Customer Service helpline **<a href="https://wa.me/923471386379" target="_blank" class="text-green-600 hover:underline">WhatsApp: 923471386379</a>** Or email us at help@giftkarte.com</p>
            </div>
            <div id="terms-conditions" class="tab-content hidden">
                <h3 class="font-semibold text-gray-800 mb-2">Terms & Conditions for <?= htmlspecialchars($product['name']) ?></h3>
                <ul class="list-disc list-inside space-y-1 pl-4">
                    <li>This E-Gift Card is redeemable for merchandise at [Brand Name] stores or online at [Brand Website].</li>
                    <li>Not redeemable for cash or credit.</li>
                    <li>Cannot be replaced if lost or stolen.</li>
                    <li>Valid for [e.g., 6 months, 1 year] from the date of purchase.</li>
                    <li>Any unused balance will remain on the card.</li>
                    <li>Full terms available at [Brand Website/Our Website T&C].</li>
                </ul>
                <p class="mt-4">Please note that each brand may have specific additional terms. Always check the brand's official website for their complete policies.</p>
            </div>
            <div id="locations" class="tab-content hidden">
                <h3 class="font-semibold text-gray-800 mb-2">Redemption Locations for <?= htmlspecialchars($product['name']) ?></h3>
                <p>This E-Gift Card can be redeemed at the following locations:</p>
                <ul class="list-disc list-inside space-y-1 pl-4 mt-2">
                    <li>**Online:** Visit [Brand Website] and enter your gift card code at checkout.</li>
                    <li>**Physical Stores:**</li>
                    <ul class="list-circle list-inside ml-4 space-y-1">
                        <li>[City 1]: [Store Address 1]</li>
                        <li>[City 2]: [Store Address 2]</li>
                        <li>[City 3]: [Store Address 3]</li>
                        <li>(Please visit brand website for full list of stores)</li>
                    </ul>
                </ul>
                <p class="mt-4">Please verify store hours and availability before visiting.</p>
            </div>
        </div>
    </div>
</div>
<script>
lucide.createIcons();

document.addEventListener('DOMContentLoaded', function() {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTabId = button.dataset.tabTarget;

            // Deactivate all buttons and hide all content
            tabButtons.forEach(btn => {
                btn.classList.remove('border-purple-600', 'text-purple-600');
                btn.classList.add('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
            });
            tabContents.forEach(content => {
                content.classList.add('hidden');
            });

            // Activate the clicked button and show its content
            button.classList.add('border-purple-600', 'text-purple-600');
            button.classList.remove('border-transparent', 'text-gray-500', 'hover:text-gray-700', 'hover:border-gray-300');
            document.getElementById(targetTabId).classList.remove('hidden');
        });
    });

    // Ensure the first tab is active on load
    document.querySelector('.tab-button[data-tab-target="gift-details"]').click(); // Programmatically click to set initial state
});
</script>
<?php
endif;
?>
