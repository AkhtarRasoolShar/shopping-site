<?php
/*
=========================================================
 File: cart_handler.php
 Description: Manages all shopping cart actions (add, update, remove).
 Location: /cart_handler.php
=========================================================
*/
session_start();
require_once 'db.php';

// Check if user is logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
    $action = $_POST['action'] ?? '';
    $user_id = $_SESSION['user_id'];

    if (!$product_id) {
        // Invalid product ID
        header("location: index.php");
        exit;
    }

    // Handle different actions
    switch ($action) {
        case 'add':
            // Check if product is already in cart
            $stmt = $conn->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                // Update quantity if product exists
                $stmt->close();
                $stmt = $conn->prepare("UPDATE cart SET quantity = quantity + ? WHERE user_id = ? AND product_id = ?");
                $stmt->bind_param("iii", $quantity, $user_id, $product_id);
            } else {
                // Insert new product into cart
                $stmt->close();
                $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
                $stmt->bind_param("iii", $user_id, $product_id, $quantity);
            }
            $stmt->execute();
            $stmt->close();
            header("location: cart.php");
            exit;

        case 'update':
            if ($quantity > 0) {
                $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
                $stmt->bind_param("iii", $quantity, $user_id, $product_id);
                $stmt->execute();
                $stmt->close();
            } else {
                // If quantity is 0 or less, remove the item
                $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
                $stmt->bind_param("ii", $user_id, $product_id);
                $stmt->execute();
                $stmt->close();
            }
            header("location: cart.php");
            exit;

        case 'remove':
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
            $stmt->bind_param("ii", $user_id, $product_id);
            $stmt->execute();
            $stmt->close();
            header("location: cart.php");
            exit;
    }
}

// Redirect if accessed directly without POST
header("location: index.php");
exit;
?>
