<?php
/*
=========================================================
 File: corporate_gifting.php (FIXED: Removed premature $conn->close() & added form feedback)
 Description: Dedicated page for Corporate Gifting, including features, contact form, clients, and testimonials.
 Location: /corporate_gifting.php
=========================================================
*/
session_start();
require_once 'db.php';

// Fetch Clients (using existing logic, but adapting for direct display here)
// In a real application, you might filter these specifically for corporate clients
$clients = [];
$sql_clients = "SELECT name, logo_url FROM clients WHERE is_active = 1 LIMIT 6"; // Limit to 6 as per screenshot
if($result_clients = $conn->query($sql_clients)){
    if ($result_clients->num_rows > 0) {
        $clients = $result_clients->fetch_all(MYSQLI_ASSOC);
    }
}

// Fetch Testimonials (using existing logic, but adapting for direct display here)
// In a real application, you might filter these specifically for corporate testimonials
$testimonials = [];
$sql_testimonials = "SELECT name, quote FROM testimonials WHERE is_active = 1 LIMIT 3"; // Limit to 3 as per screenshot
if($result_testimonials = $conn->query($sql_testimonials)){
     if ($result_testimonials->num_rows > 0) {
        $testimonials = $result_testimonials->fetch_all(MYSQLI_ASSOC);
    }
}

// IMPORTANT: REMOVED THIS LINE -> $conn->close(); // The connection should remain open for header.php and other includes.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Corporate Gifting - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-corporate-bg {
            background: linear-gradient(to right, #6d28d9, #8b5cf6); /* Deep purple to lighter purple gradient */
            position: relative;
            overflow: hidden;
            padding-top: 3rem;
            padding-bottom: 3rem;
            text-align: center;
        }
        .hero-corporate-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .feature-card {
            background-color: white;
            border-radius: 0.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 1.5rem;
            text-align: center;
        }
        .feature-icon-wrapper {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 3rem;
            height: 3rem;
            border-radius: 9999px; /* rounded-full */
            margin-bottom: 1rem;
        }
        /* Testimonial specific styling to match design */
        .testimonial-card {
            background-color: white; /* bg-white for the main card */
            border-radius: 0.5rem; /* rounded-lg */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* shadow-md */
            padding: 1.5rem; /* p-6 */
            border: 1px solid #e5e7eb; /* border border-gray-200 */
        }
        .testimonial-quote {
            background-color: #f9fafb; /* bg-gray-50 for the quote background */
            padding: 1rem; /* p-4 */
            border-radius: 0.375rem; /* rounded-md */
            margin-bottom: 1rem; /* mb-4 */
        }
        .testimonial-avatar {
            width: 3rem; /* w-12 */
            height: 3rem; /* h-12 */
            border-radius: 9999px; /* rounded-full */
            margin-right: 1rem; /* mr-4 */
            object-fit: cover;
        }
         .brand-logo-corporate {
            filter: grayscale(100%);
            opacity: 0.7;
            transition: all 0.3s ease;
        }
        .brand-logo-corporate:hover {
            filter: grayscale(0%);
            opacity: 1;
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main>
        <div class="hero-corporate-bg text-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <h1 class="text-4xl font-bold">Corporate Gifting</h1>
                <p class="mt-2 text-lg text-purple-200">
                    Create a bespoke E-Gift Card program for your employees, customers, and partners.
                </p>
                <p class="mt-4 text-purple-100 text-sm">
                    Call Us: 021-111-MYGIFT (694438) | info@giftkarte.com
                </p>
                <div class="mt-8">
                    <a href="#send-message" class="bg-white text-purple-700 hover:bg-purple-100 font-bold py-3 px-8 rounded-lg text-lg inline-flex items-center shadow-md">
                        <i data-lucide="mail" class="w-5 h-5 mr-2"></i> Send Message
                    </a>
                </div>
            </div>
        </div>

        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="text-center mb-10">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Pakistan's 1st Corporate E-Gifting Platform</h2>
                <p class="text-gray-600 max-w-3xl mx-auto">
                    We provide unique, differentiated and measurable solutions for all your gifting requirements, with a portfolio of 50+ Brands & 250+ E-Gift Cards redeemable at 2,000+ universal retail stores across Pakistan.
                </p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-purple-100"><i data-lucide="trophy" class="w-6 h-6 text-purple-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Most Reusable Corporate Gifts</h3>
                    <p class="text-gray-600 text-sm">Incentive Rewards, Long service Rewards, Sales Incentives, Customer Loyalty Programs.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-blue-100"><i data-lucide="gem" class="w-6 h-6 text-blue-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Variety of Brands (Over 250 Brands)</h3>
                    <p class="text-gray-600 text-sm">50+ categories & 2,000+ store locations.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-pink-100"><i data-lucide="gift" class="w-6 h-6 text-pink-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Personalized Gifting</h3>
                    <p class="text-gray-600 text-sm">Personalized messages, high-end gifting and more.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-yellow-100"><i data-lucide="truck" class="w-6 h-6 text-yellow-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">Flexible Delivery Methods</h3>
                    <p class="text-gray-600 text-sm">Digital (via Email & SMS), Physical (via Mail or Hand).</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-green-100"><i data-lucide="headphones" class="w-6 h-6 text-green-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">After Sales Service</h3>
                    <p class="text-gray-600 text-sm">Personalized customer care for every recipient.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon-wrapper bg-red-100"><i data-lucide="dollar-sign" class="w-6 h-6 text-red-600"></i></div>
                    <h3 class="text-xl font-semibold text-gray-800 mb-2">No Hidden Charges</h3>
                    <p class="text-gray-600 text-sm">Absolutely no pricing with full transparency.</p>
                </div>
            </div>

            <?php if (isset($_SESSION['form_success'])): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($_SESSION['form_success']); ?>
                </div>
                <?php unset($_SESSION['form_success']); // Clear the message after displaying ?>
            <?php endif; ?>

            <?php if (isset($_SESSION['form_error'])): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <?= htmlspecialchars($_SESSION['form_error']); ?>
                </div>
                <?php unset($_SESSION['form_error']); // Clear the message after displaying ?>
            <?php endif; ?>

            <section id="send-message" class="bg-white rounded-lg shadow-lg p-8 mb-12">
                <h2 class="text-2xl font-bold text-gray-800 mb-6">Send us a message</h2>
                <form action="process_corporate_message.php" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label for="name" class="block text-gray-700 text-sm font-bold mb-2">Your Name:</label>
                        <input type="text" name="name" id="name" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="company_name" class="block text-gray-700 text-sm font-bold mb-2">Company Name:</label>
                        <input type="text" name="company_name" id="company_name" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="mobile_no" class="block text-gray-700 text-sm font-bold mb-2">Mobile No.:</label>
                        <input type="tel" name="mobile_no" id="mobile_no" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div>
                        <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address:</label>
                        <input type="email" name="email" id="email" required class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline">
                    </div>
                    <div class="md:col-span-2">
                        <label for="message" class="block text-gray-700 text-sm font-bold mb-2">Message:</label>
                        <textarea name="message" id="message" rows="4" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" placeholder="Write message here..."></textarea>
                    </div>
                    <div class="md:col-span-2 flex justify-end items-center space-x-4">
                        <a href="mailto:info@giftkarte.com" class="text-purple-600 hover:underline flex items-center text-sm">
                            <i data-lucide="mail" class="w-4 h-4 mr-1"></i> Send a email
                        </a>
                        <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-lg shadow-md flex items-center">
                            Submit <i data-lucide="send" class="w-4 h-4 ml-2"></i>
                        </button>
                    </div>
                </form>
            </section>

            <section class="py-12">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-8">Our Clients</h2>
                <div class="flex flex-wrap justify-center items-center gap-x-12 gap-y-8">
                    <?php
                    // Sample data for clients (replace with actual dynamic data from $clients if needed)
                    $corporate_clients_sample = [
                        ['name' => 'Tapal', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=TAPAL'],
                        ['name' => 'Optel', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=Optel'],
                        ['name' => 'Shan', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=Shan'],
                        ['name' => 'MOLGROUP', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=MOLGROUP'],
                        ['name' => 'SANOFI', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=SANOFI'],
                        ['name' => 'Roche', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=Roche'],
                        ['name' => 'HBL', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=HBL'],
                        ['name' => 'Telenor', 'logo_url' => 'https://via.placeholder.com/150x50/f9fafb/000000?text=Telenor'],
                        // Add more as needed
                    ];
                     $display_corporate_clients = !empty($clients) ? $clients : $corporate_clients_sample;
                    ?>
                    <?php foreach ($display_corporate_clients as $client_item): ?>
                        <img src="<?= htmlspecialchars($client_item['logo_url']) ?>" alt="<?= htmlspecialchars($client_item['name']) ?>" class="h-12 md:h-16 object-contain brand-logo-corporate">
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="bg-white py-12 rounded-lg shadow-lg">
                <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                    <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">Testimonials</h2>
                    <div class="relative">
                        <div class="grid md:grid-cols-3 gap-8">
                            <?php
                            // Sample data if your DB doesn't have testimonials or images yet
                            $corporate_testimonials_sample = [
                                ['name' => 'Imran Khan - HBL', 'quote' => 'We have worked with Gifted Me for a few years now, and every time has been great. Customer service, the team at Gifted Me, their support, and responsiveness are top-notch. I highly recommend them.', 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=IK'],
                                ['name' => 'Nargis Khan - Engro Fertilizers', 'quote' => "I've used Gifted Me for our employee recognition programs. The variety of brands is excellent, and the personalization options add a special touch. It's truly a hassle-free gifting solution.", 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=NK'],
                                ['name' => 'Waqas Malik - Sanofi Pakistan', 'quote' => 'Gifted Me is very much helpful in corporate gifting. The service which is provided from Gifted Me side is not very much appreciated by us because their prompt services and coordination are always great.', 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=WM']
                            ];
                            $display_testimonials = !empty($testimonials) ? $testimonials : $corporate_testimonials_sample;
                            ?>
                            <?php foreach ($display_testimonials as $testimonial): ?>
                                <div class="testimonial-card">
                                    <div class="flex items-start mb-4">
                                        <img src="<?= htmlspecialchars($testimonial['user_image'] ?? 'https://placehold.co/48x48/dbeafe/4a5568?text=U') ?>" alt="User avatar" class="testimonial-avatar">
                                        <div>
                                            <span class="inline-block bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Corporate Client</span>
                                            <p class="text-lg text-gray-600 mt-2 testimonial-quote">"<?= htmlspecialchars($testimonial['quote']) ?> <a href="#" class="text-purple-600 hover:underline">View More</a>"</p>
                                        </div>
                                    </div>
                                    <p class="font-bold text-gray-800 text-left">- <?= htmlspecialchars($testimonial['name']) ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </section>

        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();
        // Any specific JS for this page can go here
    </script>
</body>
</html>
