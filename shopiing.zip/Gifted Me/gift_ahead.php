<?php
/*
=========================================================
 File: gift_ahead.php (NEW)
 Description: Explains the GiftAhead feature for scheduling gift cards.
 Location: /gift_ahead.php
=========================================================
*/
session_start();
require_once 'db.php'; // Ensure your database connection is included if needed for future dynamic content
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>GiftAhead - GiftKarta</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .hero-bg-purple-gradient {
            background: linear-gradient(to right, #6d28d9, #8b5cf6); /* Deep purple to lighter purple gradient */
        }
        .feature-box {
            background-color: #f3e8ff; /* Light purple background for boxes */
            border: 1px solid #c084fc; /* Purple border */
        }
        .icon-circle {
            background-color: #8b5cf6; /* Matching purple for icon background */
        }
    </style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <div class="hero-bg-purple-gradient text-white">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
            <h1 class="text-4xl font-bold">GiftAhead</h1>
            <p class="mt-2 text-lg text-purple-200">Schedule Your Gift Cards</p>
        </div>
    </div>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="bg-white rounded-lg shadow-lg p-8 mb-12">
            <h2 class="text-3xl font-bold text-gray-800 text-center mb-6">Exciting news! Introducing our new <span class="text-purple-700">GiftAhead</span> feature!</h2>
            <p class="text-center text-lg text-gray-700 max-w-3xl mx-auto">
                Now you never have to miss a birthday, anniversary or any other significant event of your loved ones.
                GiftKarte lets you schedule Gift-Cards for 6 months in advance!
            </p>

            <h3 class="text-xl font-semibold text-center text-gray-800 mt-10 mb-8">Here's how it works in three simple steps:</h3>

            <div class="grid md:grid-cols-3 gap-8 text-center">
                <div class="feature-box rounded-lg p-6 flex flex-col items-center">
                    <div class="icon-circle w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-md">
                        <i data-lucide="gift" class="w-8 h-8 text-white"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-800">1. Choose E-Gift Card</h4>
                </div>
                <div class="feature-box rounded-lg p-6 flex flex-col items-center">
                    <div class="icon-circle w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-md">
                        <i data-lucide="calendar" class="w-8 h-8 text-white"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-800">2. Select Delivery Date</h4>
                </div>
                <div class="feature-box rounded-lg p-6 flex flex-col items-center">
                    <div class="icon-circle w-16 h-16 rounded-full flex items-center justify-center mb-4 shadow-md">
                        <i data-lucide="credit-card" class="w-8 h-8 text-white"></i>
                    </div>
                    <h4 class="text-xl font-semibold text-gray-800">3. Complete Your Purchase</h4>
                </div>
            </div>

            <p class="text-center text-gray-700 mt-10">
                An email and SMS notification will be sent to the recipient on their special day, ensuring a memorable and delightful surprise.
            </p>
            <p class="text-center text-gray-700 mt-4 font-semibold">
                Never miss an occasion with our <span class="text-purple-700">GiftAhead</span> feature.
            </p>
            <p class="text-center text-gray-700 mt-4 text-xl font-bold">Happy gifting!</p>
        </div>
    </main>

    <?php include 'footer.php'; // Assuming you have a separate footer.php file, or copy footer content here ?>

    <script>
        lucide.createIcons();
        // Any specific JS for this page can go here
    </script>
</body>
</html>
