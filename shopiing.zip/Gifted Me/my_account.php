<?php
/*
=========================================================
 File: my_account.php (UPDATED: Profile Editing, FIXED: Removed premature $conn->close())
 Description: User's account dashboard with profile and order history.
 Location: /my_account.php
=========================================================
*/
session_start();
require_once 'db.php';

// Redirect if not logged in
if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// --- Handle Profile Update ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $tel = trim($_POST['tel']);

    // Basic validation
    if (empty($full_name) || empty($email) || empty($address) || empty($city) || empty($tel)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } else {
        // Check if email already exists for another user
        $stmt_check_email = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt_check_email->bind_param("si", $email, $user_id);
        $stmt_check_email->execute();
        $stmt_check_email->store_result();

        if ($stmt_check_email->num_rows > 0) {
            $error_message = "This email is already registered to another account.";
        } else {
            // Update user details
            $sql_update = "UPDATE users SET full_name = ?, email = ?, address = ?, city = ?, tel = ? WHERE id = ?";
            if ($stmt_update = $conn->prepare($sql_update)) {
                $stmt_update->bind_param("sssssi", $full_name, $email, $address, $city, $tel, $user_id);
                if ($stmt_update->execute()) {
                    $success_message = "Profile updated successfully!";
                    // Update session email if it changed
                    $_SESSION['user_email'] = $email;
                } else {
                    $error_message = "Error updating profile: " . $stmt_update->error;
                }
                $stmt_update->close();
            } else {
                $error_message = "Database prepare failed: " . $conn->error;
            }
        }
        $stmt_check_email->close();
    }
}

// --- Fetch User Details ---
$user_details = [];
$sql_user = "SELECT username, full_name, email, address, city, tel FROM users WHERE id = ?";
if ($stmt_user = $conn->prepare($sql_user)) {
    $stmt_user->bind_param("i", $user_id);
    $stmt_user->execute();
    $result_user = $stmt_user->get_result();
    if ($result_user->num_rows == 1) {
        $user_details = $result_user->fetch_assoc();
    }
    $stmt_user->close();
}

// --- Fetch User Order History (existing logic) ---
$order_history = [];
$sql_orders = "SELECT id, total_price, status, order_date FROM orders WHERE user_id = ? ORDER BY order_date DESC";
if ($stmt_orders = $conn->prepare($sql_orders)) {
    $stmt_orders->bind_param("i", $user_id);
    $stmt_orders->execute();
    $result_orders = $stmt_orders->get_result();
    if ($result_orders->num_rows > 0) {
        $order_history = $result_orders->fetch_all(MYSQLI_ASSOC);
    }
    $stmt_orders->close();
}

// IMPORTANT: Removed this line -> $conn->close(); // Close database connection after all fetches and updates.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Gifted Me</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-gray-100">

    <?php include 'header.php'; ?>

    <main class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-8">My Account</h1>

        <?php if ($success_message): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                <?= htmlspecialchars($success_message) ?>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                <?= htmlspecialchars($error_message) ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="md:col-span-1 bg-white rounded-lg shadow-md p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Account Navigation</h2>
                <ul class="space-y-2">
                    <li><a href="#profile-settings" class="block p-2 rounded-lg bg-purple-100 text-purple-700 font-medium">Profile Settings</a></li>
                    <li><a href="#order-history" class="block p-2 rounded-lg hover:bg-gray-100 text-gray-700">Order History</a></li>
                    <li><a href="change_password.php" class="block p-2 rounded-lg hover:bg-gray-100 text-gray-700">Change Password</a></li>
                    <li><a href="logout_user.php" class="block p-2 rounded-lg hover:bg-red-100 text-red-700">Logout</a></li>
                </ul>
            </div>

            <div class="md:col-span-2 space-y-8">
                <section id="profile-settings" class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Profile Settings</h2>
                    <form action="my_account.php" method="post">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="username" class="block text-gray-700 text-sm font-bold mb-2">Username:</label>
                                <input type="text" id="username" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 bg-gray-100 leading-tight" value="<?= htmlspecialchars($user_details['username'] ?? '') ?>" readonly>
                            </div>
                            <div>
                                <label for="full_name" class="block text-gray-700 text-sm font-bold mb-2">Full Name:</label>
                                <input type="text" name="full_name" id="full_name" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_details['full_name'] ?? '') ?>" required>
                            </div>
                            <div class="md:col-span-2">
                                <label for="email" class="block text-gray-700 text-sm font-bold mb-2">Email Address:</label>
                                <input type="email" name="email" id="email" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_details['email'] ?? '') ?>" required>
                            </div>
                            <div class="md:col-span-2">
                                <label for="address" class="block text-gray-700 text-sm font-bold mb-2">Address:</label>
                                <textarea name="address" id="address" rows="3" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required><?= htmlspecialchars($user_details['address'] ?? '') ?></textarea>
                            </div>
                            <div>
                                <label for="city" class="block text-gray-700 text-sm font-bold mb-2">City:</label>
                                <input type="text" name="city" id="city" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_details['city'] ?? '') ?>" required>
                            </div>
                            <div>
                                <label for="tel" class="block text-gray-700 text-sm font-bold mb-2">Phone Number:</label>
                                <input type="tel" name="tel" id="tel" class="shadow-sm border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" value="<?= htmlspecialchars($user_details['tel'] ?? '') ?>" required>
                            </div>
                        </div>
                        <div class="mt-6 flex justify-end">
                            <button type="submit" name="update_profile" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg focus:outline-none focus:shadow-outline">
                                Save Changes
                            </button>
                        </div>
                    </form>
                </section>

                <section id="order-history" class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Order History</h2>
                    <?php if (empty($order_history)): ?>
                        <p class="text-gray-600 text-center py-4">You have no past orders.</p>
                    <?php else: ?>
                        <div class="overflow-x-auto">
                            <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                                <thead>
                                    <tr class="bg-gray-50 text-left text-sm text-gray-600 uppercase">
                                        <th class="py-3 px-4">Order ID</th>
                                        <th class="py-3 px-4">Date</th>
                                        <th class="py-3 px-4">Total</th>
                                        <th class="py-3 px-4">Status</th>
                                        <th class="py-3 px-4 text-right">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order_history as $order): ?>
                                        <tr class="border-b border-gray-200">
                                            <td class="py-3 px-4">#<?= htmlspecialchars($order['id']) ?></td>
                                            <td class="py-3 px-4"><?= date('M j, Y', strtotime($order['order_date'])) ?></td>
                                            <td class="py-3 px-4">PKR <?= number_format($order['total_price'], 2) ?></td>
                                            <td class="py-3 px-4">
                                                <span class="px-2 py-1 rounded-full text-xs font-semibold
                                                    <?= ($order['status'] == 'Pending Approval') ? 'bg-yellow-100 text-yellow-800' : '' ?>
                                                    <?= ($order['status'] == 'Processing') ? 'bg-blue-100 text-blue-800' : '' ?>
                                                    <?= ($order['status'] == 'Shipped') ? 'bg-indigo-100 text-indigo-800' : '' ?>
                                                    <?= ($order['status'] == 'Delivered') ? 'bg-green-100 text-green-800' : '' ?>
                                                    <?= ($order['status'] == 'Cancelled') ? 'bg-red-100 text-red-800' : '' ?>
                                                ">
                                                    <?= htmlspecialchars($order['status']) ?>
                                                </span>
                                            </td>
                                            <td class="py-3 px-4 text-right">
                                                <a href="user_order_details.php?id=<?= $order['id'] ?>" class="text-blue-600 hover:underline">View Details</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </section>
            </div>
        </div>
    </main>

    <?php include 'footer.php'; ?>

    <script>
        lucide.createIcons();

        // Scroll to section based on hash in URL
        document.addEventListener('DOMContentLoaded', function() {
            if (window.location.hash) {
                const targetElement = document.querySelector(window.location.hash);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                    // Also update active class in sidebar
                    document.querySelectorAll('.account-navigation ul li a').forEach(link => {
                        link.classList.remove('bg-purple-100', 'text-purple-700', 'font-medium');
                        link.classList.add('hover:bg-gray-100', 'text-gray-700');
                    });
                    const activeLink = document.querySelector(`.account-navigation ul li a[href="${window.location.hash}"]`);
                    if (activeLink) {
                        activeLink.classList.remove('hover:bg-gray-100', 'text-gray-700');
                        activeLink.classList.add('bg-purple-100', 'text-purple-700', 'font-medium');
                    }
                }
            }
        });
    </script>
</body>
</html>
