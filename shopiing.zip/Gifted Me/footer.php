<footer class="bg-gray-800 text-white">
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-2 md:grid-cols-5 gap-8">
            <div class="col-span-2 md:col-span-1">
                <h3 class="text-lg font-semibold mb-4 flex items-center">
                    <i data-lucide="gift" class="w-6 h-6 mr-2"></i>
                    Gifted Me
                </h3>
                <p class="text-gray-400 text-sm">
                    Our digital gifting platform offers a variety of E-Gift Card in various retail categories that are redeemable at our ever-growing business partner retail stores across Pakistan.
                </p>
                <div class="flex space-x-4 mt-4">
                    <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="facebook" class="w-5 h-5"></i></a>
                    <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="instagram" class="w-5 h-5"></i></a>
                    <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="linkedin" class="w-5 h-5"></i></a>
                </div>
            </div>
            <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Company</h3><ul class="space-y-2 text-sm"><li><a href="about_gifted_me.php" class="text-gray-300 hover:text-white">About Gifted Me</a></li><li><a href="founders_story.php" class="text-gray-300 hover:text-white">Founder's Story</a></li><li><a href="#" class="text-gray-300 hover:text-white">In-Store Partner Brand List</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Partner Brand List</a></li><li><a href="#" class="text-gray-300 hover:text-white">Brands On Sale</a></li><li><a href="contact.php" class="text-gray-300 hover:text-white">Contact</a></li></ul></div>
            <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">E-Gift Card</h3><ul class="space-y-2 text-sm"><li><a href="egift_cards.php" class="text-gray-300 hover:text-white">E-Gift Cards</a></li><li><a href="corporate_gifting.php" class="text-gray-300 hover:text-white">Corporate Gifting</a></li><li><a href="gk_coupon.php" class="text-gray-300 hover:text-white">GK-Coupon (for Corporate Clients)</a></li></ul></div>
            <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Discover</h3><ul class="space-y-2 text-sm"><li><a href="how_it_works.php" class="text-gray-300 hover:text-white">How It Works</a></li><li><a href="#" class="text-gray-300 hover:text-white">How To Order</a></li><li><a href="#" class="text-gray-300 hover:text-white">In-Store Redemption</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Redemption</a></li><li><a href="faqs.php" class="text-gray-300 hover:text-white">FAQs</a></li><li><a href="blog.php" class="text-gray-300 hover:text-white">Blog</a></li><li><a href="#" class="text-gray-300 hover:text-white">Announcements</a></li></ul></div>
            <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Resources</h3><ul class="space-y-2 text-sm"><li><a href="admin/" class="text-gray-300 hover:text-white">Vendor Portal Login</a></li><li><a href="#" class="text-gray-300 hover:text-white">Onboarding Request Form</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Redemption API</a></li><li><a href="#" class="text-gray-300 hover:text-white">Issuance API Doc (New)</a></li></ul></div>
        </div>
        <div class="mt-12 border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center text-sm">
            <p class="text-gray-400">&copy; <?= date("Y") ?> Gifted Me. All rights reserved.</p>
            <div class="flex space-x-4 mt-4 md:mt-0"><a href="privacy_policy.php" class="text-gray-400 hover:text-white">Privacy Policy</a><a href="terms_conditions.php" class="text-gray-400 hover:text-white">Terms & Conditions</a><a href="#" class="text-gray-400 hover:text-white">Disclaimer</a><img src="https://placehold.co/100x20/ffffff/cccccc?text=VISA+Master" alt="Payment Methods" class="ml-4"></div>
        </div>
         <p class="text-gray-400 text-center mt-6">Send Gifts to Pakistan from USA, UK, Canada, UAE, and all over the world with Giftkarte.com</p>
    </div>
</footer>
