<?php
/*
=========================================================
 File: place_order.php
 Description: Processes checkout and saves payment details for admin review.
 Location: /place_order.php
=========================================================
*/
session_start();
require_once 'db.php';

// --- DEBUGGING START ---
echo "<pre>";
echo "--- POST Data ---\n";
var_dump($_POST);
echo "\n--- FILES Data ---\n";
var_dump($_FILES);
echo "</pre>";
// If you see output, comment out `exit;` below to continue execution
// exit; // Temporarily stop script here to inspect data
// --- DEBUGGING END ---


if (!isset($_SESSION["user_loggedin"]) || $_SESSION["user_loggedin"] !== true) {
    header("location: login.php");
    exit;
}

// Re-add the POST check after debugging, as it's important for security
// if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $user_id = $_SESSION['user_id'];
    $full_name = trim($_POST['full_name']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $payment_method = trim($_POST['payment_method']);
    $tel = trim($_POST['tel']); // Added this based on checkout.php fields
    $country = trim($_POST['country']); // Added this based on checkout.php fields

    // Collect card details only if payment method is Credit/Debit Card
    $card_number = '';
    $expiry_date = '';
    $cvv = '';
    $save_card_details = ''; // This will be 'on' if checked

    if ($payment_method === 'Credit / Debit Card') {
        $card_number = trim($_POST['card_number'] ?? '');
        $expiry_date = trim($_POST['expiry_date'] ?? '');
        $cvv = trim($_POST['cvv'] ?? '');
        $save_card_details = isset($_POST['save_card_details']) ? 'on' : 'off'; // Checkbox value
    }

    // Collect bank transfer details only if payment method is Direct Bank Transfer
    $tid = trim($_POST['tid'] ?? '');

    // --- Handle Payment Proof Upload ---
    $payment_proof_path = '';
    if (isset($_FILES['payment_proof']) && $_FILES['payment_proof']['error'] == 0) {
        $target_dir = "uploads/proofs/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . time() . '_' . basename($_FILES["payment_proof"]["name"]);
        if (move_uploaded_file($_FILES["payment_proof"]["tmp_name"], $target_file)) {
            $payment_proof_path = $target_file;
        } else {
            // Error handling for file upload
            $_SESSION['form_error'] = 'Failed to upload payment proof.';
            header("location: checkout.php?error=1");
            exit;
        }
    }

    // --- Start Transaction ---
    $conn->begin_transaction();

    try {
        // 1. Get cart items and calculate total price
        $cart_items = [];
        $total_price = 0;
        $sql_cart = "SELECT p.id, p.price, c.quantity FROM cart c JOIN products p ON c.product_id = p.id WHERE c.user_id = ?";
        $stmt_cart = $conn->prepare($sql_cart);
        $stmt_cart->bind_param("i", $user_id);
        $stmt_cart->execute();
        $result = $stmt_cart->get_result();
        if ($result->num_rows == 0) {
            throw new Exception("Cart is empty.");
        }
        while ($row = $result->fetch_assoc()) {
            $cart_items[] = $row;
            $total_price += $row['price'] * $row['quantity'];
        }
        $stmt_cart->close();

        // Apply 10% discount from checkout.php logic
        $discount_amount = $total_price * (10 / 100);
        $final_total_after_discount = $total_price - $discount_amount;


        // 2. Insert into `orders` table
        // NOTE: We set order_status to 'Pending Approval' for admin review
        // IMPORTANT: Ensure 'tel' and 'country' columns exist in your 'orders' table.
        // Also 'card_number', 'expiry_date', 'cvv', 'card_saved' (if you choose to store these, with major security warnings)

        // For now, let's include tel, country, and the basic payment method details.
        // I will NOT include full card details here due to security.
        // If you need to record that a card was used, save 'payment_method' and maybe 'card_last_four' (if you implement that securely).

        $order_status = 'Pending Approval';
        // Updated INSERT statement to include 'tel' and 'country' from the form
        $sql_order = "INSERT INTO orders (user_id, full_name, address, city, country, tel, total_price, payment_method, tid, payment_proof_image, order_status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_order = $conn->prepare($sql_order);
        $stmt_order->bind_param("issssdsssss", $user_id, $full_name, $address, $city, $country, $tel, $final_total_after_discount, $payment_method, $tid, $payment_proof_path, $order_status);
        $stmt_order->execute();
        $order_id = $stmt_order->insert_id;
        $stmt_order->close();

        // 3. Insert into `order_items` table
        $sql_items = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
        $stmt_items = $conn->prepare($sql_items);
        foreach ($cart_items as $item) {
            $stmt_items->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
            $stmt_items->execute();
        }
        $stmt_items->close();

        // 4. Clear the user's cart
        $sql_clear = "DELETE FROM cart WHERE user_id = ?";
        $stmt_clear = $conn->prepare($sql_clear);
        $stmt_clear->bind_param("i", $user_id);
        $stmt_clear->execute();
        $stmt_clear->close();

        // --- Commit Transaction ---
        $conn->commit();

        header("location: order_success.php?order_id=" . $order_id);
        exit;

    } catch (Exception $e) {
        $conn->rollback();
        // Log the actual error for debugging, do not expose to user
        error_log("Order placement failed: " . $e->getMessage());
        header("location: checkout.php?error=1"); // Generic error message to user
        exit;
    }
// Re-add this closing curly brace for the POST check after debugging
// } else {
//     header("location: index.php"); // Or checkout.php if it makes more sense
//     exit;
// }
?>
