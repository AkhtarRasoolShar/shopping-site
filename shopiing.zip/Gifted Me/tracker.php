<?php
/*
=========================================================
 File: tracker.php
 Description: Logs visitor activity to the database.
 Location: /tracker.php
=========================================================
*/

// This script is included by header.php to log visits.

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Do not log visits from logged-in admins to avoid cluttering the log
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    return; // Exit script and do not log
}

// The db connection should already be established by header.php, but we check just in case.
if (!isset($conn) || !$conn) {
    // If no connection, we can't do anything. Silently exit.
    return;
}

$ip_address = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$page_url = $_SERVER['REQUEST_URI'];

// To avoid flooding the database, we can update the timestamp of the last visit
// from the same IP if it's within the last 5 minutes on the same page.
$stmt = $conn->prepare("SELECT id, visit_time FROM visitor_logs WHERE ip_address = ? AND page_url = ? ORDER BY visit_time DESC LIMIT 1");
$stmt->bind_param("ss", $ip_address, $page_url);
$stmt->execute();
$result = $stmt->get_result();
$last_visit = $result->fetch_assoc();
$stmt->close();

if ($last_visit && (time() - strtotime($last_visit['visit_time']) < 300)) { // 300 seconds = 5 minutes
    // If there is a recent record, just update its timestamp
    $stmt_update = $conn->prepare("UPDATE visitor_logs SET visit_time = NOW() WHERE id = ?");
    $stmt_update->bind_param("i", $last_visit['id']);
    $stmt_update->execute();
    $stmt_update->close();
} else {
    // If no recent record, insert a new one
    $stmt_insert = $conn->prepare("INSERT INTO visitor_logs (ip_address, user_agent, page_url) VALUES (?, ?, ?)");
    $stmt_insert->bind_param("sss", $ip_address, $user_agent, $page_url);
    $stmt_insert->execute();
    $stmt_insert->close();
}

// The connection is managed by the parent script (header.php)
?>
