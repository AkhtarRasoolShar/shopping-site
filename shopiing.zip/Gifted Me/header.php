<?php
/*
=========================================================
 File: header.php (UPGRADED)
 Description: Reusable header with a new two-tier design and enhanced mobile responsiveness.
 Location: /header.php
=========================================================
*/

// Start the session if it hasn't been started already
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Include database connection if not already available
if (!isset($conn) || !$conn) {
    require_once 'db.php';
}
// Include the tracker for analytics or other purposes
require_once 'tracker.php';

// Initialize cart item count
$cart_item_count = 0;
// Check if the user is logged in to fetch cart items
if (isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true) {
    $user_id = $_SESSION['user_id'];
    // Query to sum the quantity of items in the user's cart
    $sql = "SELECT SUM(quantity) as total_items FROM cart WHERE user_id = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $user_id); // Bind user_id to the query
        $stmt->execute(); // Execute the prepared statement
        $result = $stmt->get_result(); // Get the result set
        if ($row = $result->fetch_assoc()) {
            $cart_item_count = $row['total_items'] ?? 0; // Get total items, default to 0 if null
        }
        $stmt->close(); // Close the statement
    }
}
?>
<header class="bg-white shadow-sm sticky top-0 z-50">
    <!-- Top Tier Navigation (Secondary Nav) -->
    <div class="bg-gray-100 text-sm text-gray-600">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-1 flex flex-col sm:flex-row justify-between items-center">
            <!-- Left links for top tier -->
            <div class="flex flex-wrap justify-center sm:justify-start space-x-4 py-1 sm:py-0">
                <a href="download.php" class="hover:text-purple-700">Download App</a>
                <a href="gk_points.php" class="hover:text-purple-700">GK Points</a>
                <a href="#" class="hover:text-purple-700">GiftAhead</a>
                <a href="activation.php" class="hover:text-purple-700">Activation</a>
            </div>
            <!-- Right links for top tier -->
            <div class="flex flex-wrap justify-center sm:justify-end space-x-4 py-1 sm:py-0">
                <a href="#" class="hover:text-purple-700">Why Gifted Me?</a>
                <a href="contact.php" class="hover:text-purple-700">Contact Us</a>
                <a href="faqs.php" class="hover:text-purple-700">FAQs</a>
                <a href="cart.php" class="hover:text-purple-700 relative">
                    Cart
                    <?php if ($cart_item_count > 0): ?>
                        <span class="absolute -top-2 -right-2 bg-purple-600 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                            <?= $cart_item_count ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>

    <!-- Main Navigation Bar -->
    <div class="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center py-3">
        <!-- Logo -->
        <a href="index.php" class="text-3xl font-bold text-purple-700 flex items-center">
            <i data-lucide="gift" class="w-8 h-8 mr-2"></i>
            <span>Gifted Me</span>
        </a>

        <!-- Desktop Navigation (hidden on mobile) -->
        <nav class="hidden md:flex items-center space-x-4 font-semibold text-gray-700">
            <a href="products.php" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors duration-300">Buy E-Gift Card</a>
            <a href="categories.php" class="hover:text-purple-700">Categories</a>
            <a href="#" class="hover:text-purple-700">To Whom</a>
            <a href="corporate_gifting.php" class="hover:text-purple-700">Corporate Gifting</a>
            <a href="how_it_works.php" class="hover:text-purple-700">How To</a>
            <?php if(isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true): ?>
                <a href="my_account.php" class="hover:text-purple-700">My Account</a>
                <a href="logout_user.php" class="hover:text-purple-700">Logout</a>
            <?php else: ?>
                <a href="login.php" class="hover:text-purple-700">Login / Signup</a>
            <?php endif; ?>
        </nav>

        <!-- Mobile Menu Button (Hamburger Icon) -->
        <div class="md:hidden flex items-center">
            <button id="mobile-menu-button" class="text-gray-700 hover:text-purple-700 focus:outline-none">
                <i data-lucide="menu" class="w-8 h-8"></i>
            </button>
        </div>
    </div>

    <!-- Mobile Menu Overlay -->
    <div id="mobile-menu" class="fixed inset-0 bg-white z-40 transform translate-x-full transition-transform duration-300 ease-in-out md:hidden">
        <div class="flex justify-between items-center p-4 border-b border-gray-200">
            <a href="index.php" class="text-2xl font-bold text-purple-700 flex items-center">
                <i data-lucide="gift" class="w-7 h-7 mr-2"></i>
                <span>Gifted Me</span>
            </a>
            <button id="mobile-menu-close-button" class="text-gray-700 hover:text-purple-700 focus:outline-none">
                <i data-lucide="x" class="w-8 h-8"></i>
            </button>
        </div>
        <nav class="flex flex-col p-4 space-y-4 text-lg font-semibold text-gray-800">
            <a href="products.php" class="bg-purple-600 text-white px-4 py-2 rounded-lg text-center hover:bg-purple-700 transition-colors duration-300">Buy E-Gift Card</a>
            <a href="categories.php" class="hover:text-purple-700 py-2">Categories</a>
            <a href="#" class="hover:text-purple-700 py-2">To Whom</a>
            <a href="corporate_gifting.php" class="hover:text-purple-700 py-2">Corporate Gifting</a>
            <a href="how_it_works.php" class="hover:text-purple-700 py-2">How To</a>
            <a href="download.php" class="hover:text-purple-700 py-2">Download App</a>
            <a href="gk_points.php" class="hover:text-purple-700 py-2">GK Points</a>
            <a href="#" class="hover:text-purple-700 py-2">GiftAhead</a>
            <a href="activation.php" class="hover:text-purple-700 py-2">Activation</a>
            <a href="#" class="hover:text-purple-700 py-2">Why Gifted Me?</a>
            <a href="contact.php" class="hover:text-purple-700 py-2">Contact Us</a>
            <a href="faqs.php" class="hover:text-purple-700 py-2">FAQs</a>
            <a href="cart.php" class="hover:text-purple-700 py-2 flex items-center">
                Cart
                <?php if ($cart_item_count > 0): ?>
                    <span class="ml-2 bg-purple-600 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                        <?= $cart_item_count ?>
                    </span>
                <?php endif; ?>
            </a>
            <?php if(isset($_SESSION["user_loggedin"]) && $_SESSION["user_loggedin"] === true): ?>
                <a href="my_account.php" class="hover:text-purple-700 py-2">My Account</a>
                <a href="logout_user.php" class="hover:text-purple-700 py-2">Logout</a>
            <?php else: ?>
                <a href="login.php" class="hover:text-purple-700 py-2">Login / Signup</a>
            <?php endif; ?>
        </nav>
    </div>
</header>

<script>
    // Initialize Lucide icons
    lucide.createIcons();

    // Get references to the mobile menu elements
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenuCloseButton = document.getElementById('mobile-menu-close-button');
    const mobileMenu = document.getElementById('mobile-menu');

    // Function to open the mobile menu
    function openMobileMenu() {
        mobileMenu.classList.remove('translate-x-full'); // Slide in from right
        mobileMenu.classList.add('translate-x-0');
        document.body.style.overflow = 'hidden'; // Prevent scrolling on body when menu is open
    }

    // Function to close the mobile menu
    function closeMobileMenu() {
        mobileMenu.classList.remove('translate-x-0');
        mobileMenu.classList.add('translate-x-full'); // Slide out to right
        document.body.style.overflow = ''; // Restore body scrolling
    }

    // Event listeners for opening and closing the mobile menu
    mobileMenuButton.addEventListener('click', openMobileMenu);
    mobileMenuCloseButton.addEventListener('click', closeMobileMenu);

    // Close menu if a link inside is clicked (optional, for single-page apps or if links navigate)
    mobileMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });

    // Re-render Lucide icons if content is dynamically added/changed (e.g., after initial load or AJAX)
    // This is already called once globally, but good to keep in mind for dynamic content.
    // lucide.createIcons();
</script>
