<?php
// includes/functions.php

/**
 * Fetches the active announcement message from the database.
 * @param mysqli $conn The database connection object.
 * @return string The announcement message or an empty string.
 */
function getActiveAnnouncement(mysqli $conn): string {
    $sql = "SELECT message FROM announcements WHERE is_active = TRUE LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $row = $result->fetch_assoc()) {
        return $row['message'];
    }
    return '';
}

/**
 * Fetches products from the database with a limit and offset.
 * Uses prepared statements for security.
 * @param mysqli $conn The database connection object.
 * @param int $limit The number of products to fetch.
 * @param int $offset The starting point to fetch from.
 * @return array An array of products.
 */
function getProducts(mysqli $conn, int $limit, int $offset = 0): array {
    $sql = "SELECT id, name, category, image FROM products ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $limit, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_all(MYSQLI_ASSOC);
}

/**
 * Fetches active testimonials from the database.
 * @param mysqli $conn The database connection object.
 * @return array An array of testimonials.
 */
function getTestimonials(mysqli $conn): array {
    $sql = "SELECT name, quote FROM testimonials WHERE is_active = 1 LIMIT 3";
    $result = $conn->query($sql);
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

/**
 * Fetches active clients from the database.
 * @param mysqli $conn The database connection object.
 * @return array An array of clients.
 */
function getClients(mysqli $conn): array {
    $sql = "SELECT name, logo_url FROM clients WHERE is_active = 1 LIMIT 5";
    $result = $conn->query($sql);
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

/**
 * Gets counts of total and emerging brands.
 * @param mysqli $conn The database connection object.
 * @return array An associative array with 'total' and 'emerging' counts.
 */
function getBrandCounts(mysqli $conn): array {
    $total = $conn->query("SELECT COUNT(id) as count FROM products")->fetch_assoc()['count'] ?? 0;
    $emerging = $conn->query("SELECT COUNT(id) as count FROM products WHERE category = 'Emerging Brands'")->fetch_assoc()['count'] ?? 0;
    return ['total' => $total, 'emerging' => $emerging];
}

/**
 * Renders a single product card using a reusable HTML template.
 * @param array $product The product data array.
 */
function renderProductCard(array $product): void {
    $productId = htmlspecialchars($product['id']);
    $productImage = htmlspecialchars($product['image']);
    $productName = htmlspecialchars($product['name']);
    $productCategory = htmlspecialchars($product['category']);

    echo <<<HTML
    <div class="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
        <button class="w-full text-left product-modal-trigger" data-product-id="{$productId}">
            <div class="relative">
                <img src="{$productImage}" alt="{$productName}" class="w-full h-48 object-cover">
            </div>
            <div class="p-4">
                <h3 class="text-lg font-semibold text-gray-900 truncate">{$productName}</h3>
                <p class="text-sm text-gray-500">{$productCategory}</p>
            </div>
        </button>
    </div>
    HTML;
}
?>