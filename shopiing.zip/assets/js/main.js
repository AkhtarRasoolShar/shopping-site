document.addEventListener('DOMContentLoaded', () => {
    
    // This creates all icons and ignores any with the 'data-lucide-ignore' attribute
    lucide.createIcons({
        ignore: ['[data-lucide-ignore]']
    });

    // Select all the modal elements
    const modal = document.getElementById('product-modal');
    const modalBody = document.getElementById('modal-body');
    const modalBuyBtn = document.getElementById('modal-buy-btn');
    const closeButtons = [
        document.getElementById('modal-close-btn'), 
        document.getElementById('modal-close-btn-footer')
    ];
    const triggers = document.querySelectorAll('.product-modal-trigger');

    // Logic to open modal and fetch content
    triggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const productId = trigger.dataset.productId;
            modal.classList.add('is-open');
            modalBody.innerHTML = '<div class="text-center p-8"><p>Loading...</p></div>';

            fetch(`product_modal.php?id=${productId}`)
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`Network response was not ok: ${response.statusText}`);
                    }
                    return response.text();
                })
                .then(html => {
                    modalBody.innerHTML = html;
                    modalBuyBtn.href = `product_detail.php?id=${productId}`;
                })
                .catch(error => {
                    console.error('Error fetching product details:', error);
                    modalBody.innerHTML = '<p class="text-center text-red-500">Sorry, we could not load the product details.</p>';
                });
        });
    });

    // Logic to close the modal
    const closeModal = () => {
        modal.classList.remove('is-open');
    };

    closeButtons.forEach(btn => {
        if (btn) {
            btn.addEventListener('click', closeModal);
        }
    });
    
    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeModal();
        }
    });
});