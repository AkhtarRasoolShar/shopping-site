<?php
// product_modal.php

// Connect to the database
require_once 'db.php';

// 1. Validate the Product ID from the URL (e.g., ?id=1)
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    // If the ID is missing or not a number, show an error and stop.
    echo '<p class="text-red-500 text-center p-8">Invalid product request.</p>';
    exit();
}
$productId = (int)$_GET['id'];

// 2. Fetch Product Details Securely using a Prepared Statement
// Note: If your 'products' table doesn't have 'description' or 'price', you can remove them from the SQL query.
$sql = "SELECT name, category, image, description, price FROM products WHERE id = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();

// 3. Display the Product HTML or an Error Message
if ($product = $result->fetch_assoc()) {
    // Sanitize all data before displaying it to prevent security issues
    $name = htmlspecialchars($product['name']);
    $category = htmlspecialchars($product['category']);
    $image = htmlspecialchars($product['image']);
    $description = htmlspecialchars($product['description'] ?? 'No description available.');
    $price = isset($product['price']) ? 'PKR ' . number_format($product['price']) : 'Price not available';

    // This is the pure HTML fragment that will be injected into the pop-up
    echo <<<HTML
    <div class="grid md:grid-cols-2 gap-6 items-start">
        <div>
            <img src="{$image}" alt="{$name}" class="w-full h-auto rounded-lg shadow-md object-cover">
        </div>
        <div>
            <span class="inline-block bg-purple-100 text-purple-800 text-sm font-semibold px-3 py-1 rounded-full">{$category}</span>
            <h2 class="text-3xl font-bold text-gray-900 mt-2 mb-4">{$name}</h2>
            <p class="text-gray-600 mb-4">{$description}</p>
            <div class="text-3xl font-extrabold text-gray-800">
                {$price}
            </div>
        </div>
    </div>
    HTML;

} else {
    // If no product was found with the given ID
    echo '<p class="text-gray-700 text-center p-8">Sorry, this product could not be found.</p>';
}

// 4. Clean up
$stmt->close();
$conn->close();
?>