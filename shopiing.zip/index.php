<?php
// Start the session at the very beginning of the file
session_start();

// Check if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    // Redirect to the dedicated visitors page
    header("Location: visitors.php");
    exit();
}

// If the user IS logged in, continue with the rest of the page logic
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gifted Me - Digital Gift Card Marketplace</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>

    <style>
        body { font-family: 'Inter', sans-serif; background-color: #f8fafc; }
        .hero-main-bg {
            /* This corresponds to the deep purple background with some texture */
            background: linear-gradient(to right, #6d28d9, #8b5cf6);
            position: relative;
            overflow: hidden;
            padding-top: 4rem; /* Adjust as needed for spacing from header */
        }
        .hero-main-bg::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle at top left, rgba(255,255,255,0.1) 0%, transparent 50%), radial-gradient(circle at bottom right, rgba(255,255,255,0.1) 0%, transparent 50%);
            z-index: 0;
        }
        .hero-content-wrapper {
            position: relative;
            z-index: 10;
        }
        .modal { display: none; }
        .modal.is-open { display: flex; }
        .stats-section {
            /* This section has a light background, as seen in previous images */
            background-color: #f9fafb;
        }
        .download-section {
            /* This section has a purple gradient background, as seen in previous images */
            background: linear-gradient(to right, #f3e8ff, #e9d5ff);
        }
        .brand-logo {
            filter: grayscale(100%);
            opacity: 0.8;
            transition: all 0.3s ease;
        }
        .brand-logo:hover {
            filter: grayscale(0%);
            opacity: 1;
        }
        .tab-active {
            border-color: #6d28d9;
            background-color: #6d28d9;
            color: white;
            border-radius: 9999px;
        }
        /* Styles for the "the perfect gift for every space" section */
        .gift-space-card {
            background-color: white;
            border-radius: 0.5rem; /* rounded-lg */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* shadow-md */
            padding: 1rem; /* p-4 */
        }
        .gift-space-card .text-section {
            background-color: #f0f4f8; /* A light grey for the background of the text area */
            border-radius: 0.375rem; /* rounded-md */
            padding: 1.5rem; /* p-6 */
        }
        /* Removed .gift-space-card .image-grid as requested */

        /* Specific adjustments for the icon boxes in the hero section */
        .hero-icon-box {
            background-color: white;
            border-radius: 0.5rem; /* rounded-lg */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* shadow-md */
            padding: 1rem; /* p-4 */
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            transition: all 0.3s ease;
        }
        .hero-icon-box:hover {
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1); /* hover:shadow-lg */
            transform: translateY(-2px); /* hover:-translate-y-1 */
        }

        /* Testimonial specific styling to match design */
        .testimonial-card {
            background-color: white; /* bg-white for the main card */
            border-radius: 0.5rem; /* rounded-lg */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* shadow-md */
            padding: 1.5rem; /* p-6 */
            border: 1px solid #e5e7eb; /* border border-gray-200 */
        }
        .testimonial-quote {
            background-color: #f9fafb; /* bg-gray-50 for the quote background */
            padding: 1rem; /* p-4 */
            border-radius: 0.375rem; /* rounded-md */
            margin-bottom: 1rem; /* mb-4 */
        }
        .testimonial-avatar {
            width: 3rem; /* w-12 */
            height: 3rem; /* h-12 */
            border-radius: 9999px; /* rounded-full */
            margin-right: 1rem; /* mr-4 */
            object-fit: cover;
        }
    </style>
</head>
<body class="bg-white">

    <?php
        require_once 'db.php';

        // Fetch active announcement message
        $announcement_message = '';
        $sql_announcement = "SELECT message FROM announcements WHERE is_active = TRUE LIMIT 1";
        if ($result_announcement = $conn->query($sql_announcement)) {
            if ($row = $result_announcement->fetch_assoc()) {
                $announcement_message = $row['message'];
            }
            $result_announcement->free();
        }

        // Fetch Occasion Cards (first 4 products)
        $occasion_cards = [];
        $sql_occasion = "SELECT id, name, category, image FROM products ORDER BY created_at DESC LIMIT 4";
        if($result_occasion = $conn->query($sql_occasion)){
            if ($result_occasion->num_rows > 0) {
                $occasion_cards = $result_occasion->fetch_all(MYSQLI_ASSOC);
            }
        }

        // Fetch Brand Products (next 5 products)
        $brand_products = [];
        $sql_brands = "SELECT id, name, category, image FROM products ORDER BY created_at DESC LIMIT 5 OFFSET 4";
        if($result_brands = $conn->query($sql_brands)){
            if ($result_brands->num_rows > 0) {
                $brand_products = $result_brands->fetch_all(MYSQLI_ASSOC);
            }
        }

        // Fetch Testimonials
        $testimonials = [];
        // Removed 'user_image' from SELECT to avoid 'Unknown column' error
        $sql_testimonials = "SELECT name, quote FROM testimonials WHERE is_active = 1 LIMIT 3";
        if($result_testimonials = $conn->query($sql_testimonials)){
             if ($result_testimonials->num_rows > 0) {
                 $testimonials = $result_testimonials->fetch_all(MYSQLI_ASSOC);
            }
        }

        // Fetch Clients
        $clients = [];
        $sql_clients = "SELECT name, logo_url FROM clients WHERE is_active = 1 LIMIT 5";
        if($result_clients = $conn->query($sql_clients)){
            if ($result_clients->num_rows > 0) {
                $clients = $result_clients->fetch_all(MYSQLI_ASSOC);
            }
        }

        // Fetch Brand Counts
        $total_brands_count = $conn->query("SELECT COUNT(id) as count FROM products")->fetch_assoc()['count'];
        $emerging_brands_count = $conn->query("SELECT COUNT(id) as count FROM products WHERE category = 'Emerging Brands'")->fetch_assoc()['count'];

    ?>

    <?php include 'header.php'; ?>

    <main>
        <?php if (!empty($announcement_message)): ?>
            <div class="bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4" role="alert">
                <div class="container mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                    <p class="font-bold">Announcement:</p>
                    <p class="flex-grow ml-4"><?= htmlspecialchars($announcement_message) ?></p>
                    <button class="ml-auto text-yellow-700 hover:text-yellow-900" onclick="this.parentElement.parentElement.style.display='none';"><i data-lucide="x" class="w-5 h-5"></i></button>
                </div>
            </div>
        <?php endif; ?>

        <div class="hero-main-bg py-16 lg:py-24">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 hero-content-wrapper">
                <div class="grid lg:grid-cols-2 gap-8 items-center">
                    <div class="gift-space-card">
                        <div class="grid grid-cols-2 gap-4">
                            <div class="text-section flex flex-col justify-center items-start col-span-1">
                                <h2 class="text-2xl font-bold text-gray-800 leading-tight">the perfect gift for every space</h2>
                                <p class="text-gray-600 mt-2 text-lg">with</p>
                                <p class="text-xs text-gray-500 mt-2">*Redeemable online & in-store</p>
                            </div>
                            <div class="col-span-1 flex flex-col justify-center items-start bg-gray-50 p-6 rounded-md">
                                <p class="text-gray-700 font-semibold mb-2">Find the ideal present for any occasion:</p>
                                <ul class="list-disc list-inside text-gray-600 text-sm space-y-1">
                                    <li>Birthdays & Anniversaries</li>
                                    <li>Weddings & Engagements</li>
                                    <li>Festivals & Holidays</li>
                                    <li>Corporate Gifting Solutions</li>
                                    <li>Personalized Messages & Designs</li>
                                </ul>
                                <p class="text-right w-full text-purple-600 text-sm mt-4">Discover More &rarr;</p>
                            </div>
                            </div>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <a href="egift_cards.php" class="hero-icon-box">
                            <i data-lucide="gift" class="w-10 h-10 text-purple-600 mb-2"></i>
                            <h3 class="font-semibold">E-Gift Cards</h3>
                        </a>
                        <a href="premium_gifting.php" class="hero-icon-box">
                            <i data-lucide="crown" class="w-10 h-10 text-amber-500 mb-2"></i>
                            <h3 class="font-semibold">Premium Gifting</h3>
                        </a>
                        <a href="corporate_gifting.php" class="hero-icon-box">
                            <i data-lucide="building" class="w-10 h-10 text-blue-600 mb-2"></i>
                            <h3 class="font-semibold">Corporate Gifting</h3>
                        </a>
                        <a href="partner_brands.php" class="hero-icon-box">
                            <i data-lucide="handshake" class="w-10 h-10 text-green-600 mb-2"></i>
                            <h3 class="font-semibold">Partner Brands</h3>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <section class="mt-8 bg-white p-4 rounded-lg shadow-md">
            <form action="search_results.php" method="get" class="flex flex-col md:flex-row items-center gap-4">
                <input type="text" name="query" placeholder="Find Brands..." required class="w-full md:flex-grow border-gray-300 rounded-lg shadow-sm">
                <select class="w-full md:w-auto border-gray-300 rounded-lg shadow-sm"><option>All Categories</option></select>
                <select class="w-full md:w-auto border-gray-300 rounded-lg shadow-sm"><option>All Cities</option></select>
                <button type="submit" class="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white font-bold p-2 rounded-lg flex items-center justify-center">
                    <i data-lucide="search" class="w-5 h-5"></i>
                </button>
            </form>
        </section>

        <section class="py-12">
            <div class="flex justify-between items-center mb-4"><h2 class="text-2xl font-bold text-gray-800">Category / Occasion Cards</h2><a href="products.php" class="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors">See All &rarr;</a></div>

            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-12">
                <?php foreach ($occasion_cards as $card): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                           <button class="w-full text-left product-modal-trigger" data-product-id="<?= $card['id'] ?>">
                                <div class="relative">
                                    <img src="<?= htmlspecialchars($card['image']) ?>" alt="<?= htmlspecialchars($card['name']) ?>" class="w-full h-48 object-cover">
                                </div>
                                <div class="p-4">
                                    <h3 class="text-lg font-semibold text-gray-900 truncate"><?= htmlspecialchars($card['name']) ?></h3>
                                    <p class="text-sm text-gray-500"><?= htmlspecialchars($card['category']) ?></p>
                                </div>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="bg-gray-100 p-4 rounded-lg">
                <div class="flex items-center space-x-2 mb-6">
                    <button class="px-4 py-2 text-sm font-semibold tab-active">All Brands (<?= $total_brands_count ?>)</button>
                    <button class="px-4 py-2 text-sm font-semibold text-gray-500 hover:text-gray-700">Emerging Brands (<?= $emerging_brands_count ?>)</button>
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
                    <?php foreach ($brand_products as $product): ?>
                        <div class="bg-white rounded-lg shadow-md overflow-hidden transform hover:-translate-y-1 transition-transform duration-300">
                            <button class="w-full text-left product-modal-trigger" data-product-id="<?= $product['id'] ?>">
                                <div class="relative"><img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" class="w-full h-48 object-cover"></div>
                                <div class="p-4"><h3 class="text-lg font-semibold text-gray-900 truncate"><?= htmlspecialchars($product['name']) ?></h3><p class="text-sm text-gray-500"><?= htmlspecialchars($product['category']) ?></p></div>
                            </button>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="bg-white py-16">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-12">Testimonials</h2>
                <div class="relative">
                    <div class="grid md:grid-cols-3 gap-8">
                        <?php
                        // Sample data if your DB doesn't have testimonials or images yet
                        $sample_testimonials = [
                            ['name' => 'Maria Muzaffar', 'quote' => 'A refreshing concept in Pakistan...Through giftkarte I was able to send a gift to my friend on her special occasion without e...', 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=MM'],
                            ['name' => 'Mishal Waqar', 'quote' => "I've always loved seeing my niece smile whenever she received eidi but sadly, this year I couldn't go and meet her because of...", 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=MW'],
                            ['name' => 'Mohiuddin Zia', 'quote' => 'It is a very practical solution to save time on one end and to ensure that your loved ones far and near know that you care, o...', 'user_image' => 'https://placehold.co/48x48/dbeafe/4a5568?text=MZ']
                        ];
                        // Use DB testimonials if available, otherwise fallback to sample data
                        $display_testimonials = !empty($testimonials) ? $testimonials : $sample_testimonials;
                        ?>
                        <?php foreach ($display_testimonials as $testimonial): ?>
                            <div class="testimonial-card">
                                <div class="flex items-start mb-4">
                                    <img src="<?= htmlspecialchars($testimonial['user_image'] ?? 'https://placehold.co/48x48/dbeafe/4a5568?text=U') ?>" alt="User avatar" class="testimonial-avatar">
                                    <div>
                                        <span class="inline-block bg-green-100 text-green-800 text-xs font-semibold px-2.5 py-0.5 rounded-full">Consumer</span>
                                        <p class="text-lg text-gray-600 mt-2 testimonial-quote">"<?= htmlspecialchars($testimonial['quote']) ?> <a href="#" class="text-purple-600 hover:underline">View More</a>"</p>
                                    </div>
                                </div>
                                <p class="font-bold text-gray-800 text-left">- <?= htmlspecialchars($testimonial['name']) ?></p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-12 bg-white">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-center text-gray-800 mb-8">Our Clients</h2>
                <div class="flex flex-wrap justify-center items-center gap-x-12 gap-y-8">
                    <?php
                    // Sample data for clients if your DB doesn't have them or images yet
                    $sample_clients = [
                        ['name' => 'Novartis', 'logo_url' => 'https://via.placeholder.com/150x50/ffffff/000000?text=NOVARTIS'],
                        ['name' => 'Santex', 'logo_url' => 'https://via.placeholder.com/150x50/ffffff/000000?text=Santex'],
                        ['name' => 'PARCO', 'logo_url' => 'https://via.placeholder.com/150x50/ffffff/000000?text=PARCO'],
                        ['name' => 'Gerrys dnata', 'logo_url' => 'https://via.placeholder.com/150x50/ffffff/000000?text=Gerrys+dnata'],
                        ['name' => 'KE', 'logo_url' => 'https://via.placeholder.com/150x50/ffffff/000000?text=KE']
                    ];
                    // Use DB clients if available, otherwise fallback to sample data
                    $display_clients = !empty($clients) ? $clients : $sample_clients;
                    ?>
                    <?php foreach ($display_clients as $client): ?>
                        <img src="<?= htmlspecialchars($client['logo_url']) ?>" alt="<?= htmlspecialchars($client['name']) ?>" class="h-10 md:h-12 brand-logo">
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="stats-section py-12">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <div><h3 class="text-4xl md:text-5xl font-extrabold text-purple-700">350+</h3><p class="text-gray-600 font-medium mt-1">Corporate Clients</p></div>
                <div><h3 class="text-4xl md:text-5xl font-extrabold text-purple-700">2,000+</h3><p class="text-gray-600 font-medium mt-1">Retail Stores Across Pakistan</p></div>
                <div><h3 class="text-4xl md:text-5xl font-extrabold text-purple-700">40+</h3><p class="text-gray-600 font-medium mt-1">Cities in Pakistan</p></div>
                <div><h3 class="text-4xl md:text-5xl font-extrabold text-purple-700">100k+</h3><p class="text-gray-600 font-medium mt-1">Gift Cards Issued</p></div>
            </div>
        </section>
    </main>

    <section class="download-section py-12">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
            <div><h2 class="text-2xl md:text-3xl font-bold text-gray-800">Download the app!</h2><p class="text-gray-600 mt-1">Send & Receive E-Gift Cards from your device with our mobile app!</p></div>
            <div class="flex space-x-4 mt-6 md:mt-0">
                <a href="https://www.apple.com/app-store/" target="_blank"><img src="https://placehold.co/160x50/000000/ffffff?text=App+Store" alt="Download on the App Store" class="rounded-lg"></a>
                <a href="https://play.google.com/store" target="_blank"><img src="https://placehold.co/160x50/000000/ffffff?text=Google+Play" alt="Get it on Google Play" class="rounded-lg"></a>
            </div>
        </div>
    </section>

    <footer class="bg-gray-800 text-white">
        <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div class="grid grid-cols-2 md:grid-cols-5 gap-8">
                <div class="col-span-2 md:col-span-1">
                    <h3 class="text-lg font-semibold mb-4 flex items-center">
                        <i data-lucide="gift" class="w-6 h-6 mr-2"></i>
                        Gifted Me
                    </h3>
                    <p class="text-gray-400 text-sm">
                        Our digital gifting platform offers a variety of E-Gift Card in various retail categories that are redeemable at our ever-growing business partner retail stores across Pakistan.
                    </p>
                    <div class="flex space-x-4 mt-4">
                        <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="facebook" class="w-5 h-5"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="instagram" class="w-5 h-5"></i></a>
                        <a href="#" class="text-gray-400 hover:text-white"><i data-lucide="linkedin" class="w-5 h-5"></i></a>
                    </div>
                </div>
                <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Company</h3><ul class="space-y-2 text-sm"><li><a href="about_gifted_me.php" class="text-gray-300 hover:text-white">About Gifted Me</a></li><li><a href="founders_story.php" class="text-gray-300 hover:text-white">Founder's Story</a></li><li><a href="#" class="text-gray-300 hover:text-white">In-Store Partner Brand List</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Partner Brand List</a></li><li><a href="#" class="text-gray-300 hover:text-white">Brands On Sale</a></li><li><a href="contact.php" class="text-gray-300 hover:text-white">Contact</a></li></ul></div>
                <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">E-Gift Card</h3><ul class="space-y-2 text-sm"><li><a href="egift_cards.php" class="text-gray-300 hover:text-white">E-Gift Cards</a></li><li><a href="corporate_gifting.php" class="text-gray-300 hover:text-white">Corporate Gifting</a></li><li><a href="gk_coupon.php" class="text-gray-300 hover:text-white">GK-Coupon (for Corporate Clients)</a></li></ul></div>
                <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Discover</h3><ul class="space-y-2 text-sm"><li><a href="how_it_works.php" class="text-gray-300 hover:text-white">How It Works</a></li><li><a href="#" class="text-gray-300 hover:text-white">How To Order</a></li><li><a href="#" class="text-gray-300 hover:text-white">In-Store Redemption</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Redemption</a></li><li><a href="faqs.php" class="text-gray-300 hover:text-white">FAQs</a></li><li><a href="blog.php" class="text-gray-300 hover:text-white">Blog</a></li><li><a href="#" class="text-gray-300 hover:text-white">Announcements</a></li></ul></div>
                <div><h3 class="text-sm font-semibold tracking-wider uppercase text-gray-400 mb-4">Resources</h3><ul class="space-y-2 text-sm"><li><a href="admin/" class="text-gray-300 hover:text-white">Vendor Portal Login</a></li><li><a href="#" class="text-gray-300 hover:text-white">Onboarding Request Form</a></li><li><a href="#" class="text-gray-300 hover:text-white">Online Redemption API</a></li><li><a href="#" class="text-gray-300 hover:text-white">Issuance API Doc (New)</a></li></ul></div>
            </div>
            <div class="mt-12 border-t border-gray-700 pt-6 flex flex-col md:flex-row justify-between items-center text-sm">
                <p class="text-gray-400">&copy; <?= date("Y") ?> Gifted Me. All rights reserved.</p>
                <div class="flex space-x-4 mt-4 md:mt-0"><a href="privacy_policy.php" class="text-gray-400 hover:text-white">Privacy Policy</a><a href="terms_conditions.php" class="text-gray-400 hover:text-white">Terms & Conditions</a><a href="#" class="text-gray-400 hover:text-white">Disclaimer</a><img src="https://placehold.co/100x20/ffffff/cccccc?text=VISA+Master" alt="Payment Methods" class="ml-4"></div>
            </div>
               <p class="text-gray-400 text-center mt-6">Send Gifts to Pakistan from USA, UK, Canada, UAE, and all over the world with Giftme</p>
        </div>
    </footer>

    <div id="product-modal" class="modal fixed inset-0 bg-black bg-opacity-50 items-center justify-center p-4 z-50">
        <div class="bg-white rounded-lg shadow-2xl w-full max-w-4xl p-6 relative" id="modal-content">
            <button id="modal-close-btn" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800"><i data-lucide="x" class="w-6 h-6"></i></button>
            <div id="modal-body" class="max-h-[80vh] overflow-y-auto"></div>
            <div class="mt-6 flex justify-end space-x-4 border-t pt-4">
                <button id="modal-close-btn-footer" class="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded-lg">Close</button>
                <a href="#" id="modal-buy-btn" class="bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-4 rounded-lg">Buy E-Gift Card</a>
            </div>
        </div>
    </div>

    <a href="https://wa.me/923471386379" target="_blank" class="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg flex items-center justify-center z-50">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-6 h-6"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>
    </a>

    <script>
        lucide.createIcons();
        const modal = document.getElementById('product-modal');
        const modalBody = document.getElementById('modal-body');
        const modalBuyBtn = document.getElementById('modal-buy-btn');
        const closeButtons = [document.getElementById('modal-close-btn'), document.getElementById('modal-close-btn-footer')];
        const triggers = document.querySelectorAll('.product-modal-trigger');

        triggers.forEach(trigger => {
            trigger.addEventListener('click', () => {
                const productId = trigger.dataset.productId;
                modal.classList.add('is-open');
                modalBody.innerHTML = '<div class="text-center p-8"><i data-lucide="loader" class="w-12 h-12 mx-auto animate-spin text-purple-600"></i><p>Loading...</p></div>';
                lucide.createIcons();

                fetch(`product_modal.php?id=${productId}`)
                    .then(response => response.text())
                    .then(html => {
                        modalBody.innerHTML = html;
                        modalBuyBtn.href = `product_detail.php?id=${productId}`;
                    });
            });
        });

        const closeModal = () => modal.classList.remove('is-open');
        closeButtons.forEach(btn => btn.addEventListener('click', closeModal));
        modal.addEventListener('click', (event) => {
            if (event.target === modal) closeModal();
        });
    </script>
</body>
</html>
